import Link from "next/link";
import { Button } from "@/components/ui/Button";
import { Globe } from "./components/Globe";

export default function LandingPage() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-base px-6 py-20 text-center">
      {/* Full-screen cinematic backdrop */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 20%, rgba(91,140,255,0.10), transparent 55%)",
        }}
      />

      <div className="relative z-10 flex flex-col items-center gap-10">
        <div className="flex flex-col items-center gap-4 animate-slide-up">
          <p className="font-mono text-sm uppercase tracking-widest text-text-secondary">
            LifeOS
          </p>
          <h1 className="max-w-2xl font-display text-4xl font-semibold text-text-primary sm:text-6xl">
            Your life, as one system.
          </h1>
        </div>

        <Globe />

        <Link
          href="/login"
          className="animate-slide-up"
          style={{ animationDelay: "300ms" }}
        >
          <Button size="lg">Enter LifeOS</Button>
        </Link>
      </div>
    </div>
  );
}
