export default function MarketingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Intentionally minimal — the landing page owns its full-bleed canvas
  // (rotating Earth, etc). No shared app chrome lives here.
  return <main className="min-h-screen bg-base">{children}</main>;
}
