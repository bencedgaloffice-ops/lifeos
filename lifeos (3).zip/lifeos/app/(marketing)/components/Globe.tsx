/**
 * Landing-page-only visual. Deliberately not a WebGL/Three.js globe —
 * that would mean adding a new dependency to a frozen Phase 0 foundation.
 * Instead: a shaded sphere (radial-gradient lighting) with a slowly
 * panning grid texture to read as "rotating," an ambient glow behind
 * it, and a marker for Budapest/Diósd. Pure CSS animation, so the
 * global `prefers-reduced-motion` rule in globals.css already halts
 * it for anyone who needs that — no extra handling required here.
 */
export function Globe() {
  return (
    <div className="relative mx-auto flex w-full max-w-[460px] flex-col items-center">
      <div className="relative aspect-square w-[220px] sm:w-[320px] lg:w-[420px]">
        {/* Ambient glow behind the sphere */}
        <div
          aria-hidden
          className="absolute -inset-10 rounded-full blur-3xl"
          style={{
            background:
              "radial-gradient(circle, rgba(91,140,255,0.16), transparent 70%)",
          }}
        />

        {/* The sphere itself */}
        <div
          aria-hidden
          className="globe-sphere absolute inset-0 overflow-hidden rounded-full"
        >
          {/* Rotating surface texture — a faint longitude grid panning
              horizontally to read as ambient rotation */}
          <div className="globe-surface absolute inset-0" />
          {/* Static lighting overlay — top-left highlight, terminator
              shadow toward the bottom-right, doesn't rotate */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              background:
                "radial-gradient(circle at 32% 28%, rgba(255,255,255,0.20), transparent 45%), radial-gradient(circle at 68% 75%, rgba(0,0,0,0.55), transparent 60%)",
            }}
          />
          {/* Edge darkening so the disc reads as a sphere, not a circle */}
          <div className="absolute inset-0 rounded-full shadow-[inset_0_0_60px_30px_rgba(0,0,0,0.55)]" />
        </div>

        {/* Location marker — approximate position of Central Europe
            on the visible face */}
        <div
          className="absolute flex flex-col items-center animate-fade-in"
          style={{ top: "34%", left: "58%", animationDelay: "600ms" }}
        >
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
          </span>
        </div>
      </div>

      <p
        className="mt-6 animate-fade-in font-mono text-xs uppercase tracking-widest text-text-secondary"
        style={{ animationDelay: "800ms" }}
      >
        Budapest · Diósd, Hungary
      </p>
    </div>
  );
}
