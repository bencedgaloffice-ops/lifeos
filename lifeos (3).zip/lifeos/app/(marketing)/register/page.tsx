"use client";

import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2 } from "lucide-react";
import { GlassPanel } from "@/components/ui/GlassPanel";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { registerSchema, type RegisterInput } from "@/lib/validations/auth";

export default function RegisterPage() {
  const [status, setStatus] = useState<"idle" | "sent">("idle");
  const [authError, setAuthError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({ resolver: zodResolver(registerSchema) });

  const onSubmit = async (data: RegisterInput) => {
    setAuthError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: { emailRedirectTo: `${window.location.origin}/dashboard` },
    });
    if (error) {
      setAuthError(error.message);
      return;
    }
    setStatus("sent");
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-6">
      <GlassPanel elevated className="w-full max-w-sm p-8 animate-scale-in">
        <h1 className="mb-2 font-display text-2xl text-text-primary">
          Create your LifeOS
        </h1>
        <p className="mb-6 text-sm text-text-secondary">
          One account, every part of your life.
        </p>

        {status === "sent" ? (
          <FormStatus variant="success">
            Check your inbox to confirm your account.
          </FormStatus>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
            <Input
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              error={errors.email?.message}
              {...register("email")}
            />
            <Input
              type="password"
              placeholder="Password"
              autoComplete="new-password"
              error={errors.password?.message}
              {...register("password")}
            />
            <Input
              type="password"
              placeholder="Confirm password"
              autoComplete="new-password"
              error={errors.confirmPassword?.message}
              {...register("confirmPassword")}
            />
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin" />
                  Creating account…
                </span>
              ) : (
                "Create account"
              )}
            </Button>
            {authError && <FormStatus variant="error">{authError}</FormStatus>}
          </form>
        )}

        <p className="mt-6 text-center text-xs text-text-secondary">
          Already have an account?{" "}
          <Link href="/login" className="text-accent hover:underline">
            Sign in
          </Link>
        </p>
      </GlassPanel>
    </div>
  );
}
