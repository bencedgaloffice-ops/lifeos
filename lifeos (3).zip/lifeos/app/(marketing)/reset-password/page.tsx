"use client";

import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2 } from "lucide-react";
import { GlassPanel } from "@/components/ui/GlassPanel";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import {
  resetPasswordSchema,
  type ResetPasswordInput,
} from "@/lib/validations/auth";

export default function ResetPasswordPage() {
  const [status, setStatus] = useState<"idle" | "sent">("idle");
  const [authError, setAuthError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ResetPasswordInput>({ resolver: zodResolver(resetPasswordSchema) });

  const onSubmit = async (data: ResetPasswordInput) => {
    setAuthError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.resetPasswordForEmail(data.email, {
      redirectTo: `${window.location.origin}/login`,
    });
    if (error) {
      setAuthError(error.message);
      return;
    }
    setStatus("sent");
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-6">
      <GlassPanel elevated className="w-full max-w-sm p-8 animate-scale-in">
        <h1 className="mb-2 font-display text-2xl text-text-primary">
          Reset password
        </h1>
        <p className="mb-6 text-sm text-text-secondary">
          We&apos;ll email you a link to set a new password.
        </p>

        {status === "sent" ? (
          <FormStatus variant="success">
            Check your inbox for the reset link.
          </FormStatus>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
            <Input
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              error={errors.email?.message}
              {...register("email")}
            />
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin" />
                  Sending…
                </span>
              ) : (
                "Send reset link"
              )}
            </Button>
            {authError && <FormStatus variant="error">{authError}</FormStatus>}
          </form>
        )}

        <p className="mt-6 text-center text-xs text-text-secondary">
          <Link href="/login" className="text-accent hover:underline">
            Back to sign in
          </Link>
        </p>
      </GlassPanel>
    </div>
  );
}
