"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { DreamCard } from "./DreamCard";
import type { Dream } from "../types";

interface DreamsBoardProps {
  dreams: Dream[];
  onEdit: (dream: Dream) => void;
  onCreate: () => void;
  onReorder: (orderedIds: string[]) => void;
}

export function DreamsBoard({ dreams, onEdit, onCreate, onReorder }: DreamsBoardProps) {
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  if (dreams.length === 0) {
    return (
      <EmptyState
        title="No dreams on the board yet"
        description="Add what you're picturing for the future — a place, a milestone, a life you're building toward."
        action={
          <Button size="sm" onClick={onCreate}>
            <Plus size={14} className="mr-1.5" />
            Add a dream
          </Button>
        }
      />
    );
  }

  const handleDrop = (targetId: string) => {
    if (!draggedId || draggedId === targetId) {
      setDraggedId(null);
      setDragOverId(null);
      return;
    }
    const currentIds = dreams.map((d) => d.id);
    const fromIndex = currentIds.indexOf(draggedId);
    const toIndex = currentIds.indexOf(targetId);
    const reordered = [...currentIds];
    reordered.splice(fromIndex, 1);
    reordered.splice(toIndex, 0, draggedId);

    setDraggedId(null);
    setDragOverId(null);
    onReorder(reordered);
  };

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {dreams.map((dream) => (
        <DreamCard
          key={dream.id}
          dream={dream}
          onEdit={() => onEdit(dream)}
          draggable
          isDragTarget={dragOverId === dream.id && draggedId !== dream.id}
          onDragStart={() => setDraggedId(dream.id)}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOverId(dream.id);
          }}
          onDrop={(e) => {
            e.preventDefault();
            handleDrop(dream.id);
          }}
        />
      ))}
    </div>
  );
}
