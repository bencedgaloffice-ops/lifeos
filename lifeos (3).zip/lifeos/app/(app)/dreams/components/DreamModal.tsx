"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { dreamFormSchema, type DreamFormInput } from "@/lib/validations/dreams";
import type { Dream } from "../types";

interface DreamModalProps {
  mode: "create" | "edit";
  dream?: Dream;
  /** Next order_index to assign a newly created dream (appends to the end). */
  nextOrderIndex: number;
  onClose: () => void;
  onSaved: (dream: Dream) => void;
  onDeleted: () => void;
}

export function DreamModal({
  mode,
  dream,
  nextOrderIndex,
  onClose,
  onSaved,
  onDeleted,
}: DreamModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<DreamFormInput>({
    resolver: zodResolver(dreamFormSchema),
    defaultValues: dream
      ? { title: dream.title, description: dream.description ?? "", imageUrl: dream.image_url ?? "" }
      : { title: "", description: "", imageUrl: "" },
  });

  const imageUrl = watch("imageUrl");

  const onSubmit = async (data: DreamFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      title: data.title,
      description: data.description || null,
      image_url: data.imageUrl || null,
      ...(mode === "create" ? { order_index: nextOrderIndex } : {}),
    };

    const { data: saved, error } =
      mode === "edit" && dream
        ? await supabase.from("dreams").update(payload).eq("id", dream.id).select().single()
        : await supabase.from("dreams").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!dream) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("dreams").delete().eq("id", dream.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New dream" : "Edit dream"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Dream title" error={errors.title?.message} {...register("title")} />

        <textarea
          placeholder="Description (optional)"
          rows={3}
          className="w-full rounded-card border border-border-subtle bg-glass px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          {...register("description")}
        />

        <Input
          type="url"
          placeholder="Image URL (optional)"
          error={errors.imageUrl?.message}
          {...register("imageUrl")}
        />

        {imageUrl && (
          <div className="overflow-hidden rounded-card border border-border-subtle">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={imageUrl} alt="" className="h-32 w-full object-cover" onError={(e) => (e.currentTarget.style.display = "none")} />
          </div>
        )}

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this dream?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Add dream"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
