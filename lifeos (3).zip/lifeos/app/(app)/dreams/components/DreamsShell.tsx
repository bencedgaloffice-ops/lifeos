"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { createClient } from "@/lib/supabase/client";
import { DreamsBoard } from "./DreamsBoard";
import { DreamModal } from "./DreamModal";
import type { Dream } from "../types";

interface DreamsShellProps {
  initialDreams: Dream[];
}

type ModalState = { mode: "closed" } | { mode: "create" } | { mode: "edit"; dream: Dream };

export function DreamsShell({ initialDreams }: DreamsShellProps) {
  const [dreams, setDreams] = useState(initialDreams);
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  const nextOrderIndex = dreams.length > 0 ? Math.max(...dreams.map((d) => d.order_index)) + 1 : 0;

  const handleSaved = (saved: Dream) => {
    setDreams((prev) => {
      const exists = prev.some((d) => d.id === saved.id);
      const next = exists ? prev.map((d) => (d.id === saved.id ? saved : d)) : [...prev, saved];
      return next.sort((a, b) => a.order_index - b.order_index);
    });
    setModal({ mode: "closed" });
  };

  const handleDeleted = () => {
    if (modal.mode === "edit") {
      setDreams((prev) => prev.filter((d) => d.id !== modal.dream.id));
    }
    setModal({ mode: "closed" });
  };

  const handleReorder = async (orderedIds: string[]) => {
    // Optimistic local reorder first, then persist each new order_index.
    const byId = new Map(dreams.map((d) => [d.id, d]));
    const reordered = orderedIds
      .map((id, index) => {
        const dream = byId.get(id);
        return dream ? { ...dream, order_index: index } : null;
      })
      .filter((d): d is Dream => d !== null);
    setDreams(reordered);

    const supabase = createClient();
    await Promise.all(
      reordered.map((dream) =>
        supabase.from("dreams").update({ order_index: dream.order_index }).eq("id", dream.id)
      )
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dreams"
        description="A visual board of what you're picturing for the future. Drag to reorder."
        actions={
          <Button size="sm" onClick={() => setModal({ mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            Add a dream
          </Button>
        }
      />

      <DreamsBoard
        dreams={dreams}
        onEdit={(dream) => setModal({ mode: "edit", dream })}
        onCreate={() => setModal({ mode: "create" })}
        onReorder={handleReorder}
      />

      {modal.mode !== "closed" && (
        <DreamModal
          mode={modal.mode}
          dream={modal.mode === "edit" ? modal.dream : undefined}
          nextOrderIndex={nextOrderIndex}
          onClose={() => setModal({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
