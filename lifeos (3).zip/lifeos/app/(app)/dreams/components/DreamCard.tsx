"use client";

import { useState } from "react";
import { Pencil, Sparkles, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import type { Dream } from "../types";

interface DreamCardProps {
  dream: Dream;
  onEdit: () => void;
  draggable?: boolean;
  onDragStart?: () => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
  isDragTarget?: boolean;
}

/**
 * Image-forward, cinematic card — deliberately not using next/image:
 * arbitrary user-supplied image_url values fall outside the
 * next.config.js remotePatterns allowlist (frozen at *.supabase.co),
 * and widening that allowlist would mean touching frozen foundation
 * config. A plain <img> avoids the Image Optimization domain
 * restriction entirely, with a graceful gradient placeholder when
 * no image_url is set.
 */
export function DreamCard({
  dream,
  onEdit,
  draggable = false,
  onDragStart,
  onDragOver,
  onDrop,
  isDragTarget = false,
}: DreamCardProps) {
  const [imageError, setImageError] = useState(false);
  const showImage = dream.image_url && !imageError;

  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      className={cn(
        "group relative aspect-square overflow-hidden rounded-panel border border-border-subtle transition-all",
        isDragTarget && "ring-2 ring-accent"
      )}
    >
      {showImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={dream.image_url ?? undefined}
          alt=""
          onError={() => setImageError(true)}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      ) : (
        <div
          aria-hidden
          className="absolute inset-0 flex items-center justify-center"
          style={{
            background:
              "radial-gradient(circle at 30% 20%, rgba(91,140,255,0.18), transparent 60%), #131417",
          }}
        >
          <Sparkles size={28} className="text-text-secondary/40" />
        </div>
      )}

      {/* Gradient scrim for legible text over any image */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />

      {draggable && (
        <span className="absolute left-2 top-2 cursor-grab text-white/60 opacity-0 transition-opacity group-hover:opacity-100">
          <GripVertical size={16} />
        </span>
      )}

      <button
        onClick={onEdit}
        aria-label="Edit dream"
        className="absolute right-2 top-2 rounded-card bg-black/40 p-1.5 text-white opacity-0 backdrop-blur-sm transition-opacity hover:bg-black/60 group-hover:opacity-100"
      >
        <Pencil size={14} />
      </button>

      <div className="absolute inset-x-0 bottom-0 p-3">
        <h3 className="truncate font-display text-sm font-medium text-white">{dream.title}</h3>
        {dream.description && (
          <p className="mt-0.5 line-clamp-2 text-xs text-white/70">{dream.description}</p>
        )}
      </div>
    </div>
  );
}
