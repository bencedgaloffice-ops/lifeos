import type { Database } from "@/types/supabase";

export type Dream = Database["public"]["Tables"]["dreams"]["Row"];
