import { createClient } from "@/lib/supabase/server";
import { DreamsShell } from "./components/DreamsShell";

export default async function DreamsPage() {
  const supabase = await createClient();

  const { data: dreams } = await supabase
    .from("dreams")
    .select("*")
    .order("order_index", { ascending: true });

  return <DreamsShell initialDreams={dreams ?? []} />;
}
