import { createClient } from "@/lib/supabase/server";
import { GoalsShell } from "./components/GoalsShell";

export default async function GoalsPage() {
  const supabase = await createClient();

  const [{ data: goals }, { data: lifeAreas }] = await Promise.all([
    supabase.from("goals").select("*").order("created_at", { ascending: false }),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
  ]);

  return <GoalsShell initialGoals={goals ?? []} lifeAreas={lifeAreas ?? []} />;
}
