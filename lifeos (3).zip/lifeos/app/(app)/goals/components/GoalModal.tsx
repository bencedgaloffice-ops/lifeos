"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { goalFormSchema, type GoalFormInput } from "@/lib/validations/goals";
import { SelectField } from "./SelectField";
import { LifeAreaSelector } from "./LifeAreaSelector";
import type { Goal, LifeArea } from "../types";

interface GoalModalProps {
  mode: "create" | "edit";
  goal?: Goal;
  lifeAreas: LifeArea[];
  onClose: () => void;
  onSaved: (goal: Goal) => void;
  onDeleted: () => void;
}

export function GoalModal({ mode, goal, lifeAreas, onClose, onSaved, onDeleted }: GoalModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<GoalFormInput>({
    resolver: zodResolver(goalFormSchema),
    defaultValues: goal
      ? {
          title: goal.title,
          description: goal.description ?? "",
          targetDate: goal.target_date ?? "",
          status: goal.status,
          category: goal.category ?? "",
          lifeAreaId: goal.life_area_id ?? "",
          progressPercent: goal.progress_percent,
        }
      : {
          title: "",
          description: "",
          targetDate: "",
          status: "active",
          category: "",
          lifeAreaId: "",
          progressPercent: 0,
        },
  });

  const progressPercent = watch("progressPercent");

  const onSubmit = async (data: GoalFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      title: data.title,
      description: data.description || null,
      target_date: data.targetDate || null,
      status: data.status,
      category: data.category || null,
      life_area_id: data.lifeAreaId || null,
      progress_percent: data.progressPercent,
    };

    const { data: saved, error } =
      mode === "edit" && goal
        ? await supabase.from("goals").update(payload).eq("id", goal.id).select().single()
        : await supabase.from("goals").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!goal) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("goals").delete().eq("id", goal.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New goal" : "Edit goal"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Goal title" error={errors.title?.message} {...register("title")} />

        <textarea
          placeholder="Description (optional)"
          rows={3}
          className="w-full rounded-card border border-border-subtle bg-glass px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          {...register("description")}
        />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="status"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="active">Active</option>
                <option value="achieved">Achieved</option>
                <option value="dropped">Dropped</option>
              </SelectField>
            )}
          />
          <Input type="date" placeholder="Target date" {...register("targetDate")} />
        </div>

        <Controller
          name="lifeAreaId"
          control={control}
          render={({ field }) => <LifeAreaSelector lifeAreas={lifeAreas} {...field} />}
        />

        <Input placeholder="Category (optional)" {...register("category")} />

        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>Progress</span>
            <span className="font-mono">{progressPercent}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            className="accent-[--accent]"
            {...register("progressPercent")}
          />
        </div>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this goal?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create goal"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
