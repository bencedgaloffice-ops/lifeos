import { Badge } from "@/components/ui/Badge";
import type { GoalStatus } from "../types";

const STATUS_STYLE: Record<GoalStatus, { label: string; variant: "accent" | "success" | "neutral" }> = {
  active: { label: "Active", variant: "accent" },
  achieved: { label: "Achieved", variant: "success" },
  dropped: { label: "Dropped", variant: "neutral" },
};

export function GoalStatusBadge({ status }: { status: GoalStatus }) {
  const style = STATUS_STYLE[status];
  return <Badge variant={style.variant}>{style.label}</Badge>;
}
