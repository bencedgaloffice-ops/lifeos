"use client";

import { Pencil, CalendarClock } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Tag } from "@/components/ui/Tag";
import { GoalStatusBadge } from "./StatusBadge";
import { GoalProgressBar } from "./GoalProgressBar";
import { cn } from "@/lib/utils/cn";
import type { Goal, LifeArea } from "../types";

interface GoalCardProps {
  goal: Goal;
  lifeArea?: LifeArea;
  onEdit: () => void;
}

function formatTargetDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function GoalCard({ goal, lifeArea, onEdit }: GoalCardProps) {
  const isOverdue =
    goal.status === "active" && goal.target_date && new Date(goal.target_date) < new Date();

  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <h3 className="min-w-0 flex-1 truncate font-display text-sm font-medium text-text-primary">
          {goal.title}
        </h3>
        <button
          onClick={onEdit}
          aria-label="Edit goal"
          className="shrink-0 rounded-card p-1 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
        >
          <Pencil size={14} />
        </button>
      </div>

      {goal.description && (
        <p className="line-clamp-2 text-xs text-text-secondary">{goal.description}</p>
      )}

      <div className="flex flex-wrap items-center gap-1.5">
        <GoalStatusBadge status={goal.status} />
        {goal.category && <Tag>{goal.category}</Tag>}
        {lifeArea && <Tag color={lifeArea.color ?? undefined}>{lifeArea.name}</Tag>}
      </div>

      {goal.target_date && (
        <div
          className={cn(
            "flex items-center gap-1.5 text-xs",
            isOverdue ? "text-danger" : "text-text-secondary"
          )}
        >
          <CalendarClock size={13} />
          <span>
            {isOverdue ? "Overdue — was " : "Target "}
            {formatTargetDate(goal.target_date)}
          </span>
        </div>
      )}

      <GoalProgressBar percent={goal.progress_percent} />
    </Card>
  );
}
