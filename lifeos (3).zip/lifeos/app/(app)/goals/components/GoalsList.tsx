import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { GoalCard } from "./GoalCard";
import type { Goal, LifeArea } from "../types";

interface GoalsListProps {
  goals: Goal[];
  lifeAreaById: Map<string, LifeArea>;
  onEdit: (goal: Goal) => void;
  onCreate: () => void;
  hasAnyGoals: boolean;
}

export function GoalsList({ goals, lifeAreaById, onEdit, onCreate, hasAnyGoals }: GoalsListProps) {
  if (goals.length === 0) {
    return (
      <EmptyState
        title={hasAnyGoals ? "No goals match your filters" : "No goals yet"}
        description={
          hasAnyGoals
            ? "Try adjusting your search or filters."
            : "Set your first goal — career, wealth, health, family, or legacy."
        }
        action={
          !hasAnyGoals && (
            <Button size="sm" onClick={onCreate}>
              <Plus size={14} className="mr-1.5" />
              New goal
            </Button>
          )
        }
      />
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {goals.map((goal) => (
        <GoalCard
          key={goal.id}
          goal={goal}
          lifeArea={goal.life_area_id ? lifeAreaById.get(goal.life_area_id) : undefined}
          onEdit={() => onEdit(goal)}
        />
      ))}
    </div>
  );
}
