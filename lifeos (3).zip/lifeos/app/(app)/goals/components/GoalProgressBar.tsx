import { cn } from "@/lib/utils/cn";

interface GoalProgressBarProps {
  percent: number;
  className?: string;
}

export function GoalProgressBar({ percent, className }: GoalProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, percent));

  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <div className="flex items-center justify-between text-xs text-text-secondary">
        <span>Progress</span>
        <span className="font-mono">{clamped}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
        <div
          className="h-full rounded-full bg-accent transition-all"
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}
