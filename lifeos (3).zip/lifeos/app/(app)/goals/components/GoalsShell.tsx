"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { GoalFilters } from "./GoalFilters";
import { GoalsList } from "./GoalsList";
import { GoalModal } from "./GoalModal";
import type { Goal, LifeArea, StatusFilter } from "../types";

interface GoalsShellProps {
  initialGoals: Goal[];
  lifeAreas: LifeArea[];
}

type ModalState = { mode: "closed" } | { mode: "create" } | { mode: "edit"; goal: Goal };

export function GoalsShell({ initialGoals, lifeAreas }: GoalsShellProps) {
  const [goals, setGoals] = useState(initialGoals);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [lifeAreaId, setLifeAreaId] = useState("");
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  const lifeAreaById = useMemo(() => {
    const map = new Map<string, LifeArea>();
    lifeAreas.forEach((a) => map.set(a.id, a));
    return map;
  }, [lifeAreas]);

  const filteredGoals = useMemo(() => {
    const query = search.trim().toLowerCase();
    return goals.filter((goal) => {
      if (status !== "all" && goal.status !== status) return false;
      if (lifeAreaId && goal.life_area_id !== lifeAreaId) return false;
      if (query && !goal.title.toLowerCase().includes(query)) return false;
      return true;
    });
  }, [goals, search, status, lifeAreaId]);

  const handleSaved = (saved: Goal) => {
    setGoals((prev) => {
      const exists = prev.some((g) => g.id === saved.id);
      return exists ? prev.map((g) => (g.id === saved.id ? saved : g)) : [saved, ...prev];
    });
    setModal({ mode: "closed" });
  };

  const handleDeleted = () => {
    if (modal.mode === "edit") {
      setGoals((prev) => prev.filter((g) => g.id !== modal.goal.id));
    }
    setModal({ mode: "closed" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Goals"
        description="What you're working toward, across every part of life."
        actions={
          <Button size="sm" onClick={() => setModal({ mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            New goal
          </Button>
        }
      />

      <GoalFilters
        search={search}
        onSearchChange={setSearch}
        status={status}
        onStatusChange={setStatus}
        lifeAreaId={lifeAreaId}
        onLifeAreaChange={setLifeAreaId}
        lifeAreas={lifeAreas}
      />

      <GoalsList
        goals={filteredGoals}
        lifeAreaById={lifeAreaById}
        onEdit={(goal) => setModal({ mode: "edit", goal })}
        onCreate={() => setModal({ mode: "create" })}
        hasAnyGoals={goals.length > 0}
      />

      {modal.mode !== "closed" && (
        <GoalModal
          mode={modal.mode}
          goal={modal.mode === "edit" ? modal.goal : undefined}
          lifeAreas={lifeAreas}
          onClose={() => setModal({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
