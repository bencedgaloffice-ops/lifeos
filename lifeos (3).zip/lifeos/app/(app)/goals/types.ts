import type { Database } from "@/types/supabase";

export type Goal = Database["public"]["Tables"]["goals"]["Row"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];
export type GoalStatus = Goal["status"];
export type StatusFilter = "all" | GoalStatus;
