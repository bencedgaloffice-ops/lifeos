import { createClient } from "@/lib/supabase/server";
import { JournalShell } from "./components/JournalShell";

export default async function JournalPage() {
  const supabase = await createClient();

  const { data: entries } = await supabase
    .from("journal_entries")
    .select("*")
    .order("entry_date", { ascending: false });

  return <JournalShell initialEntries={entries ?? []} />;
}
