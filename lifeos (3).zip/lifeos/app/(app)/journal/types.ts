import type { Database } from "@/types/supabase";

export type JournalEntry = Database["public"]["Tables"]["journal_entries"]["Row"];
