/** Journal-module-local mood vocabulary. Free text in the schema
 * (journal_entries.mood), but a fixed palette keeps the selector and
 * filter consistent rather than accumulating one-off strings. */
export const MOODS = [
  { value: "grateful", label: "Grateful", emoji: "🙏" },
  { value: "happy", label: "Happy", emoji: "😊" },
  { value: "calm", label: "Calm", emoji: "🌿" },
  { value: "reflective", label: "Reflective", emoji: "🌙" },
  { value: "excited", label: "Excited", emoji: "✨" },
  { value: "tired", label: "Tired", emoji: "🌫️" },
  { value: "stressed", label: "Stressed", emoji: "⚡" },
  { value: "sad", label: "Sad", emoji: "🌧️" },
] as const;

export function moodEmoji(mood: string | null) {
  return MOODS.find((m) => m.value === mood)?.emoji ?? null;
}

export function moodLabel(mood: string | null) {
  return MOODS.find((m) => m.value === mood)?.label ?? mood;
}
