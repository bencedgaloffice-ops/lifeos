import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { EntryDetailShell } from "../components/EntryDetailShell";

export default async function JournalEntryPage({
  params,
}: {
  params: Promise<{ entryId: string }>;
}) {
  const { entryId } = await params;
  const supabase = await createClient();

  const { data: entry } = await supabase
    .from("journal_entries")
    .select("*")
    .eq("id", entryId)
    .single();

  if (!entry) {
    notFound();
  }

  return <EntryDetailShell initialEntry={entry} />;
}
