import Link from "next/link";
import { Card } from "@/components/ui/Card";
import { moodEmoji } from "../moods";
import type { JournalEntry } from "../types";

interface EntryCardProps {
  entry: JournalEntry;
}

function snippet(body: string | null, length = 160) {
  if (!body) return null;
  const flat = body.replace(/\n+/g, " ").replace(/[*_]/g, "");
  return flat.length > length ? `${flat.slice(0, length).trim()}…` : flat;
}

export function EntryCard({ entry }: EntryCardProps) {
  const emoji = moodEmoji(entry.mood);

  return (
    <Link href={`/journal/${entry.id}`}>
      <Card className="flex flex-col gap-2 transition-colors hover:bg-white/[0.03]">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {emoji && <span className="text-base">{emoji}</span>}
            <h3 className="truncate font-display text-sm font-medium text-text-primary">
              {entry.title || "Untitled entry"}
            </h3>
          </div>
          <span className="shrink-0 font-mono text-xs text-text-secondary">
            {new Date(entry.entry_date).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
            })}
          </span>
        </div>
        {snippet(entry.body) && (
          <p className="line-clamp-2 text-sm text-text-secondary">{snippet(entry.body)}</p>
        )}
      </Card>
    </Link>
  );
}
