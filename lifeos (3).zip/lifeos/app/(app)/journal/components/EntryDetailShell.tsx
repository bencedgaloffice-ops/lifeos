"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Pencil, Trash2, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { createClient } from "@/lib/supabase/client";
import { RichText } from "./RichText";
import { EntryModal } from "./EntryModal";
import { moodEmoji, moodLabel } from "../moods";
import type { JournalEntry } from "../types";

interface EntryDetailShellProps {
  initialEntry: JournalEntry;
}

export function EntryDetailShell({ initialEntry }: EntryDetailShellProps) {
  const router = useRouter();
  const [entry, setEntry] = useState(initialEntry);
  const [editing, setEditing] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("journal_entries").delete().eq("id", entry.id);
    setDeleting(false);
    if (!error) {
      router.push("/journal");
      router.refresh();
    }
  };

  const emoji = moodEmoji(entry.mood);

  return (
    <div className="space-y-6">
      <Link
        href="/journal"
        className="inline-flex items-center gap-1.5 text-xs text-text-secondary hover:text-text-primary"
      >
        <ArrowLeft size={14} />
        Back to journal
      </Link>

      <PageHeader
        title={entry.title || "Untitled entry"}
        description={new Date(entry.entry_date).toLocaleDateString("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric",
        })}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => setEditing(true)}>
              <Pencil size={14} className="mr-1.5" />
              Edit
            </Button>
            {confirmingDelete ? (
              <div className="flex items-center gap-2">
                <Button variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm delete"}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <Button variant="ghost" size="sm" onClick={() => setConfirmingDelete(true)}>
                <Trash2 size={14} className="mr-1.5" />
                Delete
              </Button>
            )}
          </div>
        }
      />

      {entry.mood && (
        <p className="text-sm text-text-secondary">
          {emoji} Feeling {moodLabel(entry.mood)}
        </p>
      )}

      <Card>
        {entry.body ? (
          <RichText text={entry.body} className="text-sm text-text-primary" />
        ) : (
          <p className="text-sm text-text-secondary">No content yet.</p>
        )}
      </Card>

      {editing && (
        <EntryModal
          mode="edit"
          entry={entry}
          onClose={() => setEditing(false)}
          onSaved={(saved) => {
            setEntry(saved);
            setEditing(false);
          }}
          onDeleted={() => {
            router.push("/journal");
            router.refresh();
          }}
        />
      )}
    </div>
  );
}
