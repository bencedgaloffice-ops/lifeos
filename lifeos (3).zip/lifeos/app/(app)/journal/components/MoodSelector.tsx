import { cn } from "@/lib/utils/cn";
import { MOODS } from "../moods";

interface MoodSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export function MoodSelector({ value, onChange }: MoodSelectorProps) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {MOODS.map((mood) => (
        <button
          key={mood.value}
          type="button"
          onClick={() => onChange(value === mood.value ? "" : mood.value)}
          aria-pressed={value === mood.value}
          className={cn(
            "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-colors",
            value === mood.value
              ? "border-accent bg-accent-soft text-accent"
              : "border-border-subtle text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
          )}
        >
          <span>{mood.emoji}</span>
          {mood.label}
        </button>
      ))}
    </div>
  );
}
