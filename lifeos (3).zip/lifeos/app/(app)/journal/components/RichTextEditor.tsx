"use client";

import { forwardRef, useRef, useImperativeHandle } from "react";
import { Bold, Italic, List } from "lucide-react";
import { cn } from "@/lib/utils/cn";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

/**
 * Plain <textarea> plus a toolbar that wraps the current selection in
 * markdown-lite syntax (**bold**, *italic*, "- " list) — no editor
 * library. RichText.tsx renders this same syntax back out elsewhere.
 */
export const RichTextEditor = forwardRef<HTMLTextAreaElement, RichTextEditorProps>(
  ({ value, onChange, placeholder }, forwardedRef) => {
    const innerRef = useRef<HTMLTextAreaElement>(null);
    useImperativeHandle(forwardedRef, () => innerRef.current as HTMLTextAreaElement);

    const wrapSelection = (before: string, after: string = before) => {
      const el = innerRef.current;
      if (!el) return;
      const { selectionStart, selectionEnd } = el;
      const selected = value.slice(selectionStart, selectionEnd);
      const next =
        value.slice(0, selectionStart) + before + selected + after + value.slice(selectionEnd);
      onChange(next);
      requestAnimationFrame(() => {
        el.focus();
        el.setSelectionRange(selectionStart + before.length, selectionEnd + before.length);
      });
    };

    const insertBullet = () => {
      const el = innerRef.current;
      if (!el) return;
      const { selectionStart } = el;
      const needsNewline = selectionStart > 0 && value[selectionStart - 1] !== "\n";
      const prefix = needsNewline ? "\n- " : "- ";
      const next = value.slice(0, selectionStart) + prefix + value.slice(selectionStart);
      onChange(next);
      requestAnimationFrame(() => {
        el.focus();
        const pos = selectionStart + prefix.length;
        el.setSelectionRange(pos, pos);
      });
    };

    return (
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => wrapSelection("**")}
            aria-label="Bold"
            className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <Bold size={14} />
          </button>
          <button
            type="button"
            onClick={() => wrapSelection("*")}
            aria-label="Italic"
            className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <Italic size={14} />
          </button>
          <button
            type="button"
            onClick={insertBullet}
            aria-label="Bullet list"
            className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <List size={14} />
          </button>
        </div>
        <textarea
          ref={innerRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={10}
          className={cn(
            "w-full rounded-card border border-border-subtle bg-glass px-3 py-2 text-sm leading-relaxed text-text-primary placeholder:text-text-secondary",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          )}
        />
      </div>
    );
  }
);
RichTextEditor.displayName = "RichTextEditor";
