"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { JournalFilters } from "./JournalFilters";
import { EntryTimeline } from "./EntryTimeline";
import { EntryModal } from "./EntryModal";
import type { JournalEntry } from "../types";

interface JournalShellProps {
  initialEntries: JournalEntry[];
}

type ModalState = { mode: "closed" } | { mode: "create" };

export function JournalShell({ initialEntries }: JournalShellProps) {
  const [entries, setEntries] = useState(initialEntries);
  const [search, setSearch] = useState("");
  const [mood, setMood] = useState("");
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  const filteredEntries = useMemo(() => {
    const query = search.trim().toLowerCase();
    return entries.filter((entry) => {
      if (mood && entry.mood !== mood) return false;
      if (query) {
        const haystack = `${entry.title ?? ""} ${entry.body ?? ""}`.toLowerCase();
        if (!haystack.includes(query)) return false;
      }
      return true;
    });
  }, [entries, search, mood]);

  const handleSaved = (saved: JournalEntry) => {
    setEntries((prev) =>
      [saved, ...prev].sort(
        (a, b) => new Date(b.entry_date).getTime() - new Date(a.entry_date).getTime()
      )
    );
    setModal({ mode: "closed" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Journal"
        description="Memories, reflection, and lessons learned — your life story archive."
        actions={
          <Button size="sm" onClick={() => setModal({ mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            New entry
          </Button>
        }
      />

      <JournalFilters search={search} onSearchChange={setSearch} mood={mood} onMoodChange={setMood} />

      <EntryTimeline
        entries={filteredEntries}
        onCreate={() => setModal({ mode: "create" })}
        hasAnyEntries={entries.length > 0}
      />

      {modal.mode === "create" && (
        <EntryModal
          mode="create"
          onClose={() => setModal({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={() => setModal({ mode: "closed" })}
        />
      )}
    </div>
  );
}
