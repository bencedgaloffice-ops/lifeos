import { Fragment, type ReactNode } from "react";

/**
 * Deliberately not a WYSIWYG editor or markdown library — "rich text
 * without heavy dependencies" means a small hand-rolled renderer for
 * a minimal, predictable syntax: **bold**, *italic*, blank-line
 * paragraphs, and "- " bullet lists. EntryModal's toolbar inserts
 * this exact syntax into the plain textarea; this component renders
 * it back out on the detail/list views.
 */

function renderInline(text: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const pattern = /(\*\*[^*]+\*\*|\*[^*]+\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let key = 0;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(<Fragment key={key++}>{text.slice(lastIndex, match.index)}</Fragment>);
    }
    const token = match[0];
    if (token.startsWith("**")) {
      nodes.push(<strong key={key++}>{token.slice(2, -2)}</strong>);
    } else {
      nodes.push(<em key={key++}>{token.slice(1, -1)}</em>);
    }
    lastIndex = match.index + token.length;
  }
  if (lastIndex < text.length) {
    nodes.push(<Fragment key={key++}>{text.slice(lastIndex)}</Fragment>);
  }
  return nodes;
}

interface RichTextProps {
  text: string;
  className?: string;
}

export function RichText({ text, className }: RichTextProps) {
  if (!text.trim()) return null;

  const blocks = text.split(/\n{2,}/);

  return (
    <div className={className}>
      {blocks.map((block, i) => {
        const lines = block.split("\n").filter((l) => l.length > 0);
        const isList = lines.every((l) => l.trim().startsWith("- "));

        if (isList) {
          return (
            <ul key={i} className="mb-4 list-disc space-y-1 pl-5">
              {lines.map((line, j) => (
                <li key={j}>{renderInline(line.trim().slice(2))}</li>
              ))}
            </ul>
          );
        }

        return (
          <p key={i} className="mb-4 whitespace-pre-wrap leading-relaxed last:mb-0">
            {lines.map((line, j) => (
              <Fragment key={j}>
                {j > 0 && <br />}
                {renderInline(line)}
              </Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
}
