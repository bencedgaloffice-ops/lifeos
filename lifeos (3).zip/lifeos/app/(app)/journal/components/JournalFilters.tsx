import { Search } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { cn } from "@/lib/utils/cn";
import { MOODS } from "../moods";

interface JournalFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  mood: string;
  onMoodChange: (value: string) => void;
}

export function JournalFilters({ search, onSearchChange, mood, onMoodChange }: JournalFiltersProps) {
  return (
    <div className="flex flex-col gap-3">
      <div className="relative sm:max-w-sm">
        <Search
          size={14}
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary"
        />
        <Input
          placeholder="Search entries…"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-8"
        />
      </div>

      <div className="flex flex-wrap gap-1.5">
        <button
          onClick={() => onMoodChange("")}
          className={cn(
            "rounded-full border px-2.5 py-1 text-xs transition-colors",
            mood === ""
              ? "border-accent bg-accent-soft text-accent"
              : "border-border-subtle text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
          )}
        >
          All moods
        </button>
        {MOODS.map((m) => (
          <button
            key={m.value}
            onClick={() => onMoodChange(mood === m.value ? "" : m.value)}
            className={cn(
              "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-colors",
              mood === m.value
                ? "border-accent bg-accent-soft text-accent"
                : "border-border-subtle text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
            )}
          >
            <span>{m.emoji}</span>
            {m.label}
          </button>
        ))}
      </div>
    </div>
  );
}
