"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { toDateInputValue } from "@/lib/utils/date";
import {
  journalEntryFormSchema,
  type JournalEntryFormInput,
} from "@/lib/validations/journal";
import { MoodSelector } from "./MoodSelector";
import { RichTextEditor } from "./RichTextEditor";
import type { JournalEntry } from "../types";

interface EntryModalProps {
  mode: "create" | "edit";
  entry?: JournalEntry;
  onClose: () => void;
  onSaved: (entry: JournalEntry) => void;
  onDeleted: () => void;
}

export function EntryModal({ mode, entry, onClose, onSaved, onDeleted }: EntryModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<JournalEntryFormInput>({
    resolver: zodResolver(journalEntryFormSchema),
    defaultValues: entry
      ? {
          title: entry.title ?? "",
          body: entry.body ?? "",
          mood: entry.mood ?? "",
          entryDate: entry.entry_date,
        }
      : {
          title: "",
          body: "",
          mood: "",
          entryDate: toDateInputValue(new Date()),
        },
  });

  const onSubmit = async (data: JournalEntryFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      title: data.title || null,
      body: data.body || null,
      mood: data.mood || null,
      entry_date: data.entryDate,
    };

    const { data: saved, error } =
      mode === "edit" && entry
        ? await supabase.from("journal_entries").update(payload).eq("id", entry.id).select().single()
        : await supabase.from("journal_entries").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!entry) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("journal_entries").delete().eq("id", entry.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={mode === "create" ? "New entry" : "Edit entry"}
      className="max-w-lg"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <div className="grid grid-cols-2 gap-3">
          <Input placeholder="Title (optional)" {...register("title")} />
          <Input type="date" error={errors.entryDate?.message} {...register("entryDate")} />
        </div>

        <Controller
          name="mood"
          control={control}
          render={({ field }) => <MoodSelector value={field.value ?? ""} onChange={field.onChange} />}
        />

        <Controller
          name="body"
          control={control}
          render={({ field }) => (
            <RichTextEditor
              value={field.value ?? ""}
              onChange={field.onChange}
              placeholder="What's on your mind? What did you learn today?"
            />
          )}
        />

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this entry?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Save entry"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
