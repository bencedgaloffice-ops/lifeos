import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { EntryCard } from "./EntryCard";
import type { JournalEntry } from "../types";

interface EntryTimelineProps {
  entries: JournalEntry[];
  onCreate: () => void;
  hasAnyEntries: boolean;
}

function monthLabel(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-US", { month: "long", year: "numeric" });
}

export function EntryTimeline({ entries, onCreate, hasAnyEntries }: EntryTimelineProps) {
  if (entries.length === 0) {
    return (
      <EmptyState
        title={hasAnyEntries ? "No entries match your filters" : "Your journal is empty"}
        description={
          hasAnyEntries
            ? "Try adjusting your search or mood filter."
            : "Start your life story archive — memories, reflection, lessons learned."
        }
        action={
          !hasAnyEntries && (
            <Button size="sm" onClick={onCreate}>
              <Plus size={14} className="mr-1.5" />
              Write your first entry
            </Button>
          )
        }
      />
    );
  }

  const groups: { label: string; entries: JournalEntry[] }[] = [];
  entries.forEach((entry) => {
    const label = monthLabel(entry.entry_date);
    const group = groups.find((g) => g.label === label);
    if (group) group.entries.push(entry);
    else groups.push({ label, entries: [entry] });
  });

  return (
    <div className="space-y-8">
      {groups.map((group) => (
        <div key={group.label}>
          <p className="mb-3 font-mono text-xs uppercase tracking-wider text-text-secondary">
            {group.label}
          </p>
          <div className="space-y-3">
            {group.entries.map((entry) => (
              <EntryCard key={entry.id} entry={entry} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
