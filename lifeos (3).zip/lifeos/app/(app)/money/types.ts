import type { Database } from "@/types/supabase";

export type Account = Database["public"]["Tables"]["accounts"]["Row"];
export type BudgetCategory = Database["public"]["Tables"]["budget_categories"]["Row"];
export type Transaction = Database["public"]["Tables"]["transactions"]["Row"];
export type RecurringTransaction =
  Database["public"]["Tables"]["recurring_transactions"]["Row"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];
export type MoneyTab = "overview" | "transactions" | "budgets" | "recurring" | "accounts";
