import { createClient } from "@/lib/supabase/server";
import { MoneyShell } from "./components/MoneyShell";

/**
 * Server component: fetches everything Money needs for a fast first
 * paint (accounts, budget categories, this-month transactions, recent
 * transactions, recurring transactions, life areas). MoneyShell takes
 * over client-side for all create/edit/delete and tab navigation.
 */
export default async function MoneyPage() {
  const supabase = await createClient();

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString();

  const [
    { data: accounts },
    { data: budgetCategories },
    { data: monthTransactions },
    { data: recentTransactions },
    { data: recurring },
    { data: lifeAreas },
  ] = await Promise.all([
    supabase.from("accounts").select("*").order("created_at", { ascending: true }),
    supabase.from("budget_categories").select("*").order("name", { ascending: true }),
    supabase
      .from("transactions")
      .select("*")
      .gte("occurred_at", monthStart)
      .lt("occurred_at", monthEnd)
      .order("occurred_at", { ascending: false }),
    supabase
      .from("transactions")
      .select("*")
      .order("occurred_at", { ascending: false })
      .limit(15),
    supabase.from("recurring_transactions").select("*").order("next_date", { ascending: true }),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
  ]);

  return (
    <MoneyShell
      initialAccounts={accounts ?? []}
      initialBudgetCategories={budgetCategories ?? []}
      initialMonthTransactions={monthTransactions ?? []}
      initialRecentTransactions={recentTransactions ?? []}
      initialRecurring={recurring ?? []}
      lifeAreas={lifeAreas ?? []}
    />
  );
}
