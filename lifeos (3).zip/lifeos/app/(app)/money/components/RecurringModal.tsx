"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { toDateInputValue } from "@/lib/utils/date";
import { recurringFormSchema, type RecurringFormInput } from "@/lib/validations/money";
import { SelectField } from "./SelectField";
import type { Account, RecurringTransaction } from "../types";

interface RecurringModalProps {
  mode: "create" | "edit";
  recurring?: RecurringTransaction;
  accounts: Account[];
  onClose: () => void;
  onSaved: () => void;
  onDeleted: () => void;
}

function buildDefaultValues(accounts: Account[], recurring?: RecurringTransaction): RecurringFormInput {
  if (recurring) {
    return {
      accountId: recurring.account_id,
      name: recurring.name,
      amount: recurring.amount,
      type: recurring.type,
      category: recurring.category ?? "",
      frequency: recurring.frequency,
      nextDate: toDateInputValue(new Date(recurring.next_date)),
      active: recurring.active,
    };
  }
  return {
    accountId: accounts[0]?.id ?? "",
    name: "",
    amount: 0,
    type: "expense",
    category: "",
    frequency: "monthly",
    nextDate: toDateInputValue(new Date()),
    active: true,
  };
}

export function RecurringModal({
  mode,
  recurring,
  accounts,
  onClose,
  onSaved,
  onDeleted,
}: RecurringModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<RecurringFormInput>({
    resolver: zodResolver(recurringFormSchema),
    defaultValues: buildDefaultValues(accounts, recurring),
  });

  const onSubmit = async (data: RecurringFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      account_id: data.accountId,
      name: data.name,
      amount: data.amount,
      type: data.type,
      category: data.category || null,
      frequency: data.frequency,
      next_date: data.nextDate,
      active: data.active,
    };

    const { error } =
      mode === "edit" && recurring
        ? await supabase.from("recurring_transactions").update(payload).eq("id", recurring.id)
        : await supabase.from("recurring_transactions").insert(payload);

    if (error) {
      setSaveError(error.message);
      return;
    }
    onSaved();
  };

  const handleDelete = async () => {
    if (!recurring) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase
      .from("recurring_transactions")
      .delete()
      .eq("id", recurring.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New recurring item" : "Edit recurring item"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Name (e.g. Salary, Rent)" error={errors.name?.message} {...register("name")} />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="type"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </SelectField>
            )}
          />
          <Input
            type="number"
            step="0.01"
            placeholder="Amount"
            error={errors.amount?.message}
            {...register("amount")}
          />
        </div>

        <Controller
          name="accountId"
          control={control}
          render={({ field }) => (
            <SelectField {...field}>
              {accounts.length === 0 && <option value="">No accounts yet</option>}
              {accounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </SelectField>
          )}
        />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="frequency"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="yearly">Yearly</option>
              </SelectField>
            )}
          />
          <Input type="date" error={errors.nextDate?.message} {...register("nextDate")} />
        </div>

        <Input placeholder="Category (optional)" {...register("category")} />

        <label className="flex items-center gap-2 text-sm text-text-secondary">
          <input type="checkbox" className="accent-[--accent]" {...register("active")} />
          Active
        </label>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this item?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting || accounts.length === 0}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create recurring item"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
