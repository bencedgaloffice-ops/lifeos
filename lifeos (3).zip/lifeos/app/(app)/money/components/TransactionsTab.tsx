import { Plus } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Tag } from "@/components/ui/Tag";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency } from "@/lib/utils/currency";
import type { Transaction, LifeArea } from "../types";

interface TransactionsTabProps {
  transactions: Transaction[];
  lifeAreaById: Map<string, LifeArea>;
  onAdd: () => void;
  onEdit: (transaction: Transaction) => void;
}

export function TransactionsTab({
  transactions,
  lifeAreaById,
  onAdd,
  onEdit,
}: TransactionsTabProps) {
  return (
    <Card className="p-0">
      <div className="flex items-center justify-between p-4">
        <h3 className="font-display text-sm font-medium text-text-primary">
          Recent transactions
        </h3>
        <Button variant="secondary" size="sm" onClick={onAdd}>
          <Plus size={14} className="mr-1.5" />
          Log transaction
        </Button>
      </div>

      {transactions.length === 0 ? (
        <p className="p-4 pt-0 text-sm text-text-secondary">
          No transactions logged yet.
        </p>
      ) : (
        <div className="divide-y divide-border-subtle">
          {transactions.map((tx) => {
            const lifeArea = tx.life_area_id ? lifeAreaById.get(tx.life_area_id) : undefined;
            return (
              <button
                key={tx.id}
                onClick={() => onEdit(tx)}
                className="flex w-full items-center justify-between gap-4 p-4 text-left transition-colors hover:bg-white/[0.02]"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-text-primary">
                    {tx.description || "Untitled transaction"}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <span className="font-mono text-xs text-text-secondary">
                      {new Date(tx.occurred_at).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                    {lifeArea && <Tag color={lifeArea.color ?? undefined}>{lifeArea.name}</Tag>}
                  </div>
                </div>
                <Badge variant={tx.direction === "income" ? "success" : "neutral"}>
                  {tx.direction === "income" ? "+" : "−"}
                  {formatCurrency(tx.amount, tx.currency)}
                </Badge>
              </button>
            );
          })}
        </div>
      )}
    </Card>
  );
}
