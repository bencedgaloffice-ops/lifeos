"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { accountFormSchema, type AccountFormInput } from "@/lib/validations/money";
import { SelectField } from "./SelectField";
import type { Account } from "../types";

interface AccountModalProps {
  mode: "create" | "edit";
  account?: Account;
  onClose: () => void;
  onSaved: () => void;
  onDeleted: () => void;
}

export function AccountModal({ mode, account, onClose, onSaved, onDeleted }: AccountModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<AccountFormInput>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: account
      ? {
          name: account.name,
          type: account.type ?? "checking",
          currency: account.currency,
          currentBalance: account.current_balance,
        }
      : { name: "", type: "checking", currency: "HUF", currentBalance: 0 },
  });

  const onSubmit = async (data: AccountFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      name: data.name,
      type: data.type,
      currency: data.currency,
      current_balance: data.currentBalance,
    };

    const { error } =
      mode === "edit" && account
        ? await supabase.from("accounts").update(payload).eq("id", account.id)
        : await supabase.from("accounts").insert(payload);

    if (error) {
      setSaveError(error.message);
      return;
    }
    onSaved();
  };

  const handleDelete = async () => {
    if (!account) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("accounts").delete().eq("id", account.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New account" : "Edit account"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Account name" error={errors.name?.message} {...register("name")} />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="type"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="checking">Checking</option>
                <option value="savings">Savings</option>
                <option value="cash">Cash</option>
                <option value="other">Other</option>
              </SelectField>
            )}
          />
          <Input placeholder="Currency (e.g. HUF)" {...register("currency")} />
        </div>

        <Input
          type="number"
          step="0.01"
          placeholder="Current balance"
          error={errors.currentBalance?.message}
          {...register("currentBalance")}
        />

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this account?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create account"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
