"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import {
  budgetCategoryFormSchema,
  type BudgetCategoryFormInput,
} from "@/lib/validations/money";
import type { BudgetCategory } from "../types";

interface BudgetCategoryModalProps {
  mode: "create" | "edit";
  category?: BudgetCategory;
  onClose: () => void;
  onSaved: () => void;
  onDeleted: () => void;
}

export function BudgetCategoryModal({
  mode,
  category,
  onClose,
  onSaved,
  onDeleted,
}: BudgetCategoryModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<BudgetCategoryFormInput>({
    resolver: zodResolver(budgetCategoryFormSchema),
    defaultValues: category
      ? {
          name: category.name,
          monthlyLimit: category.monthly_limit ?? undefined,
          currency: category.currency,
        }
      : { name: "", monthlyLimit: undefined, currency: "HUF" },
  });

  const onSubmit = async (data: BudgetCategoryFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      name: data.name,
      monthly_limit: data.monthlyLimit ?? null,
      currency: data.currency,
    };

    const { error } =
      mode === "edit" && category
        ? await supabase.from("budget_categories").update(payload).eq("id", category.id)
        : await supabase.from("budget_categories").insert(payload);

    if (error) {
      setSaveError(error.message);
      return;
    }
    onSaved();
  };

  const handleDelete = async () => {
    if (!category) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("budget_categories").delete().eq("id", category.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New budget category" : "Edit category"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Category name" error={errors.name?.message} {...register("name")} />
        <div className="grid grid-cols-2 gap-3">
          <Input
            type="number"
            step="0.01"
            placeholder="Monthly limit (optional)"
            error={errors.monthlyLimit?.message}
            {...register("monthlyLimit")}
          />
          <Input placeholder="Currency" {...register("currency")} />
        </div>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this category?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create category"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
