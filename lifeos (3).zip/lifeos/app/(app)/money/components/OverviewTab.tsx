import { Plus } from "lucide-react";
import { StatCard } from "@/components/ui/StatCard";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { formatCurrency } from "@/lib/utils/currency";
import type { Account, Transaction } from "../types";

interface OverviewTabProps {
  accounts: Account[];
  monthTransactions: Transaction[];
  onAddAccount: () => void;
  onEditAccount: (account: Account) => void;
}

export function OverviewTab({
  accounts,
  monthTransactions,
  onAddAccount,
  onEditAccount,
}: OverviewTabProps) {
  const totalBalance = accounts.reduce((sum, a) => sum + a.current_balance, 0);
  const monthIncome = monthTransactions
    .filter((t) => t.direction === "income")
    .reduce((sum, t) => sum + t.amount, 0);
  const monthExpense = monthTransactions
    .filter((t) => t.direction === "expense")
    .reduce((sum, t) => sum + t.amount, 0);
  const net = monthIncome - monthExpense;

  const primaryCurrency = accounts[0]?.currency ?? "HUF";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Total balance" value={formatCurrency(totalBalance, primaryCurrency)} />
        <StatCard
          label="This month"
          value={formatCurrency(net, primaryCurrency)}
          delta={net >= 0 ? "Net positive" : "Net negative"}
          trend={net >= 0 ? "up" : "down"}
        />
        <StatCard
          label="Spent this month"
          value={formatCurrency(monthExpense, primaryCurrency)}
          delta={`Income ${formatCurrency(monthIncome, primaryCurrency)}`}
          trend="neutral"
        />
      </div>

      <Card>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-sm font-medium text-text-primary">Accounts</h3>
          <Button variant="secondary" size="sm" onClick={onAddAccount}>
            <Plus size={14} className="mr-1.5" />
            Add account
          </Button>
        </div>

        {accounts.length === 0 ? (
          <p className="text-sm text-text-secondary">
            No accounts yet — add one to start logging transactions.
          </p>
        ) : (
          <div className="divide-y divide-border-subtle">
            {accounts.map((account) => (
              <button
                key={account.id}
                onClick={() => onEditAccount(account)}
                className="flex w-full items-center justify-between py-3 text-left transition-opacity hover:opacity-80"
              >
                <div>
                  <p className="text-sm text-text-primary">{account.name}</p>
                  <p className="text-xs capitalize text-text-secondary">{account.type}</p>
                </div>
                <p className="font-mono text-sm text-text-primary">
                  {formatCurrency(account.current_balance, account.currency)}
                </p>
              </button>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
