"use client";

import { useCallback, useMemo, useState } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { createClient } from "@/lib/supabase/client";
import { MoneyTabs } from "./MoneyTabs";
import { OverviewTab } from "./OverviewTab";
import { TransactionsTab } from "./TransactionsTab";
import { BudgetsTab } from "./BudgetsTab";
import { RecurringTab } from "./RecurringTab";
import { AccountsTab } from "./AccountsTab";
import { AccountModal } from "./AccountModal";
import { TransactionModal } from "./TransactionModal";
import { BudgetCategoryModal } from "./BudgetCategoryModal";
import { RecurringModal } from "./RecurringModal";
import type {
  Account,
  BudgetCategory,
  Transaction,
  RecurringTransaction,
  LifeArea,
  MoneyTab,
} from "../types";

interface MoneyShellProps {
  initialAccounts: Account[];
  initialBudgetCategories: BudgetCategory[];
  initialMonthTransactions: Transaction[];
  initialRecentTransactions: Transaction[];
  initialRecurring: RecurringTransaction[];
  lifeAreas: LifeArea[];
}

type ModalState =
  | { type: "closed" }
  | { type: "account"; mode: "create" | "edit"; account?: Account }
  | { type: "transaction"; mode: "create" | "edit"; transaction?: Transaction }
  | { type: "budget"; mode: "create" | "edit"; category?: BudgetCategory }
  | { type: "recurring"; mode: "create" | "edit"; recurring?: RecurringTransaction };

export function MoneyShell({
  initialAccounts,
  initialBudgetCategories,
  initialMonthTransactions,
  initialRecentTransactions,
  initialRecurring,
  lifeAreas,
}: MoneyShellProps) {
  const [tab, setTab] = useState<MoneyTab>("overview");
  const [accounts, setAccounts] = useState(initialAccounts);
  const [budgetCategories, setBudgetCategories] = useState(initialBudgetCategories);
  const [monthTransactions, setMonthTransactions] = useState(initialMonthTransactions);
  const [recentTransactions, setRecentTransactions] = useState(initialRecentTransactions);
  const [recurring, setRecurring] = useState(initialRecurring);
  const [modal, setModal] = useState<ModalState>({ type: "closed" });

  const lifeAreaById = useMemo(() => {
    const map = new Map<string, LifeArea>();
    lifeAreas.forEach((area) => map.set(area.id, area));
    return map;
  }, [lifeAreas]);

  const refetchAll = useCallback(async () => {
    const supabase = createClient();
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString();

    const [
      { data: accountsData },
      { data: budgetData },
      { data: monthData },
      { data: recentData },
      { data: recurringData },
    ] = await Promise.all([
      supabase.from("accounts").select("*").order("created_at", { ascending: true }),
      supabase.from("budget_categories").select("*").order("name", { ascending: true }),
      supabase
        .from("transactions")
        .select("*")
        .gte("occurred_at", monthStart)
        .lt("occurred_at", monthEnd)
        .order("occurred_at", { ascending: false }),
      supabase.from("transactions").select("*").order("occurred_at", { ascending: false }).limit(15),
      supabase.from("recurring_transactions").select("*").order("next_date", { ascending: true }),
    ]);

    if (accountsData) setAccounts(accountsData);
    if (budgetData) setBudgetCategories(budgetData);
    if (monthData) setMonthTransactions(monthData);
    if (recentData) setRecentTransactions(recentData);
    if (recurringData) setRecurring(recurringData);
  }, []);

  const closeAndRefetch = () => {
    setModal({ type: "closed" });
    refetchAll();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Money"
        description="Accounts, spending, budgets, and recurring items in one place."
      />

      <MoneyTabs tab={tab} onChange={setTab} />

      {tab === "overview" && (
        <OverviewTab
          accounts={accounts}
          monthTransactions={monthTransactions}
          onAddAccount={() => setModal({ type: "account", mode: "create" })}
          onEditAccount={(account) => setModal({ type: "account", mode: "edit", account })}
        />
      )}
      {tab === "transactions" && (
        <TransactionsTab
          transactions={recentTransactions}
          lifeAreaById={lifeAreaById}
          onAdd={() => setModal({ type: "transaction", mode: "create" })}
          onEdit={(transaction) => setModal({ type: "transaction", mode: "edit", transaction })}
        />
      )}
      {tab === "budgets" && (
        <BudgetsTab
          categories={budgetCategories}
          monthTransactions={monthTransactions}
          onAdd={() => setModal({ type: "budget", mode: "create" })}
          onEdit={(category) => setModal({ type: "budget", mode: "edit", category })}
        />
      )}
      {tab === "recurring" && (
        <RecurringTab
          items={recurring}
          onAdd={() => setModal({ type: "recurring", mode: "create" })}
          onEdit={(item) => setModal({ type: "recurring", mode: "edit", recurring: item })}
        />
      )}
      {tab === "accounts" && (
        <AccountsTab
          accounts={accounts}
          onAdd={() => setModal({ type: "account", mode: "create" })}
          onEdit={(account) => setModal({ type: "account", mode: "edit", account })}
        />
      )}

      {modal.type === "account" && (
        <AccountModal
          mode={modal.mode}
          account={modal.account}
          onClose={() => setModal({ type: "closed" })}
          onSaved={closeAndRefetch}
          onDeleted={closeAndRefetch}
        />
      )}
      {modal.type === "transaction" && (
        <TransactionModal
          mode={modal.mode}
          transaction={modal.transaction}
          accounts={accounts}
          budgetCategories={budgetCategories}
          lifeAreas={lifeAreas}
          onClose={() => setModal({ type: "closed" })}
          onSaved={closeAndRefetch}
          onDeleted={closeAndRefetch}
        />
      )}
      {modal.type === "budget" && (
        <BudgetCategoryModal
          mode={modal.mode}
          category={modal.category}
          onClose={() => setModal({ type: "closed" })}
          onSaved={closeAndRefetch}
          onDeleted={closeAndRefetch}
        />
      )}
      {modal.type === "recurring" && (
        <RecurringModal
          mode={modal.mode}
          recurring={modal.recurring}
          accounts={accounts}
          onClose={() => setModal({ type: "closed" })}
          onSaved={closeAndRefetch}
          onDeleted={closeAndRefetch}
        />
      )}
    </div>
  );
}
