"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { toDateInputValue } from "@/lib/utils/date";
import {
  transactionFormSchema,
  type TransactionFormInput,
} from "@/lib/validations/money";
import { SelectField } from "./SelectField";
import type { Account, BudgetCategory, LifeArea, Transaction } from "../types";

interface TransactionModalProps {
  mode: "create" | "edit";
  transaction?: Transaction;
  accounts: Account[];
  budgetCategories: BudgetCategory[];
  lifeAreas: LifeArea[];
  onClose: () => void;
  onSaved: () => void;
  onDeleted: () => void;
}

function buildDefaultValues(
  accounts: Account[],
  transaction?: Transaction
): TransactionFormInput {
  if (transaction) {
    return {
      accountId: transaction.account_id,
      categoryId: transaction.category_id ?? "",
      lifeAreaId: transaction.life_area_id ?? "",
      direction: transaction.direction,
      amount: transaction.amount,
      currency: transaction.currency,
      description: transaction.description ?? "",
      occurredAt: toDateInputValue(new Date(transaction.occurred_at)),
    };
  }
  return {
    accountId: accounts[0]?.id ?? "",
    categoryId: "",
    lifeAreaId: "",
    direction: "expense",
    amount: 0,
    currency: accounts[0]?.currency ?? "HUF",
    description: "",
    occurredAt: toDateInputValue(new Date()),
  };
}

export function TransactionModal({
  mode,
  transaction,
  accounts,
  budgetCategories,
  lifeAreas,
  onClose,
  onSaved,
  onDeleted,
}: TransactionModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<TransactionFormInput>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: buildDefaultValues(accounts, transaction),
  });

  const onSubmit = async (data: TransactionFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      account_id: data.accountId,
      category_id: data.categoryId || null,
      life_area_id: data.lifeAreaId || null,
      direction: data.direction,
      amount: data.amount,
      currency: data.currency,
      description: data.description || null,
      occurred_at: new Date(data.occurredAt).toISOString(),
    };

    const { error } =
      mode === "edit" && transaction
        ? await supabase.from("transactions").update(payload).eq("id", transaction.id)
        : await supabase.from("transactions").insert(payload);

    if (error) {
      setSaveError(error.message);
      return;
    }
    onSaved();
  };

  const handleDelete = async () => {
    if (!transaction) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("transactions").delete().eq("id", transaction.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "Log transaction" : "Edit transaction"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="direction"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </SelectField>
            )}
          />
          <Input
            type="number"
            step="0.01"
            placeholder="Amount"
            error={errors.amount?.message}
            {...register("amount")}
          />
        </div>

        <Controller
          name="accountId"
          control={control}
          render={({ field }) => (
            <SelectField {...field} aria-invalid={!!errors.accountId}>
              {accounts.length === 0 && <option value="">No accounts yet</option>}
              {accounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </SelectField>
          )}
        />
        {errors.accountId && (
          <p className="-mt-2 text-xs text-danger">{errors.accountId.message}</p>
        )}

        <Controller
          name="categoryId"
          control={control}
          render={({ field }) => (
            <SelectField {...field}>
              <option value="">No budget category</option>
              {budgetCategories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </SelectField>
          )}
        />

        <Controller
          name="lifeAreaId"
          control={control}
          render={({ field }) => (
            <SelectField {...field}>
              <option value="">No life area</option>
              {lifeAreas.map((area) => (
                <option key={area.id} value={area.id}>
                  {area.name}
                </option>
              ))}
            </SelectField>
          )}
        />

        <Input type="date" error={errors.occurredAt?.message} {...register("occurredAt")} />
        <Input placeholder="Description (optional)" {...register("description")} />

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this transaction?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting || accounts.length === 0}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Log transaction"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
