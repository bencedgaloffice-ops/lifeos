import { cn } from "@/lib/utils/cn";
import type { MoneyTab } from "../types";

const TABS: { value: MoneyTab; label: string }[] = [
  { value: "overview", label: "Overview" },
  { value: "transactions", label: "Transactions" },
  { value: "budgets", label: "Budgets" },
  { value: "recurring", label: "Recurring" },
  { value: "accounts", label: "Accounts" },
];

interface MoneyTabsProps {
  tab: MoneyTab;
  onChange: (tab: MoneyTab) => void;
}

export function MoneyTabs({ tab, onChange }: MoneyTabsProps) {
  return (
    <div className="inline-flex overflow-hidden rounded-card border border-border-subtle text-sm">
      {TABS.map((t) => (
        <button
          key={t.value}
          onClick={() => onChange(t.value)}
          aria-pressed={tab === t.value}
          className={cn(
            "px-3 py-1.5 transition-colors",
            tab === t.value
              ? "bg-accent-soft text-accent"
              : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
