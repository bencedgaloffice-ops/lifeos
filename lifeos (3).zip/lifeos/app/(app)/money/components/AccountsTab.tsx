import { Plus } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency } from "@/lib/utils/currency";
import type { Account } from "../types";

interface AccountsTabProps {
  accounts: Account[];
  onAdd: () => void;
  onEdit: (account: Account) => void;
}

export function AccountsTab({ accounts, onAdd, onEdit }: AccountsTabProps) {
  return (
    <Card className="p-0">
      <div className="flex items-center justify-between p-4">
        <h3 className="font-display text-sm font-medium text-text-primary">Accounts</h3>
        <Button variant="secondary" size="sm" onClick={onAdd}>
          <Plus size={14} className="mr-1.5" />
          Add account
        </Button>
      </div>

      {accounts.length === 0 ? (
        <p className="p-4 pt-0 text-sm text-text-secondary">
          No accounts yet — add one to start logging transactions.
        </p>
      ) : (
        <div className="divide-y divide-border-subtle">
          {accounts.map((account) => (
            <button
              key={account.id}
              onClick={() => onEdit(account)}
              className="flex w-full items-center justify-between p-4 text-left transition-colors hover:bg-white/[0.02]"
            >
              <div className="flex items-center gap-2">
                <p className="text-sm text-text-primary">{account.name}</p>
                <Badge variant="neutral">{account.type}</Badge>
              </div>
              <p className="font-mono text-sm text-text-primary">
                {formatCurrency(account.current_balance, account.currency)}
              </p>
            </button>
          ))}
        </div>
      )}
    </Card>
  );
}
