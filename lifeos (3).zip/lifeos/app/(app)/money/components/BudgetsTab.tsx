import { Plus } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils/cn";
import { formatCurrency } from "@/lib/utils/currency";
import type { BudgetCategory, Transaction } from "../types";

interface BudgetsTabProps {
  categories: BudgetCategory[];
  monthTransactions: Transaction[];
  onAdd: () => void;
  onEdit: (category: BudgetCategory) => void;
}

export function BudgetsTab({ categories, monthTransactions, onAdd, onEdit }: BudgetsTabProps) {
  const spentByCategory = new Map<string, number>();
  monthTransactions
    .filter((t) => t.direction === "expense" && t.category_id)
    .forEach((t) => {
      const key = t.category_id as string;
      spentByCategory.set(key, (spentByCategory.get(key) ?? 0) + t.amount);
    });

  return (
    <Card className="p-0">
      <div className="flex items-center justify-between p-4">
        <h3 className="font-display text-sm font-medium text-text-primary">
          Budget categories
        </h3>
        <Button variant="secondary" size="sm" onClick={onAdd}>
          <Plus size={14} className="mr-1.5" />
          Add category
        </Button>
      </div>

      {categories.length === 0 ? (
        <p className="p-4 pt-0 text-sm text-text-secondary">
          No budget categories yet.
        </p>
      ) : (
        <div className="divide-y divide-border-subtle">
          {categories.map((category) => {
            const spent = spentByCategory.get(category.id) ?? 0;
            const limit = category.monthly_limit;
            const percent = limit ? Math.min(100, (spent / limit) * 100) : null;
            const overBudget = limit != null && spent > limit;

            return (
              <button
                key={category.id}
                onClick={() => onEdit(category)}
                className="flex w-full flex-col gap-2 p-4 text-left transition-colors hover:bg-white/[0.02]"
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm text-text-primary">{category.name}</p>
                  <p className="font-mono text-xs text-text-secondary">
                    {formatCurrency(spent, category.currency)}
                    {limit != null && ` / ${formatCurrency(limit, category.currency)}`}
                  </p>
                </div>
                {percent !== null && (
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        overBudget ? "bg-danger" : "bg-accent"
                      )}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      )}
    </Card>
  );
}
