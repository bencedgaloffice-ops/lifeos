import { Plus } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency } from "@/lib/utils/currency";
import type { RecurringTransaction } from "../types";

interface RecurringTabProps {
  items: RecurringTransaction[];
  onAdd: () => void;
  onEdit: (item: RecurringTransaction) => void;
}

export function RecurringTab({ items, onAdd, onEdit }: RecurringTabProps) {
  return (
    <Card className="p-0">
      <div className="flex items-center justify-between p-4">
        <h3 className="font-display text-sm font-medium text-text-primary">
          Recurring
        </h3>
        <Button variant="secondary" size="sm" onClick={onAdd}>
          <Plus size={14} className="mr-1.5" />
          Add recurring
        </Button>
      </div>

      {items.length === 0 ? (
        <p className="p-4 pt-0 text-sm text-text-secondary">
          No recurring income or expenses set up yet — salary, subscriptions,
          rent, insurance.
        </p>
      ) : (
        <div className="divide-y divide-border-subtle">
          {items.map((item) => (
            <button
              key={item.id}
              onClick={() => onEdit(item)}
              className="flex w-full items-center justify-between gap-4 p-4 text-left transition-colors hover:bg-white/[0.02]"
            >
              <div>
                <p className="text-sm text-text-primary">{item.name}</p>
                <p className="text-xs capitalize text-text-secondary">
                  {item.frequency} · next {new Date(item.next_date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {!item.active && <Badge variant="neutral">Paused</Badge>}
                <Badge variant={item.type === "income" ? "success" : "neutral"}>
                  {item.type === "income" ? "+" : "−"}
                  {formatCurrency(item.amount)}
                </Badge>
              </div>
            </button>
          ))}
        </div>
      )}
    </Card>
  );
}
