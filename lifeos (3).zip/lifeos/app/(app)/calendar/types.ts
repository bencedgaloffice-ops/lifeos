import type { Database } from "@/types/supabase";

export type CalendarEvent = Database["public"]["Tables"]["calendar_events"]["Row"];
export type CalendarEventInsert = Database["public"]["Tables"]["calendar_events"]["Insert"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];
export type CalendarView = "month" | "week" | "agenda";
