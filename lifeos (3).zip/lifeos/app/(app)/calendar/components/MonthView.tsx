"use client";

import { useState } from "react";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils/cn";
import { getMonthGrid, isSameDay } from "@/lib/utils/date";
import { EventPill } from "./EventPill";
import type { CalendarEvent, LifeArea } from "../types";

interface MonthViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  lifeAreaById: Map<string, LifeArea>;
  onSelectDay: (date: Date) => void;
  onSelectEvent: (event: CalendarEvent) => void;
  onReschedule: (eventId: string, newStart: Date) => void;
}

const WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const MAX_VISIBLE_PER_DAY = 3;

export function MonthView({
  currentDate,
  events,
  lifeAreaById,
  onSelectDay,
  onSelectEvent,
  onReschedule,
}: MonthViewProps) {
  const days = getMonthGrid(currentDate);
  const today = new Date();
  const [draggedEventId, setDraggedEventId] = useState<string | null>(null);
  const [dragOverDay, setDragOverDay] = useState<number | null>(null);

  const eventsForDay = (day: Date) =>
    events.filter((e) => isSameDay(new Date(e.start_at), day));

  return (
    <Card className="p-0 overflow-hidden">
      <div className="grid grid-cols-7 border-b border-border-subtle">
        {WEEKDAY_LABELS.map((label) => (
          <div
            key={label}
            className="px-2 py-2 text-center font-mono text-xs uppercase tracking-wider text-text-secondary"
          >
            {label}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {days.map((day, i) => {
          const inCurrentMonth = day.getMonth() === currentDate.getMonth();
          const isToday = isSameDay(day, today);
          const dayEvents = eventsForDay(day);
          const visible = dayEvents.slice(0, MAX_VISIBLE_PER_DAY);
          const overflow = dayEvents.length - visible.length;

          return (
            <div
              key={i}
              onClick={() => onSelectDay(day)}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOverDay(i);
              }}
              onDragLeave={() => setDragOverDay((d) => (d === i ? null : d))}
              onDrop={(e) => {
                e.preventDefault();
                if (draggedEventId) {
                  const original = events.find((ev) => ev.id === draggedEventId);
                  if (original) {
                    const originalStart = new Date(original.start_at);
                    const newStart = new Date(day);
                    newStart.setHours(
                      originalStart.getHours(),
                      originalStart.getMinutes()
                    );
                    onReschedule(draggedEventId, newStart);
                  }
                }
                setDraggedEventId(null);
                setDragOverDay(null);
              }}
              className={cn(
                "flex min-h-[104px] cursor-pointer flex-col gap-1 border-b border-r border-border-subtle p-1.5 transition-colors last:border-r-0",
                !inCurrentMonth && "opacity-40",
                dragOverDay === i && "bg-accent-soft",
                "hover:bg-white/[0.02]"
              )}
            >
              <span
                className={cn(
                  "flex h-5 w-5 items-center justify-center rounded-full font-mono text-xs",
                  isToday
                    ? "bg-accent text-white"
                    : "text-text-secondary"
                )}
              >
                {day.getDate()}
              </span>
              <div className="flex flex-col gap-0.5">
                {visible.map((event) => (
                  <EventPill
                    key={event.id}
                    event={event}
                    lifeArea={event.life_area_id ? lifeAreaById.get(event.life_area_id) : undefined}
                    onClick={() => onSelectEvent(event)}
                    draggable
                    onDragStart={() => setDraggedEventId(event.id)}
                    compact
                  />
                ))}
                {overflow > 0 && (
                  <span className="px-1.5 text-[10px] text-text-secondary">
                    +{overflow} more
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
