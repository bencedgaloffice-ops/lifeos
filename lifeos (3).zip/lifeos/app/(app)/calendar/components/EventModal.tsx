"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { toDateInputValue, toTimeInputValue, addDays, addMonths } from "@/lib/utils/date";
import { eventFormSchema, type EventFormInput } from "@/lib/validations/calendar";
import { SelectField } from "./SelectField";
import type { CalendarEvent, LifeArea } from "../types";

interface EventModalProps {
  mode: "create" | "edit";
  event?: CalendarEvent;
  defaultDate?: Date;
  lifeAreas: LifeArea[];
  onClose: () => void;
  onSaved: () => void;
  onDeleted: () => void;
}

function buildDefaultValues(event?: CalendarEvent, defaultDate?: Date): EventFormInput {
  if (event) {
    const start = new Date(event.start_at);
    const end = new Date(event.end_at);
    return {
      title: event.title,
      description: event.description ?? "",
      startDate: toDateInputValue(start),
      startTime: toTimeInputValue(start),
      endDate: toDateInputValue(end),
      endTime: toTimeInputValue(end),
      allDay: event.all_day,
      lifeAreaId: event.life_area_id ?? "",
      category: event.category ?? "",
      recurrence: "none",
      recurrenceCount: 4,
    };
  }
  const base = defaultDate ?? new Date();
  return {
    title: "",
    description: "",
    startDate: toDateInputValue(base),
    startTime: "09:00",
    endDate: toDateInputValue(base),
    endTime: "10:00",
    allDay: false,
    lifeAreaId: "",
    category: "",
    recurrence: "none",
    recurrenceCount: 4,
  };
}

function shiftByRecurrence(date: Date, recurrence: "daily" | "weekly" | "monthly", n: number) {
  if (recurrence === "daily") return addDays(date, n);
  if (recurrence === "weekly") return addDays(date, n * 7);
  return addMonths(date, n);
}

export function EventModal({
  mode,
  event,
  defaultDate,
  lifeAreas,
  onClose,
  onSaved,
  onDeleted,
}: EventModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<EventFormInput>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: buildDefaultValues(event, defaultDate),
  });

  const allDay = watch("allDay");
  const recurrence = watch("recurrence");

  const onSubmit = async (data: EventFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const start = new Date(`${data.startDate}T${data.allDay ? "00:00" : data.startTime || "00:00"}`);
    const end = new Date(`${data.endDate}T${data.allDay ? "23:59" : data.endTime || "00:00"}`);

    const basePayload = {
      user_id: user.id,
      title: data.title,
      description: data.description || null,
      all_day: data.allDay,
      life_area_id: data.lifeAreaId || null,
      category: data.category || null,
    };

    if (mode === "edit" && event) {
      const { error } = await supabase
        .from("calendar_events")
        .update({
          ...basePayload,
          start_at: start.toISOString(),
          end_at: end.toISOString(),
        })
        .eq("id", event.id);

      if (error) {
        setSaveError(error.message);
        return;
      }
      onSaved();
      return;
    }

    // Create — possibly expanding into multiple occurrences.
    const count = data.recurrence === "none" ? 1 : data.recurrenceCount || 1;
    const rows = Array.from({ length: count }, (_, i) => {
      const occurrenceStart =
        i === 0 ? start : shiftByRecurrence(start, data.recurrence as "daily" | "weekly" | "monthly", i);
      const occurrenceEnd =
        i === 0 ? end : shiftByRecurrence(end, data.recurrence as "daily" | "weekly" | "monthly", i);
      return {
        ...basePayload,
        start_at: occurrenceStart.toISOString(),
        end_at: occurrenceEnd.toISOString(),
        recurrence_rule: data.recurrence === "none" ? null : data.recurrence,
      };
    });

    const { data: inserted, error } = await supabase
      .from("calendar_events")
      .insert(rows)
      .select();

    if (error) {
      setSaveError(error.message);
      return;
    }

    // Link occurrences 2..n to the first as their parent.
    const parentId = inserted?.[0]?.id;
    if (parentId && inserted && inserted.length > 1) {
      const followUpIds = inserted.slice(1).map((row) => row.id);
      await supabase
        .from("calendar_events")
        .update({ parent_event_id: parentId })
        .in("id", followUpIds);
    }

    onSaved();
  };

  const handleDelete = async () => {
    if (!event) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("calendar_events").delete().eq("id", event.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New event" : "Edit event"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Title" error={errors.title?.message} {...register("title")} />

        <textarea
          placeholder="Description (optional)"
          rows={2}
          className="w-full rounded-card border border-border-subtle bg-glass px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          {...register("description")}
        />

        <label className="flex items-center gap-2 text-sm text-text-secondary">
          <input type="checkbox" className="accent-[--accent]" {...register("allDay")} />
          All day
        </label>

        <div className="grid grid-cols-2 gap-3">
          <Input type="date" error={errors.startDate?.message} {...register("startDate")} />
          {!allDay && <Input type="time" {...register("startTime")} />}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input type="date" error={errors.endDate?.message} {...register("endDate")} />
          {!allDay && <Input type="time" {...register("endTime")} />}
        </div>

        <Controller
          name="lifeAreaId"
          control={control}
          render={({ field }) => (
            <SelectField {...field}>
              <option value="">No life area</option>
              {lifeAreas.map((area) => (
                <option key={area.id} value={area.id}>
                  {area.name}
                </option>
              ))}
            </SelectField>
          )}
        />

        <Input placeholder="Category (optional)" {...register("category")} />

        {mode === "create" && (
          <div className="grid grid-cols-2 gap-3">
            <Controller
              name="recurrence"
              control={control}
              render={({ field }) => (
                <SelectField {...field}>
                  <option value="none">Does not repeat</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </SelectField>
              )}
            />
            {recurrence !== "none" && (
              <Input
                type="number"
                min={1}
                max={52}
                placeholder="Occurrences"
                {...register("recurrenceCount")}
              />
            )}
          </div>
        )}

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this event?</span>
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  disabled={deleting}
                  onClick={handleDelete}
                >
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setConfirmingDelete(false)}
                >
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create event"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
