"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { createClient } from "@/lib/supabase/client";
import { addMonths, addDays, startOfMonth, formatMonthYear } from "@/lib/utils/date";
import type { CalendarEvent, LifeArea, CalendarView } from "../types";
import { ViewSwitcher } from "./ViewSwitcher";
import { MonthView } from "./MonthView";
import { WeekView } from "./WeekView";
import { AgendaView } from "./AgendaView";
import { EventModal } from "./EventModal";

interface CalendarShellProps {
  initialEvents: CalendarEvent[];
  lifeAreas: LifeArea[];
  initialDate: string;
}

export function CalendarShell({
  initialEvents,
  lifeAreas,
  initialDate,
}: CalendarShellProps) {
  const [currentDate, setCurrentDate] = useState(() => new Date(initialDate));
  const [view, setView] = useState<CalendarView>("month");
  const [events, setEvents] = useState<CalendarEvent[]>(initialEvents);
  const [loading, setLoading] = useState(false);
  const [modalState, setModalState] = useState<
    { mode: "closed" } | { mode: "create"; date?: Date } | { mode: "edit"; event: CalendarEvent }
  >({ mode: "closed" });

  const monthKey = `${currentDate.getFullYear()}-${currentDate.getMonth()}`;

  const fetchRange = useCallback(async (centerDate: Date) => {
    setLoading(true);
    const supabase = createClient();
    const rangeStart = addMonths(startOfMonth(centerDate), -1);
    const rangeEnd = addMonths(startOfMonth(centerDate), 2);

    const { data, error } = await supabase
      .from("calendar_events")
      .select("*")
      .gte("start_at", rangeStart.toISOString())
      .lt("start_at", rangeEnd.toISOString())
      .order("start_at", { ascending: true });

    if (!error && data) setEvents(data);
    setLoading(false);
  }, []);

  // Refetch whenever navigation moves to a month outside the loaded window.
  useEffect(() => {
    fetchRange(currentDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monthKey]);

  const lifeAreaById = useMemo(() => {
    const map = new Map<string, LifeArea>();
    lifeAreas.forEach((area) => map.set(area.id, area));
    return map;
  }, [lifeAreas]);

  const goToday = () => setCurrentDate(new Date());
  const goPrev = () =>
    setCurrentDate((d) => (view === "month" ? addMonths(d, -1) : addDays(d, view === "week" ? -7 : -1)));
  const goNext = () =>
    setCurrentDate((d) => (view === "month" ? addMonths(d, 1) : addDays(d, view === "week" ? 7 : 1)));

  const handleReschedule = async (eventId: string, newStart: Date) => {
    const event = events.find((e) => e.id === eventId);
    if (!event) return;

    const duration = new Date(event.end_at).getTime() - new Date(event.start_at).getTime();
    const newEnd = new Date(newStart.getTime() + duration);

    const supabase = createClient();
    await supabase
      .from("calendar_events")
      .update({ start_at: newStart.toISOString(), end_at: newEnd.toISOString() })
      .eq("id", eventId);

    fetchRange(currentDate);
  };

  const handleSaved = () => {
    setModalState({ mode: "closed" });
    fetchRange(currentDate);
  };

  const handleDeleted = () => {
    setModalState({ mode: "closed" });
    fetchRange(currentDate);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Calendar"
        description="Schedule across every part of your life, in one place."
        actions={
          <Button size="sm" onClick={() => setModalState({ mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            New event
          </Button>
        }
      />

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={goPrev}
            aria-label="Previous"
            className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <ChevronLeft size={18} />
          </button>
          <h2 className="min-w-[160px] text-center font-display text-lg text-text-primary">
            {formatMonthYear(currentDate)}
          </h2>
          <button
            onClick={goNext}
            aria-label="Next"
            className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <ChevronRight size={18} />
          </button>
          <Button variant="ghost" size="sm" onClick={goToday}>
            Today
          </Button>
        </div>
        <ViewSwitcher view={view} onChange={setView} />
      </div>

      {view === "month" && (
        <MonthView
          currentDate={currentDate}
          events={events}
          lifeAreaById={lifeAreaById}
          onSelectDay={(date) => setModalState({ mode: "create", date })}
          onSelectEvent={(event) => setModalState({ mode: "edit", event })}
          onReschedule={handleReschedule}
        />
      )}
      {view === "week" && (
        <WeekView
          currentDate={currentDate}
          events={events}
          lifeAreaById={lifeAreaById}
          onSelectEvent={(event) => setModalState({ mode: "edit", event })}
        />
      )}
      {view === "agenda" && (
        <AgendaView
          currentDate={currentDate}
          events={events}
          lifeAreaById={lifeAreaById}
          onSelectEvent={(event) => setModalState({ mode: "edit", event })}
        />
      )}

      {loading && (
        <p className="text-center text-xs text-text-secondary">Updating…</p>
      )}

      {modalState.mode !== "closed" && (
        <EventModal
          mode={modalState.mode}
          event={modalState.mode === "edit" ? modalState.event : undefined}
          defaultDate={modalState.mode === "create" ? modalState.date : undefined}
          lifeAreas={lifeAreas}
          onClose={() => setModalState({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
