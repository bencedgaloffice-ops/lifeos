import { cn } from "@/lib/utils/cn";
import type { CalendarView } from "../types";

const VIEWS: { value: CalendarView; label: string }[] = [
  { value: "month", label: "Month" },
  { value: "week", label: "Week" },
  { value: "agenda", label: "Agenda" },
];

interface ViewSwitcherProps {
  view: CalendarView;
  onChange: (view: CalendarView) => void;
}

export function ViewSwitcher({ view, onChange }: ViewSwitcherProps) {
  return (
    <div className="inline-flex overflow-hidden rounded-card border border-border-subtle text-sm">
      {VIEWS.map((v) => (
        <button
          key={v.value}
          onClick={() => onChange(v.value)}
          aria-pressed={view === v.value}
          className={cn(
            "px-3 py-1.5 transition-colors",
            view === v.value
              ? "bg-accent-soft text-accent"
              : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
          )}
        >
          {v.label}
        </button>
      ))}
    </div>
  );
}
