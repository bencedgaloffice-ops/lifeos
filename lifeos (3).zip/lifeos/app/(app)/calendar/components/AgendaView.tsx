import { Card } from "@/components/ui/Card";
import { addDays, isSameDay } from "@/lib/utils/date";
import { EventPill } from "./EventPill";
import type { CalendarEvent, LifeArea } from "../types";

interface AgendaViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  lifeAreaById: Map<string, LifeArea>;
  onSelectEvent: (event: CalendarEvent) => void;
}

const AGENDA_SPAN_DAYS = 30;

export function AgendaView({ currentDate, events, lifeAreaById, onSelectEvent }: AgendaViewProps) {
  const days = Array.from({ length: AGENDA_SPAN_DAYS }, (_, i) => addDays(currentDate, i));
  const daysWithEvents = days
    .map((day) => ({
      day,
      dayEvents: events
        .filter((e) => isSameDay(new Date(e.start_at), day))
        .sort((a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime()),
    }))
    .filter(({ dayEvents }) => dayEvents.length > 0);

  if (daysWithEvents.length === 0) {
    return (
      <Card>
        <p className="text-center text-sm text-text-secondary">
          Nothing scheduled in the next {AGENDA_SPAN_DAYS} days.
        </p>
      </Card>
    );
  }

  return (
    <Card className="divide-y divide-border-subtle p-0">
      {daysWithEvents.map(({ day, dayEvents }) => (
        <div key={day.toISOString()} className="flex gap-4 p-4">
          <div className="w-16 shrink-0 text-right">
            <p className="font-mono text-xs text-text-secondary">
              {day.toLocaleDateString("en-US", { weekday: "short" })}
            </p>
            <p className="font-display text-lg text-text-primary">{day.getDate()}</p>
          </div>
          <div className="flex flex-1 flex-col gap-1.5">
            {dayEvents.map((event) => (
              <EventPill
                key={event.id}
                event={event}
                lifeArea={event.life_area_id ? lifeAreaById.get(event.life_area_id) : undefined}
                onClick={() => onSelectEvent(event)}
              />
            ))}
          </div>
        </div>
      ))}
    </Card>
  );
}
