import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils/cn";
import { getWeekDays, isSameDay, formatDayLabel } from "@/lib/utils/date";
import { EventPill } from "./EventPill";
import type { CalendarEvent, LifeArea } from "../types";

interface WeekViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  lifeAreaById: Map<string, LifeArea>;
  onSelectEvent: (event: CalendarEvent) => void;
}

const HOURS = Array.from({ length: 24 }, (_, i) => i);

export function WeekView({ currentDate, events, lifeAreaById, onSelectEvent }: WeekViewProps) {
  const days = getWeekDays(currentDate);
  const today = new Date();

  const eventsForDay = (day: Date) =>
    events
      .filter((e) => isSameDay(new Date(e.start_at), day))
      .sort((a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime());

  const allDayEvents = (day: Date) => eventsForDay(day).filter((e) => e.all_day);
  const timedEvents = (day: Date) => eventsForDay(day).filter((e) => !e.all_day);

  const topForHour = (date: Date) => {
    const hours = date.getHours() + date.getMinutes() / 60;
    return `${(hours / 24) * 100}%`;
  };

  return (
    <Card className="overflow-hidden p-0">
      {/* Day headers */}
      <div className="grid grid-cols-[48px_repeat(7,1fr)] border-b border-border-subtle">
        <div />
        {days.map((day) => (
          <div key={day.toISOString()} className="border-l border-border-subtle px-2 py-2 text-center">
            <span
              className={cn(
                "font-mono text-xs",
                isSameDay(day, today) ? "text-accent" : "text-text-secondary"
              )}
            >
              {formatDayLabel(day)}
            </span>
          </div>
        ))}
      </div>

      {/* All-day row */}
      <div className="grid grid-cols-[48px_repeat(7,1fr)] border-b border-border-subtle">
        <div className="px-1.5 py-1 text-right font-mono text-[10px] text-text-secondary">
          all-day
        </div>
        {days.map((day) => (
          <div
            key={day.toISOString()}
            className="flex flex-col gap-0.5 border-l border-border-subtle p-1"
          >
            {allDayEvents(day).map((event) => (
              <EventPill
                key={event.id}
                event={event}
                lifeArea={event.life_area_id ? lifeAreaById.get(event.life_area_id) : undefined}
                onClick={() => onSelectEvent(event)}
                compact
              />
            ))}
          </div>
        ))}
      </div>

      {/* Hourly grid */}
      <div className="relative grid max-h-[600px] grid-cols-[48px_repeat(7,1fr)] overflow-y-auto">
        <div className="flex flex-col">
          {HOURS.map((hour) => (
            <div
              key={hour}
              className="h-14 border-b border-border-subtle px-1.5 pt-0.5 text-right font-mono text-[10px] text-text-secondary"
            >
              {hour}:00
            </div>
          ))}
        </div>
        {days.map((day) => (
          <div key={day.toISOString()} className="relative border-l border-border-subtle">
            {HOURS.map((hour) => (
              <div key={hour} className="h-14 border-b border-border-subtle" />
            ))}
            {timedEvents(day).map((event) => (
              <div
                key={event.id}
                className="absolute inset-x-0.5"
                style={{ top: topForHour(new Date(event.start_at)) }}
              >
                <EventPill
                  event={event}
                  lifeArea={event.life_area_id ? lifeAreaById.get(event.life_area_id) : undefined}
                  onClick={() => onSelectEvent(event)}
                  compact
                />
              </div>
            ))}
          </div>
        ))}
      </div>
    </Card>
  );
}
