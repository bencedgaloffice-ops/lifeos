import { formatTime } from "@/lib/utils/date";
import type { CalendarEvent, LifeArea } from "../types";

interface EventPillProps {
  event: CalendarEvent;
  lifeArea?: LifeArea;
  onClick: () => void;
  draggable?: boolean;
  onDragStart?: () => void;
  compact?: boolean;
}

const FALLBACK_COLOR = "#5b8cff"; // --accent

export function EventPill({
  event,
  lifeArea,
  onClick,
  draggable = false,
  onDragStart,
  compact = false,
}: EventPillProps) {
  const color = lifeArea?.color || FALLBACK_COLOR;

  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      draggable={draggable}
      onDragStart={onDragStart}
      className="flex w-full items-center gap-1.5 truncate rounded px-1.5 py-0.5 text-left text-xs transition-opacity hover:opacity-80"
      style={{ backgroundColor: `${color}26`, color }}
      title={event.title}
    >
      <span
        className="h-1.5 w-1.5 shrink-0 rounded-full"
        style={{ backgroundColor: color }}
      />
      {!compact && !event.all_day && (
        <span className="shrink-0 font-mono text-[10px] opacity-80">
          {formatTime(new Date(event.start_at))}
        </span>
      )}
      <span className="truncate">{event.title}</span>
    </button>
  );
}
