import { type SelectHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils/cn";

/**
 * Calendar-module-local select — not added to components/ui since the
 * shared primitive set is frozen for this phase. Styled to match Input
 * exactly so it's visually indistinguishable from the design system.
 */
export const SelectField = forwardRef<
  HTMLSelectElement,
  SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select
    ref={ref}
    className={cn(
      "h-10 w-full rounded-card border border-border-subtle bg-glass px-3 text-sm text-text-primary",
      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent",
      className
    )}
    {...props}
  >
    {children}
  </select>
));
SelectField.displayName = "SelectField";
