import { createClient } from "@/lib/supabase/server";
import { CalendarShell } from "./components/CalendarShell";
import { startOfMonth, addMonths } from "@/lib/utils/date";

/**
 * Server component: fetches life_areas (for the color-coded picker)
 * and the current month's events for a fast first paint. CalendarShell
 * takes over client-side from there — refetching on month/view
 * navigation and handling all create/edit/delete.
 */
export default async function CalendarPage() {
  const supabase = await createClient();

  const now = new Date();
  const rangeStart = addMonths(startOfMonth(now), -1);
  const rangeEnd = addMonths(startOfMonth(now), 2);

  const [{ data: events }, { data: lifeAreas }] = await Promise.all([
    supabase
      .from("calendar_events")
      .select("*")
      .gte("start_at", rangeStart.toISOString())
      .lt("start_at", rangeEnd.toISOString())
      .order("start_at", { ascending: true }),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
  ]);

  return (
    <CalendarShell
      initialEvents={events ?? []}
      lifeAreas={lifeAreas ?? []}
      initialDate={now.toISOString()}
    />
  );
}
