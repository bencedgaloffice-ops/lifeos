import { createClient } from "@/lib/supabase/server";
import { DocumentsShell } from "./components/DocumentsShell";

export default async function DocumentsPage() {
  const supabase = await createClient();

  const [{ data: documents }, { data: lifeAreas }, { data: projects }] = await Promise.all([
    supabase.from("documents").select("*").order("uploaded_at", { ascending: false }),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
    supabase.from("projects").select("*").order("name", { ascending: true }),
  ]);

  return (
    <DocumentsShell
      initialDocuments={documents ?? []}
      lifeAreas={lifeAreas ?? []}
      projects={projects ?? []}
    />
  );
}
