import type { Database } from "@/types/supabase";

export type Document = Database["public"]["Tables"]["documents"]["Row"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];
export type Project = Database["public"]["Tables"]["projects"]["Row"];
