import { FileText, Image as ImageIcon, FileSpreadsheet, Presentation, File } from "lucide-react";

const IMAGE_EXT = ["png", "jpg", "jpeg", "gif", "webp", "svg"];
const SPREADSHEET_EXT = ["xlsx", "xls", "csv"];
const PRESENTATION_EXT = ["pptx", "ppt", "key"];
const DOC_EXT = ["pdf", "doc", "docx", "txt", "rtf", "pages"];

function getExtension(path: string) {
  const filename = path.split("/").pop() ?? path;
  const dot = filename.lastIndexOf(".");
  return dot === -1 ? "" : filename.slice(dot + 1).toLowerCase();
}

export function DocumentIcon({ path, size = 18 }: { path: string; size?: number }) {
  const ext = getExtension(path);

  if (IMAGE_EXT.includes(ext)) return <ImageIcon size={size} />;
  if (SPREADSHEET_EXT.includes(ext)) return <FileSpreadsheet size={size} />;
  if (PRESENTATION_EXT.includes(ext)) return <Presentation size={size} />;
  if (DOC_EXT.includes(ext)) return <FileText size={size} />;
  return <File size={size} />;
}

export function fileExtensionLabel(path: string) {
  const ext = getExtension(path);
  return ext ? ext.toUpperCase() : "FILE";
}

export function originalFilename(path: string, storedTitle: string) {
  // Storage path is `${userId}/${timestamp}-${sanitizedName}` — prefer
  // the document's own title for display, this is a fallback only.
  const filename = path.split("/").pop() ?? storedTitle;
  return filename.replace(/^\d+-/, "");
}
