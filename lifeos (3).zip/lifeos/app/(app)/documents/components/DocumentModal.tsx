"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2, Upload } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import {
  documentMetadataSchema,
  MAX_UPLOAD_BYTES,
  type DocumentMetadataInput,
} from "@/lib/validations/documents";
import { LifeAreaSelector } from "./LifeAreaSelector";
import { ProjectSelector } from "./ProjectSelector";
import type { Document, LifeArea, Project } from "../types";

interface DocumentModalProps {
  mode: "create" | "edit";
  doc?: Document;
  lifeAreas: LifeArea[];
  projects: Project[];
  onClose: () => void;
  onSaved: (doc: Document) => void;
  onDeleted: () => void;
}

function sanitizeFilename(name: string) {
  return name.replace(/[^a-zA-Z0-9.\-]/g, "_");
}

export function DocumentModal({
  mode,
  doc,
  lifeAreas,
  projects,
  onClose,
  onSaved,
  onDeleted,
}: DocumentModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<DocumentMetadataInput>({
    resolver: zodResolver(documentMetadataSchema),
    defaultValues: doc
      ? {
          title: doc.title,
          category: doc.category ?? "",
          lifeAreaId: doc.life_area_id ?? "",
          projectId: doc.related_project_id ?? "",
        }
      : { title: "", category: "", lifeAreaId: "", projectId: "" },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null);
    const selected = e.target.files?.[0];
    if (!selected) {
      setFile(null);
      return;
    }
    if (selected.size > MAX_UPLOAD_BYTES) {
      setFileError("File is too large — 20MB max.");
      setFile(null);
      return;
    }
    setFile(selected);
    // Default the title to the filename (without extension) if empty.
    setValue("title", selected.name.replace(/\.[^/.]+$/, ""), { shouldValidate: true });
  };

  const onSubmit = async (data: DocumentMetadataInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    if (mode === "edit" && doc) {
      const { data: saved, error } = await supabase
        .from("documents")
        .update({
          title: data.title,
          category: data.category || null,
          life_area_id: data.lifeAreaId || null,
          related_project_id: data.projectId || null,
        })
        .eq("id", doc.id)
        .select()
        .single();

      if (error || !saved) {
        setSaveError(error?.message ?? "Something went wrong.");
        return;
      }
      onSaved(saved);
      return;
    }

    // Create — requires a file.
    if (!file) {
      setFileError("Choose a file to upload.");
      return;
    }

    setUploading(true);
    const path = `${user.id}/${Date.now()}-${sanitizeFilename(file.name)}`;
    const { error: uploadError } = await supabase.storage.from("documents").upload(path, file);

    if (uploadError) {
      setUploading(false);
      setSaveError(uploadError.message);
      return;
    }

    const { data: saved, error: insertError } = await supabase
      .from("documents")
      .insert({
        user_id: user.id,
        title: data.title,
        file_path: path,
        category: data.category || null,
        life_area_id: data.lifeAreaId || null,
        related_project_id: data.projectId || null,
      })
      .select()
      .single();

    setUploading(false);

    if (insertError || !saved) {
      // Best-effort cleanup so a failed insert doesn't leave an orphaned file.
      await supabase.storage.from("documents").remove([path]);
      setSaveError(insertError?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!doc) return;
    setDeleting(true);
    const supabase = createClient();
    const { error: storageError } = await supabase.storage
      .from("documents")
      .remove([doc.file_path]);

    if (storageError) {
      setDeleting(false);
      setSaveError(storageError.message);
      return;
    }

    const { error } = await supabase.from("documents").delete().eq("id", doc.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  const busy = isSubmitting || uploading;

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "Upload document" : "Edit document"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        {mode === "create" && (
          <div className="flex flex-col gap-1.5">
            <label className="flex cursor-pointer flex-col items-center gap-2 rounded-card border border-dashed border-border-subtle px-4 py-6 text-center transition-colors hover:bg-white/[0.02]">
              <Upload size={20} className="text-text-secondary" />
              <span className="text-sm text-text-secondary">
                {file ? file.name : "Choose a file (max 20MB)"}
              </span>
              <input type="file" onChange={handleFileChange} className="hidden" />
            </label>
            {fileError && <p className="text-xs text-danger">{fileError}</p>}
          </div>
        )}

        <Input placeholder="Title" error={errors.title?.message} {...register("title")} />
        <Input placeholder="Category (optional)" {...register("category")} />

        <Controller
          name="lifeAreaId"
          control={control}
          render={({ field }) => <LifeAreaSelector lifeAreas={lifeAreas} {...field} />}
        />

        <Controller
          name="projectId"
          control={control}
          render={({ field }) => <ProjectSelector projects={projects} {...field} />}
        />

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this document?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={busy}>
            {busy ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                {uploading ? "Uploading…" : "Saving…"}
              </span>
            ) : mode === "create" ? (
              "Upload"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
