import { Upload } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { DocumentCard } from "./DocumentCard";
import type { Document, LifeArea, Project } from "../types";

interface DocumentsListProps {
  documents: Document[];
  lifeAreaById: Map<string, LifeArea>;
  projectById: Map<string, Project>;
  onEdit: (doc: Document) => void;
  onUpload: () => void;
  hasAnyDocuments: boolean;
}

export function DocumentsList({
  documents,
  lifeAreaById,
  projectById,
  onEdit,
  onUpload,
  hasAnyDocuments,
}: DocumentsListProps) {
  if (documents.length === 0) {
    return (
      <EmptyState
        title={hasAnyDocuments ? "No documents match your filters" : "Your vault is empty"}
        description={
          hasAnyDocuments
            ? "Try adjusting your search or filters."
            : "Certificates, contracts, plans, archives — store the documents that matter."
        }
        action={
          !hasAnyDocuments && (
            <Button size="sm" onClick={onUpload}>
              <Upload size={14} className="mr-1.5" />
              Upload a document
            </Button>
          )
        }
      />
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {documents.map((doc) => (
        <DocumentCard
          key={doc.id}
          doc={doc}
          lifeArea={doc.life_area_id ? lifeAreaById.get(doc.life_area_id) : undefined}
          project={doc.related_project_id ? projectById.get(doc.related_project_id) : undefined}
          onEdit={() => onEdit(doc)}
        />
      ))}
    </div>
  );
}
