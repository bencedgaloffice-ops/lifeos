"use client";

import { useState } from "react";
import { Pencil, Download, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Tag } from "@/components/ui/Tag";
import { Badge } from "@/components/ui/Badge";
import { createClient } from "@/lib/supabase/client";
import { DocumentIcon, fileExtensionLabel } from "./DocumentIcon";
import type { Document, LifeArea, Project } from "../types";

interface DocumentCardProps {
  doc: Document;
  lifeArea?: LifeArea;
  project?: Project;
  onEdit: () => void;
}

export function DocumentCard({ doc, lifeArea, project, onEdit }: DocumentCardProps) {
  const [opening, setOpening] = useState(false);
  const [openError, setOpenError] = useState<string | null>(null);

  const handleOpen = async () => {
    setOpening(true);
    setOpenError(null);
    const supabase = createClient();
    const { data, error } = await supabase.storage
      .from("documents")
      .createSignedUrl(doc.file_path, 60);
    setOpening(false);

    if (error || !data) {
      setOpenError("Couldn't open this file.");
      return;
    }
    window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="shrink-0 text-text-secondary">
            <DocumentIcon path={doc.file_path} />
          </span>
          <h3 className="truncate font-display text-sm font-medium text-text-primary">
            {doc.title}
          </h3>
        </div>
        <button
          onClick={onEdit}
          aria-label="Edit document"
          className="shrink-0 rounded-card p-1 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
        >
          <Pencil size={14} />
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <Badge variant="neutral">{fileExtensionLabel(doc.file_path)}</Badge>
        {doc.category && <Tag>{doc.category}</Tag>}
        {lifeArea && <Tag color={lifeArea.color ?? undefined}>{lifeArea.name}</Tag>}
        {project && <Tag>{project.name}</Tag>}
      </div>

      <p className="font-mono text-xs text-text-secondary">
        {new Date(doc.uploaded_at).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
        })}
      </p>

      <button
        onClick={handleOpen}
        disabled={opening}
        className="flex items-center justify-center gap-1.5 rounded-card border border-border-subtle py-1.5 text-xs text-text-secondary transition-colors hover:bg-white/[0.04] hover:text-text-primary disabled:opacity-50"
      >
        {opening ? (
          <Loader2 size={13} className="animate-spin" />
        ) : (
          <Download size={13} />
        )}
        Open
      </button>
      {openError && <p className="text-xs text-danger">{openError}</p>}
    </Card>
  );
}
