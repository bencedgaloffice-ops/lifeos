"use client";

import { useMemo, useState } from "react";
import { Upload } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { DocumentFilters } from "./DocumentFilters";
import { DocumentsList } from "./DocumentsList";
import { DocumentModal } from "./DocumentModal";
import type { Document, LifeArea, Project } from "../types";

interface DocumentsShellProps {
  initialDocuments: Document[];
  lifeAreas: LifeArea[];
  projects: Project[];
}

type ModalState = { mode: "closed" } | { mode: "create" } | { mode: "edit"; doc: Document };

export function DocumentsShell({ initialDocuments, lifeAreas, projects }: DocumentsShellProps) {
  const [documents, setDocuments] = useState(initialDocuments);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [lifeAreaId, setLifeAreaId] = useState("");
  const [projectId, setProjectId] = useState("");
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  const lifeAreaById = useMemo(() => {
    const map = new Map<string, LifeArea>();
    lifeAreas.forEach((a) => map.set(a.id, a));
    return map;
  }, [lifeAreas]);

  const projectById = useMemo(() => {
    const map = new Map<string, Project>();
    projects.forEach((p) => map.set(p.id, p));
    return map;
  }, [projects]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    documents.forEach((d) => d.category && set.add(d.category));
    return Array.from(set).sort();
  }, [documents]);

  const filteredDocuments = useMemo(() => {
    const query = search.trim().toLowerCase();
    return documents.filter((doc) => {
      if (category && doc.category !== category) return false;
      if (lifeAreaId && doc.life_area_id !== lifeAreaId) return false;
      if (projectId && doc.related_project_id !== projectId) return false;
      if (query && !doc.title.toLowerCase().includes(query)) return false;
      return true;
    });
  }, [documents, search, category, lifeAreaId, projectId]);

  const handleSaved = (saved: Document) => {
    setDocuments((prev) => {
      const exists = prev.some((d) => d.id === saved.id);
      return exists ? prev.map((d) => (d.id === saved.id ? saved : d)) : [saved, ...prev];
    });
    setModal({ mode: "closed" });
  };

  const handleDeleted = () => {
    if (modal.mode === "edit") {
      setDocuments((prev) => prev.filter((d) => d.id !== modal.doc.id));
    }
    setModal({ mode: "closed" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Documents"
        description="Your personal vault — certificates, contracts, plans, and archives."
        actions={
          <Button size="sm" onClick={() => setModal({ mode: "create" })}>
            <Upload size={14} className="mr-1.5" />
            Upload
          </Button>
        }
      />

      <DocumentFilters
        search={search}
        onSearchChange={setSearch}
        category={category}
        onCategoryChange={setCategory}
        categories={categories}
        lifeAreaId={lifeAreaId}
        onLifeAreaChange={setLifeAreaId}
        lifeAreas={lifeAreas}
        projectId={projectId}
        onProjectChange={setProjectId}
        projects={projects}
      />

      <DocumentsList
        documents={filteredDocuments}
        lifeAreaById={lifeAreaById}
        projectById={projectById}
        onEdit={(doc) => setModal({ mode: "edit", doc })}
        onUpload={() => setModal({ mode: "create" })}
        hasAnyDocuments={documents.length > 0}
      />

      {modal.mode !== "closed" && (
        <DocumentModal
          mode={modal.mode}
          doc={modal.mode === "edit" ? modal.doc : undefined}
          lifeAreas={lifeAreas}
          projects={projects}
          onClose={() => setModal({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
