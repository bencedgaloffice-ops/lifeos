import { Search } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { SelectField } from "./SelectField";
import { LifeAreaSelector } from "./LifeAreaSelector";
import { ProjectSelector } from "./ProjectSelector";
import type { LifeArea, Project } from "../types";

interface DocumentFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  category: string;
  onCategoryChange: (value: string) => void;
  categories: string[];
  lifeAreaId: string;
  onLifeAreaChange: (value: string) => void;
  lifeAreas: LifeArea[];
  projectId: string;
  onProjectChange: (value: string) => void;
  projects: Project[];
}

export function DocumentFilters({
  search,
  onSearchChange,
  category,
  onCategoryChange,
  categories,
  lifeAreaId,
  onLifeAreaChange,
  lifeAreas,
  projectId,
  onProjectChange,
  projects,
}: DocumentFiltersProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
      <div className="relative flex-1 sm:min-w-[200px]">
        <Search
          size={14}
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary"
        />
        <Input
          placeholder="Search documents…"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-8"
        />
      </div>

      {categories.length > 0 && (
        <SelectField
          value={category}
          onChange={(e) => onCategoryChange(e.target.value)}
          className="sm:w-44"
        >
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </SelectField>
      )}

      <LifeAreaSelector
        lifeAreas={lifeAreas}
        emptyLabel="All life areas"
        value={lifeAreaId}
        onChange={(e) => onLifeAreaChange(e.target.value)}
        className="sm:w-44"
      />

      <ProjectSelector
        projects={projects}
        emptyLabel="All projects"
        value={projectId}
        onChange={(e) => onProjectChange(e.target.value)}
        className="sm:w-44"
      />
    </div>
  );
}
