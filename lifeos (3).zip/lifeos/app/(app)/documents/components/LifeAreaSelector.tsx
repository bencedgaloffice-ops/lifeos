import { forwardRef } from "react";
import { SelectField } from "./SelectField";
import type { LifeArea } from "../types";

interface LifeAreaSelectorProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "children"> {
  lifeAreas: LifeArea[];
  emptyLabel?: string;
}

export const LifeAreaSelector = forwardRef<HTMLSelectElement, LifeAreaSelectorProps>(
  ({ lifeAreas, emptyLabel = "No life area", ...props }, ref) => (
    <SelectField ref={ref} {...props}>
      <option value="">{emptyLabel}</option>
      {lifeAreas.map((area) => (
        <option key={area.id} value={area.id}>
          {area.name}
        </option>
      ))}
    </SelectField>
  )
);
LifeAreaSelector.displayName = "LifeAreaSelector";
