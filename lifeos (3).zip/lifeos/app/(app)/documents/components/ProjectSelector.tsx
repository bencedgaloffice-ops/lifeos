import { forwardRef } from "react";
import { SelectField } from "./SelectField";
import type { Project } from "../types";

interface ProjectSelectorProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "children"> {
  projects: Project[];
  emptyLabel?: string;
}

export const ProjectSelector = forwardRef<HTMLSelectElement, ProjectSelectorProps>(
  ({ projects, emptyLabel = "No project", ...props }, ref) => (
    <SelectField ref={ref} {...props}>
      <option value="">{emptyLabel}</option>
      {projects.map((project) => (
        <option key={project.id} value={project.id}>
          {project.name}
        </option>
      ))}
    </SelectField>
  )
);
ProjectSelector.displayName = "ProjectSelector";
