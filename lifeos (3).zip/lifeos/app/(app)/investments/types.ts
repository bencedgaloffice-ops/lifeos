import type { Database } from "@/types/supabase";

export type InvestmentAccount = Database["public"]["Tables"]["investment_accounts"]["Row"];
export type InvestmentHolding = Database["public"]["Tables"]["investment_holdings"]["Row"];
export type InvestmentType = NonNullable<InvestmentAccount["type"]>;
