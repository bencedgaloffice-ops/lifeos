import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { AccountCard } from "./AccountCard";
import type { InvestmentAccount, InvestmentHolding } from "../types";

interface AccountsListProps {
  accounts: InvestmentAccount[];
  holdingsByAccount: Map<string, InvestmentHolding[]>;
  onAddAccount: () => void;
  onEditAccount: (account: InvestmentAccount) => void;
  onAddHolding: (accountId: string) => void;
  onEditHolding: (accountId: string, holding: InvestmentHolding) => void;
}

export function AccountsList({
  accounts,
  holdingsByAccount,
  onAddAccount,
  onEditAccount,
  onAddHolding,
  onEditHolding,
}: AccountsListProps) {
  if (accounts.length === 0) {
    return (
      <EmptyState
        title="No investment accounts yet"
        description="Add a brokerage, exchange, or other account to start tracking holdings."
        action={
          <Button size="sm" onClick={onAddAccount}>
            <Plus size={14} className="mr-1.5" />
            Add account
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-3">
      {accounts.map((account) => (
        <AccountCard
          key={account.id}
          account={account}
          holdings={holdingsByAccount.get(account.id) ?? []}
          onEditAccount={() => onEditAccount(account)}
          onAddHolding={() => onAddHolding(account.id)}
          onEditHolding={(holding) => onEditHolding(account.id, holding)}
        />
      ))}
    </div>
  );
}
