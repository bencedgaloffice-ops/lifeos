"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { PortfolioOverview } from "./PortfolioOverview";
import { AccountsList } from "./AccountsList";
import { AccountModal } from "./AccountModal";
import { HoldingModal } from "./HoldingModal";
import type { InvestmentAccount, InvestmentHolding } from "../types";

interface InvestmentsShellProps {
  initialAccounts: InvestmentAccount[];
  initialHoldings: InvestmentHolding[];
}

type ModalState =
  | { type: "closed" }
  | { type: "account"; mode: "create" | "edit"; account?: InvestmentAccount }
  | { type: "holding"; mode: "create" | "edit"; accountId: string; holding?: InvestmentHolding };

export function InvestmentsShell({ initialAccounts, initialHoldings }: InvestmentsShellProps) {
  const [accounts, setAccounts] = useState(initialAccounts);
  const [holdings, setHoldings] = useState(initialHoldings);
  const [modal, setModal] = useState<ModalState>({ type: "closed" });

  const holdingsByAccount = useMemo(() => {
    const map = new Map<string, InvestmentHolding[]>();
    holdings.forEach((h) => {
      const list = map.get(h.investment_account_id) ?? [];
      list.push(h);
      map.set(h.investment_account_id, list);
    });
    return map;
  }, [holdings]);

  const handleAccountSaved = (saved: InvestmentAccount) => {
    setAccounts((prev) => {
      const exists = prev.some((a) => a.id === saved.id);
      return exists ? prev.map((a) => (a.id === saved.id ? saved : a)) : [saved, ...prev];
    });
    setModal({ type: "closed" });
  };

  const handleAccountDeleted = () => {
    if (modal.type === "account" && modal.account) {
      const deletedId = modal.account.id;
      setAccounts((prev) => prev.filter((a) => a.id !== deletedId));
      setHoldings((prev) => prev.filter((h) => h.investment_account_id !== deletedId));
    }
    setModal({ type: "closed" });
  };

  const handleHoldingSaved = (saved: InvestmentHolding) => {
    setHoldings((prev) => {
      const exists = prev.some((h) => h.id === saved.id);
      return exists ? prev.map((h) => (h.id === saved.id ? saved : h)) : [...prev, saved];
    });
    setModal({ type: "closed" });
  };

  const handleHoldingDeleted = () => {
    if (modal.type === "holding" && modal.holding) {
      const deletedId = modal.holding.id;
      setHoldings((prev) => prev.filter((h) => h.id !== deletedId));
    }
    setModal({ type: "closed" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Investments"
        description="A private view of long-term wealth — asset ownership, tracked manually."
        actions={
          <Button size="sm" onClick={() => setModal({ type: "account", mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            Add account
          </Button>
        }
      />

      <PortfolioOverview accounts={accounts} holdingsByAccount={holdingsByAccount} />

      <AccountsList
        accounts={accounts}
        holdingsByAccount={holdingsByAccount}
        onAddAccount={() => setModal({ type: "account", mode: "create" })}
        onEditAccount={(account) => setModal({ type: "account", mode: "edit", account })}
        onAddHolding={(accountId) => setModal({ type: "holding", mode: "create", accountId })}
        onEditHolding={(accountId, holding) =>
          setModal({ type: "holding", mode: "edit", accountId, holding })
        }
      />

      {modal.type === "account" && (
        <AccountModal
          mode={modal.mode}
          account={modal.account}
          onClose={() => setModal({ type: "closed" })}
          onSaved={handleAccountSaved}
          onDeleted={handleAccountDeleted}
        />
      )}
      {modal.type === "holding" && (
        <HoldingModal
          mode={modal.mode}
          accountId={modal.accountId}
          holding={modal.holding}
          onClose={() => setModal({ type: "closed" })}
          onSaved={handleHoldingSaved}
          onDeleted={handleHoldingDeleted}
        />
      )}
    </div>
  );
}
