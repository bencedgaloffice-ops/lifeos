import { Card } from "@/components/ui/Card";
import { formatCurrency } from "@/lib/utils/currency";
import type { AllocationSlice } from "../portfolio-math";

interface AllocationBreakdownProps {
  slices: AllocationSlice[];
  currency: string;
}

const TYPE_LABEL: Record<string, string> = {
  stocks: "Stocks",
  crypto: "Crypto",
  other: "Other",
};

export function AllocationBreakdown({ slices, currency }: AllocationBreakdownProps) {
  if (slices.length === 0) return null;

  return (
    <Card className="flex flex-col gap-3">
      <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">
        Allocation — {currency}
      </p>
      <div className="flex flex-col gap-3">
        {slices.map((slice) => (
          <div key={slice.type} className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-text-primary">{TYPE_LABEL[slice.type] ?? slice.type}</span>
              <span className="font-mono text-xs text-text-secondary">
                {formatCurrency(slice.currentValue, currency)} · {Math.round(slice.percent)}%
              </span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
              <div
                className="h-full rounded-full bg-accent transition-all"
                style={{ width: `${slice.percent}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
