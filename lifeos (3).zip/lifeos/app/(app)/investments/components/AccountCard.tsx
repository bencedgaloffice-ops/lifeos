"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, Pencil } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency } from "@/lib/utils/currency";
import { holdingCurrentValue } from "../portfolio-math";
import { HoldingsTable } from "./HoldingsTable";
import type { InvestmentAccount, InvestmentHolding } from "../types";

interface AccountCardProps {
  account: InvestmentAccount;
  holdings: InvestmentHolding[];
  onEditAccount: () => void;
  onAddHolding: () => void;
  onEditHolding: (holding: InvestmentHolding) => void;
}

export function AccountCard({
  account,
  holdings,
  onEditAccount,
  onAddHolding,
  onEditHolding,
}: AccountCardProps) {
  const [expanded, setExpanded] = useState(false);
  const total = holdings.reduce((sum, h) => sum + holdingCurrentValue(h), 0);

  return (
    <Card className="p-0">
      {/* A <div> with role="button" for the row toggle (not a <button>)
          so the nested Edit button below is valid, non-nested markup. */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => setExpanded((e) => !e)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") setExpanded((v) => !v);
        }}
        className="flex w-full cursor-pointer items-center justify-between gap-3 p-4 text-left"
      >
        <div className="flex items-center gap-3">
          {expanded ? (
            <ChevronUp size={16} className="text-text-secondary" />
          ) : (
            <ChevronDown size={16} className="text-text-secondary" />
          )}
          <div>
            <p className="text-sm text-text-primary">{account.name}</p>
            <div className="mt-0.5 flex items-center gap-1.5">
              <Badge variant="neutral">{account.type ?? "other"}</Badge>
              {account.institution && (
                <span className="text-xs text-text-secondary">{account.institution}</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono text-sm text-text-primary">
            {formatCurrency(total, account.currency)}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEditAccount();
            }}
            aria-label="Edit account"
            className="rounded-card p-1 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
          >
            <Pencil size={14} />
          </button>
        </div>
      </div>

      {expanded && (
        <HoldingsTable
          holdings={holdings}
          currency={account.currency}
          onAdd={onAddHolding}
          onEdit={onEditHolding}
        />
      )}
    </Card>
  );
}
