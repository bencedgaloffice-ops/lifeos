import { StatCard } from "@/components/ui/StatCard";
import { formatCurrency } from "@/lib/utils/currency";
import { totalsByCurrency, allocationByType } from "../portfolio-math";
import { AllocationBreakdown } from "./AllocationBreakdown";
import type { InvestmentAccount, InvestmentHolding } from "../types";

interface PortfolioOverviewProps {
  accounts: InvestmentAccount[];
  holdingsByAccount: Map<string, InvestmentHolding[]>;
}

/**
 * One overview block per currency present — portfolio math never sums
 * across currencies (no live FX, none planned), so a person with both
 * a HUF and a USD account sees two independent summaries rather than
 * one misleading blended number.
 */
export function PortfolioOverview({ accounts, holdingsByAccount }: PortfolioOverviewProps) {
  const totals = totalsByCurrency(accounts, holdingsByAccount);

  if (totals.length === 0) return null;

  return (
    <div className="space-y-6">
      {totals.map(({ currency, currentValue, costBasis }) => {
        const gain = currentValue - costBasis;
        const gainPercent = costBasis > 0 ? (gain / costBasis) * 100 : 0;
        const slices = allocationByType(accounts, holdingsByAccount, currency);

        return (
          <div key={currency} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <StatCard label={`Portfolio value — ${currency}`} value={formatCurrency(currentValue, currency)} />
              <StatCard label="Cost basis" value={formatCurrency(costBasis, currency)} />
              <StatCard
                label="Unrealized gain/loss"
                value={formatCurrency(gain, currency)}
                delta={costBasis > 0 ? `${gain >= 0 ? "+" : ""}${gainPercent.toFixed(1)}%` : undefined}
                trend={gain >= 0 ? "up" : "down"}
              />
            </div>
            <AllocationBreakdown slices={slices} currency={currency} />
          </div>
        );
      })}
    </div>
  );
}
