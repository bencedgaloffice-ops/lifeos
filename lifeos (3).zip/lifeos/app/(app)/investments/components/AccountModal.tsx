"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import {
  investmentAccountFormSchema,
  type InvestmentAccountFormInput,
} from "@/lib/validations/investments";
import { SelectField } from "./SelectField";
import type { InvestmentAccount } from "../types";

interface AccountModalProps {
  mode: "create" | "edit";
  account?: InvestmentAccount;
  onClose: () => void;
  onSaved: (account: InvestmentAccount) => void;
  onDeleted: () => void;
}

export function AccountModal({ mode, account, onClose, onSaved, onDeleted }: AccountModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<InvestmentAccountFormInput>({
    resolver: zodResolver(investmentAccountFormSchema),
    defaultValues: account
      ? {
          name: account.name,
          institution: account.institution ?? "",
          type: account.type ?? "stocks",
          currency: account.currency,
        }
      : { name: "", institution: "", type: "stocks", currency: "HUF" },
  });

  const onSubmit = async (data: InvestmentAccountFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      name: data.name,
      institution: data.institution || null,
      type: data.type,
      currency: data.currency,
    };

    const { data: saved, error } =
      mode === "edit" && account
        ? await supabase.from("investment_accounts").update(payload).eq("id", account.id).select().single()
        : await supabase.from("investment_accounts").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!account) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("investment_accounts").delete().eq("id", account.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New investment account" : "Edit account"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Account name" error={errors.name?.message} {...register("name")} />
        <Input placeholder="Institution (optional)" {...register("institution")} />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="type"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="stocks">Stocks</option>
                <option value="crypto">Crypto</option>
                <option value="other">Other</option>
              </SelectField>
            )}
          />
          <Input placeholder="Currency (e.g. HUF)" {...register("currency")} />
        </div>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">
                  Delete this account and all its holdings?
                </span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create account"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
