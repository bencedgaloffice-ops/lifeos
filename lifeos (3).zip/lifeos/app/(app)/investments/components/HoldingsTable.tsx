import { Plus, Pencil } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { formatCurrency } from "@/lib/utils/currency";
import { holdingCurrentValue, holdingCostBasis } from "../portfolio-math";
import type { InvestmentHolding } from "../types";

interface HoldingsTableProps {
  holdings: InvestmentHolding[];
  currency: string;
  onAdd: () => void;
  onEdit: (holding: InvestmentHolding) => void;
}

export function HoldingsTable({ holdings, currency, onAdd, onEdit }: HoldingsTableProps) {
  return (
    <div className="border-t border-border-subtle p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">Holdings</p>
        <Button variant="ghost" size="sm" onClick={onAdd}>
          <Plus size={13} className="mr-1" />
          Add holding
        </Button>
      </div>

      {holdings.length === 0 ? (
        <p className="text-sm text-text-secondary">No holdings in this account yet.</p>
      ) : (
        <div className="divide-y divide-border-subtle">
          {holdings.map((holding) => {
            const currentValue = holdingCurrentValue(holding);
            const costBasis = holdingCostBasis(holding);
            const gain = currentValue - costBasis;
            const hasGain = holding.avg_cost != null;

            return (
              <button
                key={holding.id}
                onClick={() => onEdit(holding)}
                className="flex w-full items-center justify-between gap-3 py-2.5 text-left transition-colors hover:bg-white/[0.02]"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm text-text-primary">{holding.symbol}</span>
                  <span className="text-xs text-text-secondary">
                    {holding.quantity} units
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {hasGain && (
                    <Badge variant={gain >= 0 ? "success" : "danger"}>
                      {gain >= 0 ? "+" : ""}
                      {formatCurrency(gain, currency)}
                    </Badge>
                  )}
                  <span className="font-mono text-sm text-text-primary">
                    {formatCurrency(currentValue, currency)}
                  </span>
                  <Pencil size={12} className="text-text-secondary" />
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
