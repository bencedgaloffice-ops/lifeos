"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { holdingFormSchema, type HoldingFormInput } from "@/lib/validations/investments";
import type { InvestmentHolding } from "../types";

interface HoldingModalProps {
  mode: "create" | "edit";
  accountId: string;
  holding?: InvestmentHolding;
  onClose: () => void;
  onSaved: (holding: InvestmentHolding) => void;
  onDeleted: () => void;
}

export function HoldingModal({
  mode,
  accountId,
  holding,
  onClose,
  onSaved,
  onDeleted,
}: HoldingModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<HoldingFormInput>({
    resolver: zodResolver(holdingFormSchema),
    defaultValues: holding
      ? {
          symbol: holding.symbol,
          quantity: holding.quantity,
          avgCost: holding.avg_cost ?? undefined,
          currentValue: holding.current_value ?? undefined,
        }
      : { symbol: "", quantity: 0, avgCost: undefined, currentValue: undefined },
  });

  const onSubmit = async (data: HoldingFormInput) => {
    setSaveError(null);
    const supabase = createClient();

    const payload = {
      investment_account_id: accountId,
      symbol: data.symbol.toUpperCase(),
      quantity: data.quantity,
      avg_cost: data.avgCost ?? null,
      current_value: data.currentValue ?? null,
    };

    const { data: saved, error } =
      mode === "edit" && holding
        ? await supabase.from("investment_holdings").update(payload).eq("id", holding.id).select().single()
        : await supabase.from("investment_holdings").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!holding) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("investment_holdings").delete().eq("id", holding.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "Add holding" : "Edit holding"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input
          placeholder="Symbol (e.g. AAPL, BTC)"
          error={errors.symbol?.message}
          {...register("symbol")}
        />

        <Input
          type="number"
          step="any"
          placeholder="Quantity"
          error={errors.quantity?.message}
          {...register("quantity")}
        />

        <div className="grid grid-cols-2 gap-3">
          <Input
            type="number"
            step="0.01"
            placeholder="Avg. cost / unit (optional)"
            error={errors.avgCost?.message}
            {...register("avgCost")}
          />
          <Input
            type="number"
            step="0.01"
            placeholder="Current value (optional)"
            error={errors.currentValue?.message}
            {...register("currentValue")}
          />
        </div>
        <p className="-mt-2 text-xs text-text-secondary">
          Current value is the total position value — update it manually as prices change.
        </p>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this holding?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Add holding"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
