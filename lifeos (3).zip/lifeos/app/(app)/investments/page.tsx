import { createClient } from "@/lib/supabase/server";
import { InvestmentsShell } from "./components/InvestmentsShell";

export default async function InvestmentsPage() {
  const supabase = await createClient();

  const { data: accounts } = await supabase
    .from("investment_accounts")
    .select("*")
    .order("created_at", { ascending: true });

  const accountIds = (accounts ?? []).map((a) => a.id);
  const { data: holdings } =
    accountIds.length > 0
      ? await supabase.from("investment_holdings").select("*").in("investment_account_id", accountIds)
      : { data: [] };

  return <InvestmentsShell initialAccounts={accounts ?? []} initialHoldings={holdings ?? []} />;
}
