import type { InvestmentAccount, InvestmentHolding } from "./types";

/**
 * Interpretation of the schema (documented here since the columns
 * alone are ambiguous): `avg_cost` is the average cost *per unit*;
 * `current_value` is the manually-updated *total current value* of
 * the position (not a per-unit price). Falls back to quantity ×
 * avg_cost when current_value hasn't been set yet.
 */
export function holdingCurrentValue(holding: InvestmentHolding): number {
  if (holding.current_value != null) return holding.current_value;
  if (holding.avg_cost != null) return holding.quantity * holding.avg_cost;
  return 0;
}

export function holdingCostBasis(holding: InvestmentHolding): number {
  return holding.avg_cost != null ? holding.quantity * holding.avg_cost : 0;
}

export interface CurrencyTotals {
  currency: string;
  currentValue: number;
  costBasis: number;
}

/**
 * Portfolio math never sums across currencies (no live FX, none
 * planned) — totals are grouped by account currency instead.
 */
export function totalsByCurrency(
  accounts: InvestmentAccount[],
  holdingsByAccount: Map<string, InvestmentHolding[]>
): CurrencyTotals[] {
  const map = new Map<string, CurrencyTotals>();

  accounts.forEach((account) => {
    const holdings = holdingsByAccount.get(account.id) ?? [];
    const entry = map.get(account.currency) ?? {
      currency: account.currency,
      currentValue: 0,
      costBasis: 0,
    };
    holdings.forEach((holding) => {
      entry.currentValue += holdingCurrentValue(holding);
      entry.costBasis += holdingCostBasis(holding);
    });
    map.set(account.currency, entry);
  });

  return Array.from(map.values());
}

export interface AllocationSlice {
  type: string;
  currentValue: number;
  percent: number;
}

/** Allocation by account type, scoped to a single currency at a time. */
export function allocationByType(
  accounts: InvestmentAccount[],
  holdingsByAccount: Map<string, InvestmentHolding[]>,
  currency: string
): AllocationSlice[] {
  const totals = new Map<string, number>();
  let grandTotal = 0;

  accounts
    .filter((a) => a.currency === currency)
    .forEach((account) => {
      const holdings = holdingsByAccount.get(account.id) ?? [];
      const accountValue = holdings.reduce((sum, h) => sum + holdingCurrentValue(h), 0);
      const type = account.type ?? "other";
      totals.set(type, (totals.get(type) ?? 0) + accountValue);
      grandTotal += accountValue;
    });

  return Array.from(totals.entries()).map(([type, currentValue]) => ({
    type,
    currentValue,
    percent: grandTotal > 0 ? (currentValue / grandTotal) * 100 : 0,
  }));
}
