"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { projectFormSchema, type ProjectFormInput } from "@/lib/validations/projects";
import { SelectField } from "./SelectField";
import { OrganizationSelector } from "./OrganizationSelector";
import { LifeAreaSelector } from "./LifeAreaSelector";
import type { Project, Organization, LifeArea } from "../types";

interface ProjectModalProps {
  mode: "create" | "edit";
  project?: Project;
  organizations: Organization[];
  lifeAreas: LifeArea[];
  onClose: () => void;
  onSaved: (project: Project) => void;
  onDeleted: () => void;
}

export function ProjectModal({
  mode,
  project,
  organizations,
  lifeAreas,
  onClose,
  onSaved,
  onDeleted,
}: ProjectModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<ProjectFormInput>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: project
      ? {
          name: project.name,
          description: project.description ?? "",
          status: project.status,
          organizationId: project.organization_id ?? "",
          lifeAreaId: project.life_area_id ?? "",
        }
      : { name: "", description: "", status: "active", organizationId: "", lifeAreaId: "" },
  });

  const onSubmit = async (data: ProjectFormInput) => {
    setSaveError(null);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setSaveError("Your session expired — please sign in again.");
      return;
    }

    const payload = {
      user_id: user.id,
      name: data.name,
      description: data.description || null,
      status: data.status,
      organization_id: data.organizationId || null,
      life_area_id: data.lifeAreaId || null,
    };

    const { data: saved, error } =
      mode === "edit" && project
        ? await supabase.from("projects").update(payload).eq("id", project.id).select().single()
        : await supabase.from("projects").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!project) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("projects").delete().eq("id", project.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New project" : "Edit project"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Project name" error={errors.name?.message} {...register("name")} />

        <textarea
          placeholder="Description (optional)"
          rows={3}
          className="w-full rounded-card border border-border-subtle bg-glass px-3 py-2 text-sm text-text-primary placeholder:text-text-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          {...register("description")}
        />

        <Controller
          name="status"
          control={control}
          render={({ field }) => (
            <SelectField {...field}>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="done">Done</option>
            </SelectField>
          )}
        />

        <Controller
          name="organizationId"
          control={control}
          render={({ field }) => (
            <OrganizationSelector organizations={organizations} {...field} />
          )}
        />

        <Controller
          name="lifeAreaId"
          control={control}
          render={({ field }) => <LifeAreaSelector lifeAreas={lifeAreas} {...field} />}
        />

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this project?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Create project"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
