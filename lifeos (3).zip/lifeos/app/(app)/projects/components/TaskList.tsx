"use client";

import { Plus, CheckCircle2, Circle } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { TaskStatusBadge } from "./StatusBadge";
import { createClient } from "@/lib/supabase/client";
import type { ProjectTask } from "../types";

interface TaskListProps {
  tasks: ProjectTask[];
  onAdd: () => void;
  onEdit: (task: ProjectTask) => void;
  onToggled: (task: ProjectTask) => void;
}

export function TaskList({ tasks, onAdd, onEdit, onToggled }: TaskListProps) {
  const toggleDone = async (task: ProjectTask, e: React.MouseEvent) => {
    e.stopPropagation();
    const nextStatus = task.status === "done" ? "todo" : "done";
    const supabase = createClient();
    const { data: saved, error } = await supabase
      .from("project_tasks")
      .update({ status: nextStatus })
      .eq("id", task.id)
      .select()
      .single();
    if (!error && saved) onToggled(saved);
  };

  return (
    <Card className="p-0">
      <div className="flex items-center justify-between p-4">
        <h3 className="font-display text-sm font-medium text-text-primary">Tasks</h3>
        <Button variant="secondary" size="sm" onClick={onAdd}>
          <Plus size={14} className="mr-1.5" />
          Add task
        </Button>
      </div>

      {tasks.length === 0 ? (
        <div className="p-4 pt-0">
          <EmptyState
            title="No tasks yet"
            description="Break this project down into steps."
            action={
              <Button size="sm" onClick={onAdd}>
                <Plus size={14} className="mr-1.5" />
                Add task
              </Button>
            }
          />
        </div>
      ) : (
        <div className="divide-y divide-border-subtle">
          {tasks.map((task) => (
            <button
              key={task.id}
              onClick={() => onEdit(task)}
              className="flex w-full items-center gap-3 p-4 text-left transition-colors hover:bg-white/[0.02]"
            >
              <span
                onClick={(e) => toggleDone(task, e)}
                role="checkbox"
                aria-checked={task.status === "done"}
                className="shrink-0 text-text-secondary transition-colors hover:text-accent"
              >
                {task.status === "done" ? (
                  <CheckCircle2 size={18} className="text-success" />
                ) : (
                  <Circle size={18} />
                )}
              </span>
              <span
                className={
                  task.status === "done"
                    ? "flex-1 truncate text-sm text-text-secondary line-through"
                    : "flex-1 truncate text-sm text-text-primary"
                }
              >
                {task.title}
              </span>
              {task.due_date && (
                <span className="shrink-0 font-mono text-xs text-text-secondary">
                  {new Date(task.due_date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              )}
              <TaskStatusBadge status={task.status} />
            </button>
          ))}
        </div>
      )}
    </Card>
  );
}
