import { Badge } from "@/components/ui/Badge";
import type { ProjectStatus, TaskStatus } from "../types";

const PROJECT_STATUS_STYLE: Record<ProjectStatus, { label: string; variant: "accent" | "warning" | "success" }> = {
  active: { label: "Active", variant: "accent" },
  paused: { label: "Paused", variant: "warning" },
  done: { label: "Done", variant: "success" },
};

const TASK_STATUS_STYLE: Record<TaskStatus, { label: string; variant: "neutral" | "accent" | "success" }> = {
  todo: { label: "To do", variant: "neutral" },
  in_progress: { label: "In progress", variant: "accent" },
  done: { label: "Done", variant: "success" },
};

export function ProjectStatusBadge({ status }: { status: ProjectStatus }) {
  const style = PROJECT_STATUS_STYLE[status];
  return <Badge variant={style.variant}>{style.label}</Badge>;
}

export function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const style = TASK_STATUS_STYLE[status];
  return <Badge variant={style.variant}>{style.label}</Badge>;
}
