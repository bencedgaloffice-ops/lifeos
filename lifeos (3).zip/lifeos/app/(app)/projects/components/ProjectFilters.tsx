import { Search } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { SelectField } from "./SelectField";
import { OrganizationSelector } from "./OrganizationSelector";
import { LifeAreaSelector } from "./LifeAreaSelector";
import type { Organization, LifeArea, StatusFilter } from "../types";

interface ProjectFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  status: StatusFilter;
  onStatusChange: (value: StatusFilter) => void;
  organizationId: string;
  onOrganizationChange: (value: string) => void;
  lifeAreaId: string;
  onLifeAreaChange: (value: string) => void;
  organizations: Organization[];
  lifeAreas: LifeArea[];
}

export function ProjectFilters({
  search,
  onSearchChange,
  status,
  onStatusChange,
  organizationId,
  onOrganizationChange,
  lifeAreaId,
  onLifeAreaChange,
  organizations,
  lifeAreas,
}: ProjectFiltersProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
      <div className="relative flex-1 sm:min-w-[200px]">
        <Search
          size={14}
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary"
        />
        <Input
          placeholder="Search projects…"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-8"
        />
      </div>

      <SelectField
        value={status}
        onChange={(e) => onStatusChange(e.target.value as StatusFilter)}
        className="sm:w-40"
      >
        <option value="all">All statuses</option>
        <option value="active">Active</option>
        <option value="paused">Paused</option>
        <option value="done">Done</option>
      </SelectField>

      <OrganizationSelector
        organizations={organizations}
        emptyLabel="All organizations"
        value={organizationId}
        onChange={(e) => onOrganizationChange(e.target.value)}
        className="sm:w-48"
      />

      <LifeAreaSelector
        lifeAreas={lifeAreas}
        emptyLabel="All life areas"
        value={lifeAreaId}
        onChange={(e) => onLifeAreaChange(e.target.value)}
        className="sm:w-44"
      />
    </div>
  );
}
