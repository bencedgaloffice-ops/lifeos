import { forwardRef } from "react";
import { SelectField } from "./SelectField";
import type { Organization } from "../types";

interface OrganizationSelectorProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "children"> {
  organizations: Organization[];
  /** Label for the unset option — differs between a form ("No organization") and a filter ("All organizations"). */
  emptyLabel?: string;
}

export const OrganizationSelector = forwardRef<HTMLSelectElement, OrganizationSelectorProps>(
  ({ organizations, emptyLabel = "No organization", ...props }, ref) => (
    <SelectField ref={ref} {...props}>
      <option value="">{emptyLabel}</option>
      {organizations.map((org) => (
        <option key={org.id} value={org.id}>
          {org.name}
        </option>
      ))}
    </SelectField>
  )
);
OrganizationSelector.displayName = "OrganizationSelector";
