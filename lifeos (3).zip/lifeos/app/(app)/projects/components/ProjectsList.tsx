import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "./EmptyState";
import { ProjectCard } from "./ProjectCard";
import type { Project, Organization, LifeArea, ProjectTask } from "../types";

interface ProjectsListProps {
  projects: Project[];
  organizationById: Map<string, Organization>;
  lifeAreaById: Map<string, LifeArea>;
  tasksByProject: Map<string, ProjectTask[]>;
  onEdit: (project: Project) => void;
  onCreate: () => void;
  hasAnyProjects: boolean;
}

export function ProjectsList({
  projects,
  organizationById,
  lifeAreaById,
  tasksByProject,
  onEdit,
  onCreate,
  hasAnyProjects,
}: ProjectsListProps) {
  if (projects.length === 0) {
    return (
      <EmptyState
        title={hasAnyProjects ? "No projects match your filters" : "No projects yet"}
        description={
          hasAnyProjects
            ? "Try adjusting your search or filters."
            : "Create your first project — for ICSB, the security business, the ranch, or anything else."
        }
        action={
          !hasAnyProjects && (
            <Button size="sm" onClick={onCreate}>
              <Plus size={14} className="mr-1.5" />
              New project
            </Button>
          )
        }
      />
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {projects.map((project) => (
        <ProjectCard
          key={project.id}
          project={project}
          organization={project.organization_id ? organizationById.get(project.organization_id) : undefined}
          lifeArea={project.life_area_id ? lifeAreaById.get(project.life_area_id) : undefined}
          tasks={tasksByProject.get(project.id) ?? []}
          onEdit={() => onEdit(project)}
        />
      ))}
    </div>
  );
}
