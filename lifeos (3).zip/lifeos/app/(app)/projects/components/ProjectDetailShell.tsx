"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Pencil, Trash2, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Tag } from "@/components/ui/Tag";
import { createClient } from "@/lib/supabase/client";
import { SelectField } from "./SelectField";
import { ProgressIndicator } from "./ProgressIndicator";
import { TaskList } from "./TaskList";
import { TaskModal } from "./TaskModal";
import { ProjectModal } from "./ProjectModal";
import type { Project, ProjectTask, Organization, LifeArea, ProjectStatus } from "../types";

interface ProjectDetailShellProps {
  initialProject: Project;
  initialTasks: ProjectTask[];
  organization?: Organization;
  lifeArea?: LifeArea;
  organizations: Organization[];
  lifeAreas: LifeArea[];
}

type TaskModalState = { mode: "closed" } | { mode: "create" } | { mode: "edit"; task: ProjectTask };

export function ProjectDetailShell({
  initialProject,
  initialTasks,
  organization,
  lifeArea,
  organizations,
  lifeAreas,
}: ProjectDetailShellProps) {
  const router = useRouter();
  const [project, setProject] = useState(initialProject);
  const [tasks, setTasks] = useState(initialTasks);
  const [taskModal, setTaskModal] = useState<TaskModalState>({ mode: "closed" });
  const [editingProject, setEditingProject] = useState(false);
  const [statusSaving, setStatusSaving] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const completed = tasks.filter((t) => t.status === "done").length;

  const handleStatusChange = async (status: ProjectStatus) => {
    setStatusSaving(true);
    const supabase = createClient();
    const { data: saved, error } = await supabase
      .from("projects")
      .update({ status })
      .eq("id", project.id)
      .select()
      .single();
    setStatusSaving(false);
    if (!error && saved) setProject(saved);
  };

  const handleDeleteProject = async () => {
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("projects").delete().eq("id", project.id);
    setDeleting(false);
    if (!error) {
      router.push("/projects");
      router.refresh();
    }
  };

  const handleTaskSaved = (task: ProjectTask) => {
    setTasks((prev) => {
      const exists = prev.some((t) => t.id === task.id);
      return exists ? prev.map((t) => (t.id === task.id ? task : t)) : [task, ...prev];
    });
    setTaskModal({ mode: "closed" });
  };

  const handleTaskDeleted = () => {
    if (taskModal.mode === "edit") {
      setTasks((prev) => prev.filter((t) => t.id !== taskModal.task.id));
    }
    setTaskModal({ mode: "closed" });
  };

  const handleTaskToggled = (task: ProjectTask) => {
    setTasks((prev) => prev.map((t) => (t.id === task.id ? task : t)));
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={project.name}
        description={project.description ?? undefined}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => setEditingProject(true)}>
              <Pencil size={14} className="mr-1.5" />
              Edit
            </Button>
            {confirmingDelete ? (
              <div className="flex items-center gap-2">
                <Button
                  variant="danger"
                  size="sm"
                  disabled={deleting}
                  onClick={handleDeleteProject}
                >
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm delete"}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <Button variant="ghost" size="sm" onClick={() => setConfirmingDelete(true)}>
                <Trash2 size={14} className="mr-1.5" />
                Delete
              </Button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="flex flex-col gap-3">
          <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">Status</p>
          <SelectField
            value={project.status}
            disabled={statusSaving}
            onChange={(e) => handleStatusChange(e.target.value as ProjectStatus)}
          >
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="done">Done</option>
          </SelectField>
        </Card>

        <Card className="flex flex-col gap-2">
          <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">Context</p>
          <div className="flex flex-wrap gap-1.5">
            {organization && <Tag>{organization.name}</Tag>}
            {lifeArea && <Tag color={lifeArea.color ?? undefined}>{lifeArea.name}</Tag>}
            {!organization && !lifeArea && (
              <span className="text-sm text-text-secondary">Not linked yet</span>
            )}
          </div>
        </Card>

        <Card className="flex flex-col gap-2">
          <p className="font-mono text-xs uppercase tracking-wider text-text-secondary">Progress</p>
          <ProgressIndicator completed={completed} total={tasks.length} />
        </Card>
      </div>

      <TaskList
        tasks={tasks}
        onAdd={() => setTaskModal({ mode: "create" })}
        onEdit={(task) => setTaskModal({ mode: "edit", task })}
        onToggled={handleTaskToggled}
      />

      {taskModal.mode !== "closed" && (
        <TaskModal
          mode={taskModal.mode}
          projectId={project.id}
          task={taskModal.mode === "edit" ? taskModal.task : undefined}
          onClose={() => setTaskModal({ mode: "closed" })}
          onSaved={handleTaskSaved}
          onDeleted={handleTaskDeleted}
        />
      )}

      {editingProject && (
        <ProjectModal
          mode="edit"
          project={project}
          organizations={organizations}
          lifeAreas={lifeAreas}
          onClose={() => setEditingProject(false)}
          onSaved={(saved) => {
            setProject(saved);
            setEditingProject(false);
          }}
          onDeleted={() => {
            router.push("/projects");
            router.refresh();
          }}
        />
      )}
    </div>
  );
}
