"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { ProjectFilters } from "./ProjectFilters";
import { ProjectsList } from "./ProjectsList";
import { ProjectModal } from "./ProjectModal";
import type { Project, Organization, LifeArea, ProjectTask, StatusFilter } from "../types";

interface ProjectShellProps {
  initialProjects: Project[];
  organizations: Organization[];
  lifeAreas: LifeArea[];
  tasks: ProjectTask[];
}

type ModalState = { mode: "closed" } | { mode: "create" } | { mode: "edit"; project: Project };

export function ProjectShell({
  initialProjects,
  organizations,
  lifeAreas,
  tasks,
}: ProjectShellProps) {
  const [projects, setProjects] = useState(initialProjects);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [organizationId, setOrganizationId] = useState("");
  const [lifeAreaId, setLifeAreaId] = useState("");
  const [modal, setModal] = useState<ModalState>({ mode: "closed" });

  const organizationById = useMemo(() => {
    const map = new Map<string, Organization>();
    organizations.forEach((o) => map.set(o.id, o));
    return map;
  }, [organizations]);

  const lifeAreaById = useMemo(() => {
    const map = new Map<string, LifeArea>();
    lifeAreas.forEach((a) => map.set(a.id, a));
    return map;
  }, [lifeAreas]);

  const tasksByProject = useMemo(() => {
    const map = new Map<string, ProjectTask[]>();
    tasks.forEach((task) => {
      const list = map.get(task.project_id) ?? [];
      list.push(task);
      map.set(task.project_id, list);
    });
    return map;
  }, [tasks]);

  const filteredProjects = useMemo(() => {
    const query = search.trim().toLowerCase();
    return projects.filter((project) => {
      if (status !== "all" && project.status !== status) return false;
      if (organizationId && project.organization_id !== organizationId) return false;
      if (lifeAreaId && project.life_area_id !== lifeAreaId) return false;
      if (query && !project.name.toLowerCase().includes(query)) return false;
      return true;
    });
  }, [projects, search, status, organizationId, lifeAreaId]);

  const handleSaved = (saved: Project) => {
    setProjects((prev) => {
      const exists = prev.some((p) => p.id === saved.id);
      return exists ? prev.map((p) => (p.id === saved.id ? saved : p)) : [saved, ...prev];
    });
    setModal({ mode: "closed" });
  };

  const handleDeleted = () => {
    if (modal.mode === "edit") {
      setProjects((prev) => prev.filter((p) => p.id !== modal.project.id));
    }
    setModal({ mode: "closed" });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Projects"
        description="Everything in motion — ICSB, the security business, the ranch, and beyond."
        actions={
          <Button size="sm" onClick={() => setModal({ mode: "create" })}>
            <Plus size={14} className="mr-1.5" />
            New project
          </Button>
        }
      />

      <ProjectFilters
        search={search}
        onSearchChange={setSearch}
        status={status}
        onStatusChange={setStatus}
        organizationId={organizationId}
        onOrganizationChange={setOrganizationId}
        lifeAreaId={lifeAreaId}
        onLifeAreaChange={setLifeAreaId}
        organizations={organizations}
        lifeAreas={lifeAreas}
      />

      <ProjectsList
        projects={filteredProjects}
        organizationById={organizationById}
        lifeAreaById={lifeAreaById}
        tasksByProject={tasksByProject}
        onEdit={(project) => setModal({ mode: "edit", project })}
        onCreate={() => setModal({ mode: "create" })}
        hasAnyProjects={projects.length > 0}
      />

      {modal.mode !== "closed" && (
        <ProjectModal
          mode={modal.mode}
          project={modal.mode === "edit" ? modal.project : undefined}
          organizations={organizations}
          lifeAreas={lifeAreas}
          onClose={() => setModal({ mode: "closed" })}
          onSaved={handleSaved}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
