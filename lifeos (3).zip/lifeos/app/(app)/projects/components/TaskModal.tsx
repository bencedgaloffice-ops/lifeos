"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Trash2 } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { FormStatus } from "@/components/shared/FormStatus";
import { createClient } from "@/lib/supabase/client";
import { taskFormSchema, type TaskFormInput } from "@/lib/validations/projects";
import { SelectField } from "./SelectField";
import type { ProjectTask } from "../types";

interface TaskModalProps {
  mode: "create" | "edit";
  projectId: string;
  task?: ProjectTask;
  onClose: () => void;
  onSaved: (task: ProjectTask) => void;
  onDeleted: () => void;
}

export function TaskModal({ mode, projectId, task, onClose, onSaved, onDeleted }: TaskModalProps) {
  const [saveError, setSaveError] = useState<string | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<TaskFormInput>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: task
      ? { title: task.title, status: task.status, dueDate: task.due_date ?? "" }
      : { title: "", status: "todo", dueDate: "" },
  });

  const onSubmit = async (data: TaskFormInput) => {
    setSaveError(null);
    const supabase = createClient();

    const payload = {
      project_id: projectId,
      title: data.title,
      status: data.status,
      due_date: data.dueDate || null,
    };

    const { data: saved, error } =
      mode === "edit" && task
        ? await supabase.from("project_tasks").update(payload).eq("id", task.id).select().single()
        : await supabase.from("project_tasks").insert(payload).select().single();

    if (error || !saved) {
      setSaveError(error?.message ?? "Something went wrong.");
      return;
    }
    onSaved(saved);
  };

  const handleDelete = async () => {
    if (!task) return;
    setDeleting(true);
    const supabase = createClient();
    const { error } = await supabase.from("project_tasks").delete().eq("id", task.id);
    setDeleting(false);
    if (error) {
      setSaveError(error.message);
      return;
    }
    onDeleted();
  };

  return (
    <Modal open onClose={onClose} title={mode === "create" ? "New task" : "Edit task"}>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3" noValidate>
        <Input placeholder="Task title" error={errors.title?.message} {...register("title")} />

        <div className="grid grid-cols-2 gap-3">
          <Controller
            name="status"
            control={control}
            render={({ field }) => (
              <SelectField {...field}>
                <option value="todo">To do</option>
                <option value="in_progress">In progress</option>
                <option value="done">Done</option>
              </SelectField>
            )}
          />
          <Input type="date" {...register("dueDate")} />
        </div>

        {saveError && <FormStatus variant="error">{saveError}</FormStatus>}

        <div className="mt-2 flex items-center justify-between">
          {mode === "edit" ? (
            confirmingDelete ? (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-text-secondary">Delete this task?</span>
                <Button type="button" variant="danger" size="sm" disabled={deleting} onClick={handleDelete}>
                  {deleting ? <Loader2 size={14} className="animate-spin" /> : "Confirm"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setConfirmingDelete(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="flex items-center gap-1.5 text-xs text-danger hover:underline"
              >
                <Trash2 size={14} />
                Delete
              </button>
            )
          ) : (
            <span />
          )}

          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Saving…
              </span>
            ) : mode === "create" ? (
              "Add task"
            ) : (
              "Save changes"
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
