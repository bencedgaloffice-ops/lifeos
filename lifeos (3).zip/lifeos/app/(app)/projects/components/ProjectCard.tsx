"use client";

import Link from "next/link";
import { Pencil } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Tag } from "@/components/ui/Tag";
import { ProjectStatusBadge } from "./StatusBadge";
import { ProgressIndicator } from "./ProgressIndicator";
import type { Project, Organization, LifeArea, ProjectTask } from "../types";

interface ProjectCardProps {
  project: Project;
  organization?: Organization;
  lifeArea?: LifeArea;
  tasks: ProjectTask[];
  onEdit: () => void;
}

export function ProjectCard({ project, organization, lifeArea, tasks, onEdit }: ProjectCardProps) {
  const completed = tasks.filter((t) => t.status === "done").length;

  return (
    <Card className="flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <Link href={`/projects/${project.id}`} className="min-w-0 flex-1">
          <h3 className="truncate font-display text-sm font-medium text-text-primary hover:text-accent">
            {project.name}
          </h3>
        </Link>
        <button
          onClick={onEdit}
          aria-label="Edit project"
          className="shrink-0 rounded-card p-1 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
        >
          <Pencil size={14} />
        </button>
      </div>

      {project.description && (
        <p className="line-clamp-2 text-xs text-text-secondary">{project.description}</p>
      )}

      <div className="flex flex-wrap items-center gap-1.5">
        <ProjectStatusBadge status={project.status} />
        {organization && <Tag>{organization.name}</Tag>}
        {lifeArea && <Tag color={lifeArea.color ?? undefined}>{lifeArea.name}</Tag>}
      </div>

      <ProgressIndicator completed={completed} total={tasks.length} />
    </Card>
  );
}
