import { type SelectHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils/cn";

/**
 * Projects-module-local select, matching the pattern already
 * established by Calendar's and Money's own SelectField copies —
 * each module owns its own, none shared, none added to components/ui.
 */
export const SelectField = forwardRef<
  HTMLSelectElement,
  SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select
    ref={ref}
    className={cn(
      "h-10 w-full rounded-card border border-border-subtle bg-glass px-3 text-sm text-text-primary",
      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent",
      className
    )}
    {...props}
  >
    {children}
  </select>
));
SelectField.displayName = "SelectField";
