import { cn } from "@/lib/utils/cn";

interface ProgressIndicatorProps {
  completed: number;
  total: number;
  className?: string;
}

export function ProgressIndicator({ completed, total, className }: ProgressIndicatorProps) {
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <div className="flex items-center justify-between text-xs text-text-secondary">
        <span>
          {total > 0 ? `${completed}/${total} tasks` : "No tasks yet"}
        </span>
        {total > 0 && <span className="font-mono">{percent}%</span>}
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
        <div
          className="h-full rounded-full bg-accent transition-all"
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}
