import { createClient } from "@/lib/supabase/server";
import { ProjectShell } from "./components/ProjectShell";

export default async function ProjectsPage() {
  const supabase = await createClient();

  const [{ data: projects }, { data: organizations }, { data: lifeAreas }] = await Promise.all([
    supabase.from("projects").select("*").order("created_at", { ascending: false }),
    supabase.from("organizations").select("*").order("name", { ascending: true }),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
  ]);

  const projectIds = (projects ?? []).map((p) => p.id);
  const { data: tasks } =
    projectIds.length > 0
      ? await supabase.from("project_tasks").select("*").in("project_id", projectIds)
      : { data: [] };

  return (
    <ProjectShell
      initialProjects={projects ?? []}
      organizations={organizations ?? []}
      lifeAreas={lifeAreas ?? []}
      tasks={tasks ?? []}
    />
  );
}
