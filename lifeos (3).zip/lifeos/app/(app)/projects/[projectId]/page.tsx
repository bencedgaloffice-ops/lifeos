import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ProjectDetailShell } from "../components/ProjectDetailShell";

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ projectId: string }>;
}) {
  const { projectId } = await params;
  const supabase = await createClient();

  const [{ data: project }, { data: tasks }, { data: organizations }, { data: lifeAreas }] =
    await Promise.all([
      supabase.from("projects").select("*").eq("id", projectId).single(),
      supabase
        .from("project_tasks")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false }),
      supabase.from("organizations").select("*").order("name", { ascending: true }),
      supabase.from("life_areas").select("*").order("name", { ascending: true }),
    ]);

  if (!project) {
    notFound();
  }

  const organization = organizations?.find((o) => o.id === project.organization_id);
  const lifeArea = lifeAreas?.find((a) => a.id === project.life_area_id);

  return (
    <ProjectDetailShell
      initialProject={project}
      initialTasks={tasks ?? []}
      organization={organization}
      lifeArea={lifeArea}
      organizations={organizations ?? []}
      lifeAreas={lifeAreas ?? []}
    />
  );
}
