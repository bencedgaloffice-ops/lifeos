import type { Database } from "@/types/supabase";

export type Project = Database["public"]["Tables"]["projects"]["Row"];
export type ProjectTask = Database["public"]["Tables"]["project_tasks"]["Row"];
export type Organization = Database["public"]["Tables"]["organizations"]["Row"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];

export type ProjectStatus = Project["status"];
export type TaskStatus = ProjectTask["status"];

export type StatusFilter = "all" | ProjectStatus;
