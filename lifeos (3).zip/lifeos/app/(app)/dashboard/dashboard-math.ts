import type {
  ProjectTask,
  InvestmentAccount,
  InvestmentHolding,
  Goal,
  LifeArea,
} from "./types";

/**
 * Dashboard-local computations. Deliberately duplicated rather than
 * importing from Projects'/Investments' own module folders — each
 * module owns its logic; the dashboard recomputes the small subset it
 * needs from raw rows, same convention as every module's local
 * SelectField copies.
 */

export function projectProgress(tasks: ProjectTask[]) {
  const completed = tasks.filter((t) => t.status === "done").length;
  return { completed, total: tasks.length };
}

/** Same avg_cost/current_value interpretation as Investments' own portfolio-math.ts. */
function holdingCurrentValue(holding: InvestmentHolding): number {
  if (holding.current_value != null) return holding.current_value;
  if (holding.avg_cost != null) return holding.quantity * holding.avg_cost;
  return 0;
}

export interface CurrencyTotal {
  currency: string;
  value: number;
}

/** Never sums across currencies — same reasoning as Investments' own totals. */
export function investmentTotalsByCurrency(
  accounts: InvestmentAccount[],
  holdingsByAccount: Map<string, InvestmentHolding[]>
): CurrencyTotal[] {
  const totals = new Map<string, number>();
  accounts.forEach((account) => {
    const holdings = holdingsByAccount.get(account.id) ?? [];
    const sum = holdings.reduce((s, h) => s + holdingCurrentValue(h), 0);
    totals.set(account.currency, (totals.get(account.currency) ?? 0) + sum);
  });
  return Array.from(totals.entries()).map(([currency, value]) => ({ currency, value }));
}

export interface LifeAreaProgress {
  lifeArea: LifeArea;
  /** null when no goals are linked yet — never fabricated. */
  averageProgress: number | null;
  linkedGoalCount: number;
}

export function lifeAreaProgress(lifeAreas: LifeArea[], goals: Goal[]): LifeAreaProgress[] {
  return lifeAreas.map((lifeArea) => {
    const linked = goals.filter((g) => g.life_area_id === lifeArea.id);
    const averageProgress =
      linked.length > 0
        ? Math.round(linked.reduce((sum, g) => sum + g.progress_percent, 0) / linked.length)
        : null;
    return { lifeArea, averageProgress, linkedGoalCount: linked.length };
  });
}

export function isToday(dateStr: string) {
  const date = new Date(dateStr);
  const now = new Date();
  return (
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate()
  );
}

export function daysUntil(dateStr: string) {
  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

export function timeOfDayGreeting(date: Date) {
  const hour = date.getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}
