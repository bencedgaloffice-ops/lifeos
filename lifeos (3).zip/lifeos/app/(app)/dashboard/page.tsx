import { createClient } from "@/lib/supabase/server";
import { WelcomeSection } from "./components/WelcomeSection";
import { TodayCard } from "./components/TodayCard";
import { ActiveProjectsCard } from "./components/ActiveProjectsCard";
import { UpcomingDeadlinesCard } from "./components/UpcomingDeadlinesCard";
import { FinancialSnapshotCard } from "./components/FinancialSnapshotCard";
import { InvestmentOverviewCard } from "./components/InvestmentOverviewCard";
import { GoalsProgressCard } from "./components/GoalsProgressCard";
import { DreamsPreviewCard } from "./components/DreamsPreviewCard";
import { LifeAreasBalanceCard } from "./components/LifeAreasBalanceCard";
import { RecentActivityTimeline } from "./components/RecentActivityTimeline";
import type {
  Project,
  ProjectTask,
  InvestmentHolding,
} from "./types";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfTomorrow = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

  const [
    { data: profile },
    { data: todayEvents },
    { data: projects },
    { data: tasks },
    { data: goals },
    { data: dreams },
    { data: recentJournalEntries },
    { data: recentDocuments },
    { data: accounts },
    { data: monthTransactions },
    { data: recentTransactions },
    { data: investmentAccounts },
    { data: investmentHoldings },
    { data: lifeAreas },
  ] = await Promise.all([
    user ? supabase.from("profiles").select("*").eq("id", user.id).single() : { data: null },
    supabase
      .from("calendar_events")
      .select("*")
      .gte("start_at", startOfToday.toISOString())
      .lt("start_at", startOfTomorrow.toISOString())
      .order("start_at", { ascending: true }),
    supabase.from("projects").select("*").order("created_at", { ascending: false }),
    // RLS scopes this to tasks whose parent project belongs to the
    // current user — no explicit filter needed.
    supabase.from("project_tasks").select("*"),
    supabase.from("goals").select("*").order("created_at", { ascending: false }),
    supabase.from("dreams").select("*").order("order_index", { ascending: true }),
    supabase.from("journal_entries").select("*").order("created_at", { ascending: false }).limit(10),
    supabase.from("documents").select("*").order("uploaded_at", { ascending: false }).limit(10),
    supabase.from("accounts").select("*"),
    supabase
      .from("transactions")
      .select("*")
      .gte("occurred_at", startOfMonth.toISOString())
      .lt("occurred_at", startOfNextMonth.toISOString()),
    supabase.from("transactions").select("*").order("occurred_at", { ascending: false }).limit(10),
    supabase.from("investment_accounts").select("*"),
    // Same RLS-scoping note as project_tasks above.
    supabase.from("investment_holdings").select("*"),
    supabase.from("life_areas").select("*").order("name", { ascending: true }),
  ]);

  const tasksByProject = new Map<string, ProjectTask[]>();
  (tasks ?? []).forEach((task) => {
    const list = tasksByProject.get(task.project_id) ?? [];
    list.push(task);
    tasksByProject.set(task.project_id, list);
  });

  const projectById = new Map<string, Project>();
  (projects ?? []).forEach((p) => projectById.set(p.id, p));

  const holdingsByAccount = new Map<string, InvestmentHolding[]>();
  (investmentHoldings ?? []).forEach((holding) => {
    const list = holdingsByAccount.get(holding.investment_account_id) ?? [];
    list.push(holding);
    holdingsByAccount.set(holding.investment_account_id, list);
  });

  const displayName = profile?.display_name || user?.email?.split("@")[0] || "there";

  return (
    <div className="space-y-6">
      <WelcomeSection name={displayName} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <TodayCard events={todayEvents ?? []} />
        </div>
        <UpcomingDeadlinesCard
          tasks={tasks ?? []}
          projectById={projectById}
          goals={goals ?? []}
        />
      </div>

      <FinancialSnapshotCard accounts={accounts ?? []} monthTransactions={monthTransactions ?? []} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ActiveProjectsCard projects={projects ?? []} tasksByProject={tasksByProject} />
        <GoalsProgressCard goals={goals ?? []} />
        <InvestmentOverviewCard
          accounts={investmentAccounts ?? []}
          holdingsByAccount={holdingsByAccount}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <DreamsPreviewCard dreams={dreams ?? []} />
        <LifeAreasBalanceCard lifeAreas={lifeAreas ?? []} goals={goals ?? []} />
        <RecentActivityTimeline
          journalEntries={recentJournalEntries ?? []}
          documents={recentDocuments ?? []}
          transactions={recentTransactions ?? []}
        />
      </div>
    </div>
  );
}
