import type { Database } from "@/types/supabase";

export type CalendarEvent = Database["public"]["Tables"]["calendar_events"]["Row"];
export type Project = Database["public"]["Tables"]["projects"]["Row"];
export type ProjectTask = Database["public"]["Tables"]["project_tasks"]["Row"];
export type Goal = Database["public"]["Tables"]["goals"]["Row"];
export type Dream = Database["public"]["Tables"]["dreams"]["Row"];
export type JournalEntry = Database["public"]["Tables"]["journal_entries"]["Row"];
export type Document = Database["public"]["Tables"]["documents"]["Row"];
export type Transaction = Database["public"]["Tables"]["transactions"]["Row"];
export type Account = Database["public"]["Tables"]["accounts"]["Row"];
export type InvestmentAccount = Database["public"]["Tables"]["investment_accounts"]["Row"];
export type InvestmentHolding = Database["public"]["Tables"]["investment_holdings"]["Row"];
export type LifeArea = Database["public"]["Tables"]["life_areas"]["Row"];
