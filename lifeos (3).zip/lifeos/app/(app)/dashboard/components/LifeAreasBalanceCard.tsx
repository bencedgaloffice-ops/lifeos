import { Layers } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import { lifeAreaProgress } from "../dashboard-math";
import type { LifeArea, Goal } from "../types";

interface LifeAreasBalanceCardProps {
  lifeAreas: LifeArea[];
  goals: Goal[];
}

/**
 * Shows real life_areas rows only — there's no dedicated Life Areas
 * management UI yet (that module hasn't been built), so this list is
 * genuinely empty until one exists. No placeholder categories
 * (Faith/Health/Career/etc.) are fabricated here; per-area progress
 * is only shown when goals are actually linked via life_area_id.
 */
export function LifeAreasBalanceCard({ lifeAreas, goals }: LifeAreasBalanceCardProps) {
  const progress = lifeAreaProgress(lifeAreas, goals);

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Layers size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Life areas</h3>
      </div>

      {progress.length === 0 ? (
        <EmptyState message="No life areas set up yet — that management screen is coming in a later phase." />
      ) : (
        <div className="flex flex-col gap-3">
          {progress.map(({ lifeArea, averageProgress, linkedGoalCount }) => (
            <div key={lifeArea.id}>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-text-primary">
                  {lifeArea.color && (
                    <span
                      className="h-1.5 w-1.5 rounded-full"
                      style={{ backgroundColor: lifeArea.color }}
                    />
                  )}
                  {lifeArea.name}
                </span>
                <span className="font-mono text-xs text-text-secondary">
                  {averageProgress !== null ? `${averageProgress}%` : "No goals linked"}
                </span>
              </div>
              {averageProgress !== null && (
                <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className="h-full rounded-full bg-accent transition-all"
                    style={{ width: `${averageProgress}%` }}
                  />
                </div>
              )}
              {linkedGoalCount > 0 && (
                <p className="mt-0.5 text-[11px] text-text-secondary">
                  Based on {linkedGoalCount} goal{linkedGoalCount === 1 ? "" : "s"}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
