import { BookOpen, FileText, Wallet } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import { formatCurrency } from "@/lib/utils/currency";
import type { JournalEntry, Document, Transaction } from "../types";

interface RecentActivityTimelineProps {
  journalEntries: JournalEntry[];
  documents: Document[];
  transactions: Transaction[];
}

type ActivityItem = {
  id: string;
  icon: typeof BookOpen;
  label: string;
  timestamp: string;
};

function relativeTime(timestamp: string) {
  const diffMs = Date.now() - new Date(timestamp).getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  if (diffHours < 1) return "Just now";
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function RecentActivityTimeline({
  journalEntries,
  documents,
  transactions,
}: RecentActivityTimelineProps) {
  const items: ActivityItem[] = [
    ...journalEntries.map((entry) => ({
      id: `journal-${entry.id}`,
      icon: BookOpen,
      label: `Journal entry: ${entry.title || "Untitled"}`,
      timestamp: entry.created_at,
    })),
    ...documents.map((doc) => ({
      id: `document-${doc.id}`,
      icon: FileText,
      label: `Uploaded: ${doc.title}`,
      timestamp: doc.uploaded_at,
    })),
    ...transactions.map((tx) => ({
      id: `transaction-${tx.id}`,
      icon: Wallet,
      label: `${tx.direction === "income" ? "Income" : "Expense"}: ${
        tx.description || formatCurrency(tx.amount, tx.currency)
      }`,
      timestamp: tx.occurred_at,
    })),
  ]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 8);

  return (
    <Card>
      <h3 className="mb-4 font-display text-sm font-medium text-text-primary">Recent activity</h3>

      {items.length === 0 ? (
        <EmptyState message="Nothing logged yet — activity across Journal, Documents, and Money will show up here." />
      ) : (
        <div className="flex flex-col gap-3">
          {items.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.id} className="flex items-center gap-3 text-sm">
                <Icon size={14} className="shrink-0 text-text-secondary" />
                <span className="min-w-0 flex-1 truncate text-text-primary">{item.label}</span>
                <span className="shrink-0 font-mono text-xs text-text-secondary">
                  {relativeTime(item.timestamp)}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
