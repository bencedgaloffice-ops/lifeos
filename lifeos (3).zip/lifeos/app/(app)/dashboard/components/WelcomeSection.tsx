import { timeOfDayGreeting } from "../dashboard-math";

interface WelcomeSectionProps {
  name: string;
}

export function WelcomeSection({ name }: WelcomeSectionProps) {
  const now = new Date();
  const greeting = timeOfDayGreeting(now);
  const dateLabel = now.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  return (
    <div>
      <p className="font-mono text-xs uppercase tracking-widest text-text-secondary">
        {dateLabel}
      </p>
      <h1 className="mt-1 font-display text-3xl font-semibold text-text-primary">
        {greeting}, {name}
      </h1>
    </div>
  );
}
