import Link from "next/link";
import { Sparkles } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import type { Dream } from "../types";

interface DreamsPreviewCardProps {
  dreams: Dream[];
}

/**
 * Plain <img>, not next/image — same reasoning as the Dreams module
 * itself: arbitrary image_url values fall outside the frozen
 * next.config.js remotePatterns allowlist.
 */
export function DreamsPreviewCard({ dreams }: DreamsPreviewCardProps) {
  const preview = dreams.slice(0, 4);

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Sparkles size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Dreams</h3>
      </div>

      {preview.length === 0 ? (
        <EmptyState message="No dreams on the board yet." />
      ) : (
        <div className="grid grid-cols-4 gap-2">
          {preview.map((dream) => (
            <div
              key={dream.id}
              className="aspect-square overflow-hidden rounded-card border border-border-subtle"
            >
              {dream.image_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={dream.image_url} alt="" className="h-full w-full object-cover" />
              ) : (
                <div
                  className="flex h-full w-full items-center justify-center"
                  style={{ background: "#131417" }}
                >
                  <Sparkles size={14} className="text-text-secondary/40" />
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Link href="/dreams" className="mt-4 inline-block text-xs text-accent hover:underline">
        View dream board
      </Link>
    </Card>
  );
}
