import Link from "next/link";
import { Clock } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "./EmptyState";
import { daysUntil } from "../dashboard-math";
import type { Project, ProjectTask, Goal } from "../types";

interface UpcomingDeadlinesCardProps {
  tasks: ProjectTask[];
  projectById: Map<string, Project>;
  goals: Goal[];
  windowDays?: number;
}

type DeadlineItem =
  | { kind: "task"; date: string; label: string; href: string; daysLeft: number }
  | { kind: "goal"; date: string; label: string; href: string; daysLeft: number };

export function UpcomingDeadlinesCard({
  tasks,
  projectById,
  goals,
  windowDays = 14,
}: UpcomingDeadlinesCardProps) {
  const taskItems: DeadlineItem[] = tasks
    .filter((t) => t.status !== "done" && t.due_date)
    .map((t) => ({
      kind: "task" as const,
      date: t.due_date as string,
      label: `${t.title}${projectById.get(t.project_id) ? ` — ${projectById.get(t.project_id)?.name}` : ""}`,
      href: `/projects/${t.project_id}`,
      daysLeft: daysUntil(t.due_date as string),
    }));

  const goalItems: DeadlineItem[] = goals
    .filter((g) => g.status === "active" && g.target_date)
    .map((g) => ({
      kind: "goal" as const,
      date: g.target_date as string,
      label: g.title,
      href: "/goals",
      daysLeft: daysUntil(g.target_date as string),
    }));

  const upcoming = [...taskItems, ...goalItems]
    .filter((item) => item.daysLeft <= windowDays)
    .sort((a, b) => a.daysLeft - b.daysLeft);

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Clock size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">
          Upcoming deadlines
        </h3>
      </div>

      {upcoming.length === 0 ? (
        <EmptyState message="Nothing due in the next two weeks." />
      ) : (
        <div className="flex flex-col gap-2">
          {upcoming.map((item, i) => (
            <Link
              key={i}
              href={item.href}
              className="flex items-center justify-between gap-3 text-sm hover:text-accent"
            >
              <span className="truncate text-text-primary">{item.label}</span>
              <Badge variant={item.daysLeft < 0 ? "danger" : item.daysLeft <= 2 ? "warning" : "neutral"}>
                {item.daysLeft < 0
                  ? "Overdue"
                  : item.daysLeft === 0
                    ? "Today"
                    : `${item.daysLeft}d`}
              </Badge>
            </Link>
          ))}
        </div>
      )}
    </Card>
  );
}
