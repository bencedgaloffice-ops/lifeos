import Link from "next/link";
import { Briefcase } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import { projectProgress } from "../dashboard-math";
import type { Project, ProjectTask } from "../types";

interface ActiveProjectsCardProps {
  projects: Project[];
  tasksByProject: Map<string, ProjectTask[]>;
}

export function ActiveProjectsCard({ projects, tasksByProject }: ActiveProjectsCardProps) {
  const active = projects.filter((p) => p.status === "active");

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Briefcase size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Active projects</h3>
      </div>

      {active.length === 0 ? (
        <EmptyState message="No active projects right now." />
      ) : (
        <div className="flex flex-col gap-3">
          {active.map((project) => {
            const { completed, total } = projectProgress(tasksByProject.get(project.id) ?? []);
            const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
            return (
              <Link key={project.id} href={`/projects/${project.id}`} className="group">
                <div className="flex items-center justify-between text-sm">
                  <span className="truncate text-text-primary group-hover:text-accent">
                    {project.name}
                  </span>
                  <span className="shrink-0 font-mono text-xs text-text-secondary">
                    {total > 0 ? `${completed}/${total}` : "No tasks"}
                  </span>
                </div>
                <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className="h-full rounded-full bg-accent transition-all"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </Link>
            );
          })}
        </div>
      )}

      <Link
        href="/projects"
        className="mt-4 inline-block text-xs text-accent hover:underline"
      >
        View all projects
      </Link>
    </Card>
  );
}
