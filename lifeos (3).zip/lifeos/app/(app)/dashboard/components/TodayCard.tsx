import Link from "next/link";
import { CalendarDays } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import type { CalendarEvent } from "../types";

interface TodayCardProps {
  events: CalendarEvent[];
}

export function TodayCard({ events }: TodayCardProps) {
  const sorted = [...events].sort(
    (a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime()
  );

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <CalendarDays size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Today</h3>
      </div>

      {sorted.length === 0 ? (
        <EmptyState message="Nothing on the calendar today." />
      ) : (
        <div className="flex flex-col gap-2">
          {sorted.map((event) => (
            <div key={event.id} className="flex items-center gap-3 text-sm">
              <span className="w-14 shrink-0 font-mono text-xs text-text-secondary">
                {event.all_day
                  ? "All day"
                  : new Date(event.start_at).toLocaleTimeString("en-US", {
                      hour: "numeric",
                      minute: "2-digit",
                    })}
              </span>
              <span className="truncate text-text-primary">{event.title}</span>
            </div>
          ))}
        </div>
      )}

      <Link
        href="/calendar"
        className="mt-4 inline-block text-xs text-accent hover:underline"
      >
        View calendar
      </Link>
    </Card>
  );
}
