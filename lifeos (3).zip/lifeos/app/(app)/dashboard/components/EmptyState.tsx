import { type ReactNode } from "react";

interface EmptyStateProps {
  message: string;
  action?: ReactNode;
}

/** Compact, card-internal empty state — Dashboard cards are dense, so
 * this is a single line + optional link, not the full-page EmptyState
 * pattern other modules use. */
export function EmptyState({ message, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center gap-2 py-6 text-center">
      <p className="text-sm text-text-secondary">{message}</p>
      {action}
    </div>
  );
}
