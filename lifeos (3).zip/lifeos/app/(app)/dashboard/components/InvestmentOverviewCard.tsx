import Link from "next/link";
import { LineChart } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import { formatCurrency } from "@/lib/utils/currency";
import { investmentTotalsByCurrency } from "../dashboard-math";
import type { InvestmentAccount, InvestmentHolding } from "../types";

interface InvestmentOverviewCardProps {
  accounts: InvestmentAccount[];
  holdingsByAccount: Map<string, InvestmentHolding[]>;
}

export function InvestmentOverviewCard({ accounts, holdingsByAccount }: InvestmentOverviewCardProps) {
  const totals = investmentTotalsByCurrency(accounts, holdingsByAccount);

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <LineChart size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Investments</h3>
      </div>

      {totals.length === 0 ? (
        <EmptyState message="No investment accounts yet." />
      ) : (
        <div className="flex flex-col gap-2">
          {totals.map(({ currency, value }) => (
            <div key={currency} className="flex items-center justify-between text-sm">
              <span className="text-text-secondary">{currency}</span>
              <span className="font-mono text-text-primary">{formatCurrency(value, currency)}</span>
            </div>
          ))}
        </div>
      )}

      <Link href="/investments" className="mt-4 inline-block text-xs text-accent hover:underline">
        View investments
      </Link>
    </Card>
  );
}
