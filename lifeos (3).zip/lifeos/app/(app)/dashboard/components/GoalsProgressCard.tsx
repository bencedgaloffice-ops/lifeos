import Link from "next/link";
import { Target } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "./EmptyState";
import type { Goal } from "../types";

interface GoalsProgressCardProps {
  goals: Goal[];
}

export function GoalsProgressCard({ goals }: GoalsProgressCardProps) {
  const active = goals.filter((g) => g.status === "active");

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Target size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Active goals</h3>
      </div>

      {active.length === 0 ? (
        <EmptyState message="No active goals right now." />
      ) : (
        <div className="flex flex-col gap-3">
          {active.slice(0, 5).map((goal) => (
            <div key={goal.id}>
              <div className="flex items-center justify-between text-sm">
                <span className="truncate text-text-primary">{goal.title}</span>
                <span className="shrink-0 font-mono text-xs text-text-secondary">
                  {goal.progress_percent}%
                </span>
              </div>
              <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/[0.06]">
                <div
                  className="h-full rounded-full bg-accent transition-all"
                  style={{ width: `${goal.progress_percent}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      <Link href="/goals" className="mt-4 inline-block text-xs text-accent hover:underline">
        View all goals
      </Link>
    </Card>
  );
}
