import Link from "next/link";
import { Wallet } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { StatCard } from "@/components/ui/StatCard";
import { formatCurrency } from "@/lib/utils/currency";
import type { Account, Transaction } from "../types";

interface FinancialSnapshotCardProps {
  accounts: Account[];
  monthTransactions: Transaction[];
}

export function FinancialSnapshotCard({ accounts, monthTransactions }: FinancialSnapshotCardProps) {
  const totalBalance = accounts.reduce((sum, a) => sum + a.current_balance, 0);
  const income = monthTransactions
    .filter((t) => t.direction === "income")
    .reduce((sum, t) => sum + t.amount, 0);
  const expense = monthTransactions
    .filter((t) => t.direction === "expense")
    .reduce((sum, t) => sum + t.amount, 0);
  const net = income - expense;
  const currency = accounts[0]?.currency ?? "HUF";

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <Wallet size={16} className="text-text-secondary" />
        <h3 className="font-display text-sm font-medium text-text-primary">Financial snapshot</h3>
      </div>

      {accounts.length === 0 ? (
        <p className="py-6 text-center text-sm text-text-secondary">
          No accounts set up in Money yet.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <StatCard label="Total balance" value={formatCurrency(totalBalance, currency)} />
          <StatCard
            label="Net saved this month"
            value={formatCurrency(net, currency)}
            trend={net >= 0 ? "up" : "down"}
          />
          <StatCard label="Income this month" value={formatCurrency(income, currency)} trend="up" />
          <StatCard label="Spent this month" value={formatCurrency(expense, currency)} trend="neutral" />
        </div>
      )}

      <Link href="/money" className="mt-4 inline-block text-xs text-accent hover:underline">
        View Money
      </Link>
    </Card>
  );
}
