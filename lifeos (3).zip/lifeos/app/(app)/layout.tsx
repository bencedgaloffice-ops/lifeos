import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { createClient } from "@/lib/supabase/server";

/**
 * Shell for every authenticated route. The actual auth check happens
 * in middleware.ts before a request ever reaches this layout — this
 * component assumes a valid session. The user lookup here is only to
 * pass an email down to TopBar/UserMenu, not a second auth check.
 */
export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="flex min-h-screen bg-base">
      <Sidebar />
      <div className="flex flex-1 flex-col">
        <TopBar userEmail={user?.email ?? null} />
        <main className="flex-1 px-8 py-8 sm:px-12">
          <div className="mx-auto max-w-[1200px]">{children}</div>
        </main>
      </div>
    </div>
  );
}
