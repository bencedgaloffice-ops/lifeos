"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LOCALES, DEFAULT_LOCALE, type Locale } from "@/lib/i18n/config";
import { cn } from "@/lib/utils/cn";

const LOCALE_COOKIE = "locale";

function readLocaleCookie(): Locale {
  if (typeof document === "undefined") return DEFAULT_LOCALE;
  const match = document.cookie.match(new RegExp(`${LOCALE_COOKIE}=([^;]+)`));
  const value = match?.[1];
  return (LOCALES as readonly string[]).includes(value ?? "")
    ? (value as Locale)
    : DEFAULT_LOCALE;
}

/**
 * Reads/writes the same `locale` cookie that middleware.ts sets on
 * first visit — picking a language here overrides the Accept-Language
 * detection for every future request.
 */
export function LocaleSwitcher() {
  const router = useRouter();
  const [active, setActive] = useState<Locale>(DEFAULT_LOCALE);

  useEffect(() => {
    setActive(readLocaleCookie());
  }, []);

  const setLocale = (locale: Locale) => {
    document.cookie = `${LOCALE_COOKIE}=${locale}; path=/; max-age=${60 * 60 * 24 * 365}; SameSite=Lax`;
    setActive(locale);
    router.refresh();
  };

  return (
    <div className="flex overflow-hidden rounded-card border border-border-subtle text-xs">
      {LOCALES.map((locale) => (
        <button
          key={locale}
          onClick={() => setLocale(locale)}
          aria-pressed={active === locale}
          className={cn(
            "px-2.5 py-1.5 transition-colors",
            active === locale
              ? "bg-accent-soft text-accent"
              : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
          )}
        >
          {locale.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
