"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Calendar,
  Target,
  Sparkles,
  Clock,
  Briefcase,
  Building2,
  Wallet,
  LineChart,
  BookOpen,
  FileText,
  Layers,
  Settings,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

type NavItem = {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  /** Only Dashboard has a real page in Phase 1 — everything else is
   * structurally ready but not yet built, so it renders disabled
   * rather than 404ing. */
  ready?: boolean;
};

const NAV_SECTIONS: { label: string; items: NavItem[] }[] = [
  {
    label: "Overview",
    items: [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, ready: true }],
  },
  {
    label: "Plan",
    items: [
      { href: "/calendar", label: "Calendar", icon: Calendar, ready: true },
      { href: "/goals", label: "Goals", icon: Target, ready: true },
      { href: "/dreams", label: "Dreams", icon: Sparkles, ready: true },
      { href: "/timeline", label: "Timeline", icon: Clock },
    ],
  },
  {
    label: "Work",
    items: [
      { href: "/projects", label: "Projects", icon: Briefcase, ready: true },
      { href: "/organizations", label: "Organizations", icon: Building2 },
    ],
  },
  {
    label: "Life",
    items: [
      { href: "/money", label: "Money", icon: Wallet, ready: true },
      { href: "/investments", label: "Investments", icon: LineChart, ready: true },
      { href: "/journal", label: "Journal", icon: BookOpen, ready: true },
      { href: "/documents", label: "Documents", icon: FileText, ready: true },
      { href: "/life-areas", label: "Life Areas", icon: Layers },
    ],
  },
  {
    label: "System",
    items: [{ href: "/settings", label: "Settings", icon: Settings }],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        "hidden shrink-0 flex-col border-r border-border-subtle bg-surface p-4 transition-[width] duration-200 sm:flex",
        collapsed ? "w-16" : "w-60"
      )}
    >
      <div className="mb-6 flex items-center justify-between px-2">
        {!collapsed && (
          <span className="font-display text-lg font-semibold text-text-primary">
            LifeOS
          </span>
        )}
        <button
          onClick={() => setCollapsed((c) => !c)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="rounded-card p-1.5 text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
        >
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-6 overflow-y-auto">
        {NAV_SECTIONS.map((section) => (
          <div key={section.label}>
            {!collapsed && (
              <p className="mb-2 px-2 font-mono text-xs uppercase tracking-wider text-text-secondary">
                {section.label}
              </p>
            )}
            <div className="flex flex-col gap-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;

                if (!item.ready) {
                  return (
                    <span
                      key={item.href}
                      title={`${item.label} — coming soon`}
                      aria-disabled="true"
                      className={cn(
                        "flex cursor-not-allowed items-center gap-2.5 rounded-card px-2 py-1.5 text-sm text-text-secondary/40",
                        collapsed && "justify-center"
                      )}
                    >
                      <Icon size={16} strokeWidth={1.75} />
                      {!collapsed && (
                        <span className="flex flex-1 items-center justify-between">
                          {item.label}
                          <span className="rounded-full bg-white/[0.06] px-1.5 py-0.5 text-[10px] text-text-secondary/60">
                            Soon
                          </span>
                        </span>
                      )}
                    </span>
                  );
                }

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    title={item.label}
                    className={cn(
                      "flex items-center gap-2.5 rounded-card px-2 py-1.5 text-sm transition-colors",
                      collapsed && "justify-center",
                      isActive
                        ? "bg-accent-soft text-accent"
                        : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
                    )}
                  >
                    <Icon size={16} strokeWidth={1.75} />
                    {!collapsed && item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </aside>
  );
}
