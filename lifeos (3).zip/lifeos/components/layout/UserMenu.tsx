"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LogOut, User } from "lucide-react";
import { GlassPanel } from "@/components/ui/GlassPanel";
import { createClient } from "@/lib/supabase/client";

interface UserMenuProps {
  email: string | null;
}

/**
 * "User menu placeholder" per the Phase 1 brief — kept intentionally
 * minimal (avatar initial + email + sign out), no profile editing or
 * settings shortcuts yet. Sign-out is real (it's part of the auth
 * experience, not a feature module), so this isn't purely decorative.
 */
export function UserMenu({ email }: UserMenuProps) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const initial = email?.[0]?.toUpperCase() ?? "?";

  const handleSignOut = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="User menu"
        aria-expanded={open}
        className="flex h-8 w-8 items-center justify-center rounded-full bg-accent-soft text-xs font-medium text-accent transition-opacity hover:opacity-80"
      >
        {initial}
      </button>

      {open && (
        <>
          {/* Click-outside overlay */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setOpen(false)}
            aria-hidden
          />
          <GlassPanel
            elevated
            className="absolute right-0 top-11 z-50 w-56 p-2 animate-scale-in"
          >
            <div className="flex items-center gap-2 px-2 py-2 text-sm text-text-secondary">
              <User size={14} />
              <span className="truncate">{email ?? "Unknown user"}</span>
            </div>
            <div className="my-1 h-px bg-border-subtle" />
            <button
              onClick={handleSignOut}
              className="flex w-full items-center gap-2 rounded-card px-2 py-1.5 text-left text-sm text-text-secondary transition-colors hover:bg-white/[0.06] hover:text-text-primary"
            >
              <LogOut size={14} />
              Sign out
            </button>
          </GlassPanel>
        </>
      )}
    </div>
  );
}
