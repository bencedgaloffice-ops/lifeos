"use client";

import { usePathname } from "next/navigation";
import { LocaleSwitcher } from "@/components/layout/LocaleSwitcher";
import { UserMenu } from "@/components/layout/UserMenu";

const PAGE_TITLES: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/calendar": "Calendar",
  "/money": "Money",
  "/projects": "Projects",
  "/goals": "Goals",
  "/dreams": "Dreams",
  "/journal": "Journal",
  "/documents": "Documents",
  "/investments": "Investments",
};

interface TopBarProps {
  userEmail: string | null;
}

export function TopBar({ userEmail }: TopBarProps) {
  const pathname = usePathname();
  const title = PAGE_TITLES[pathname] ?? "LifeOS";

  return (
    <header className="flex h-16 items-center justify-between border-b border-border-subtle px-8 sm:px-12">
      <h2 className="font-display text-sm font-medium text-text-primary">{title}</h2>
      <div className="flex items-center gap-3">
        <LocaleSwitcher />
        <UserMenu email={userEmail} />
      </div>
    </header>
  );
}
