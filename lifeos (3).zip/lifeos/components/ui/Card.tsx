import { type HTMLAttributes } from "react";
import { cn } from "@/lib/utils/cn";

/**
 * The base surface used by every module — Calendar, Money, Projects,
 * etc. — so the app reads as one system rather than separate screens.
 */
export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("glass-panel p-6", className)} {...props} />;
}
