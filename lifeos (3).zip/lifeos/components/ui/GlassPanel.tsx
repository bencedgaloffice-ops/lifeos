import { type HTMLAttributes } from "react";
import { cn } from "@/lib/utils/cn";

interface GlassPanelProps extends HTMLAttributes<HTMLDivElement> {
  /** Adds a stronger blur + border for panels that float above content (modals, popovers). */
  elevated?: boolean;
}

/**
 * GlassPanel vs Card: Card is the everyday content surface (list rows,
 * stat tiles, form sections). GlassPanel is for surfaces that need to
 * visually separate from the page behind them — modals, dropdowns,
 * the landing page's floating content block.
 */
export function GlassPanel({
  className,
  elevated = false,
  ...props
}: GlassPanelProps) {
  return (
    <div
      className={cn(
        "rounded-panel border border-border-subtle bg-glass backdrop-blur-glass",
        elevated && "shadow-[0_8px_40px_rgba(0,0,0,0.45)] border-white/[0.12]",
        className
      )}
      {...props}
    />
  );
}
