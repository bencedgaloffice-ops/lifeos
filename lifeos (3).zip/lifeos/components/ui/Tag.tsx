import { type HTMLAttributes } from "react";
import { cn } from "@/lib/utils/cn";

interface TagProps extends HTMLAttributes<HTMLSpanElement> {
  /** Hex color, typically sourced from a life_areas or organizations row. */
  color?: string;
}

/**
 * Small color-coded label. This is how a life_area or organization
 * shows up inline on a goal, project, event, or transaction card —
 * the visual thread that ties modules together.
 */
export function Tag({ color, className, style, children, ...props }: TagProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border-subtle px-2.5 py-1 text-xs font-medium text-text-secondary",
        className
      )}
      style={{ ...style }}
      {...props}
    >
      {color && (
        <span
          className="h-1.5 w-1.5 rounded-full"
          style={{ backgroundColor: color }}
        />
      )}
      {children}
    </span>
  );
}
