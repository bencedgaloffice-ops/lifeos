import { type ReactNode } from "react";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils/cn";

interface StatCardProps {
  label: string;
  value: string;
  /** e.g. "+4.2%" or "-120,000 HUF" — rendered in mono, colored by trend. */
  delta?: string;
  trend?: "up" | "down" | "neutral";
  icon?: ReactNode;
}

const trendColor: Record<NonNullable<StatCardProps["trend"]>, string> = {
  up: "text-success",
  down: "text-danger",
  neutral: "text-text-secondary",
};

/**
 * The financial-clarity pattern (Copilot Money reference): a label,
 * one dominant number set in mono for numeric precision, and an
 * optional delta. Used for net worth, budget remaining, goal
 * progress — anywhere a single number is the point.
 */
export function StatCard({ label, value, delta, trend = "neutral", icon }: StatCardProps) {
  return (
    <Card className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <p className="text-sm text-text-secondary">{label}</p>
        {icon && <span className="text-text-secondary">{icon}</span>}
      </div>
      <p className="font-mono text-2xl font-medium text-text-primary">{value}</p>
      {delta && (
        <p className={cn("font-mono text-xs", trendColor[trend])}>{delta}</p>
      )}
    </Card>
  );
}
