"use client";

import { type ReactNode, useEffect } from "react";
import { createPortal } from "react-dom";
import { GlassPanel } from "@/components/ui/GlassPanel";
import { cn } from "@/lib/utils/cn";

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  className?: string;
}

/**
 * Portal-based modal (not <dialog>) so it composes cleanly with the
 * glass-panel visual language and animation utilities. Closes on
 * Escape and on backdrop click; focus trapping can be layered on
 * once a real form is placed inside — Phase 0 keeps this minimal.
 */
export function Modal({ open, onClose, title, children, className }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in"
      onClick={onClose}
    >
      <GlassPanel
        elevated
        className={cn("w-full max-w-md p-6 animate-scale-in", className)}
        onClick={(event) => event.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? "modal-title" : undefined}
      >
        {title && (
          <h2 id="modal-title" className="mb-4 font-display text-lg text-text-primary">
            {title}
          </h2>
        )}
        {children}
      </GlassPanel>
    </div>,
    document.body
  );
}
