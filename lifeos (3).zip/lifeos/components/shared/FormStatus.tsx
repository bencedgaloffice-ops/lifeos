import { type ReactNode } from "react";
import { CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils/cn";

interface FormStatusProps {
  variant: "success" | "error";
  children: ReactNode;
}

/**
 * Shared success/error banner for the three auth forms (login,
 * register, reset-password) — factored out because all three had
 * the identical inline pattern. Not a new base primitive like
 * Button/Card/Input/GlassPanel; this composes on top of them.
 */
export function FormStatus({ variant, children }: FormStatusProps) {
  const Icon = variant === "success" ? CheckCircle2 : AlertCircle;
  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-card border p-4 text-sm",
        variant === "success" && "border-success/30 bg-success/10 text-success",
        variant === "error" && "border-danger/30 bg-danger/10 text-danger"
      )}
      role={variant === "error" ? "alert" : "status"}
    >
      <Icon size={18} className="shrink-0" />
      <span>{children}</span>
    </div>
  );
}
