/**
 * Minimal date helpers for the Calendar module. Deliberately dependency-free
 * (no date-fns/dayjs) — Phase 0's dependency set is frozen, and native Date
 * covers everything a month/week/agenda grid needs.
 */

const DAY_MS = 24 * 60 * 60 * 1000;

export function startOfMonth(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

export function addMonths(date: Date, count: number) {
  return new Date(date.getFullYear(), date.getMonth() + count, 1);
}

export function addDays(date: Date, count: number) {
  return new Date(date.getTime() + count * DAY_MS);
}

export function isSameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

/** Monday-first 6-week grid covering the given month, including
 * leading/trailing days from adjacent months so every week is full. */
export function getMonthGrid(monthDate: Date): Date[] {
  const first = startOfMonth(monthDate);
  // getDay(): 0 = Sunday. Convert to Monday-first offset.
  const leadingOffset = (first.getDay() + 6) % 7;
  const gridStart = addDays(first, -leadingOffset);

  return Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
}

/** Monday-first 7-day span containing the given date. */
export function getWeekDays(date: Date): Date[] {
  const offset = (date.getDay() + 6) % 7;
  const weekStart = addDays(date, -offset);
  return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
}

export function formatMonthYear(date: Date) {
  return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
}

export function formatDayLabel(date: Date) {
  return date.toLocaleDateString("en-US", { weekday: "short", day: "numeric" });
}

export function formatTime(date: Date) {
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

export function toDateInputValue(date: Date) {
  return date.toISOString().slice(0, 10);
}

export function toTimeInputValue(date: Date) {
  return date.toTimeString().slice(0, 5);
}
