/**
 * Formatting helpers shared by anything money-related. Kept in
 * lib/utils rather than the money module itself since date.ts (used
 * by Calendar) already sets the precedent of generic formatting
 * helpers living here — this one just isn't a "global financial
 * component" (no UI, no JSX), so it doesn't conflict with keeping
 * Money's components local to app/(app)/money/components.
 */
export function formatCurrency(amount: number, currency: string = "HUF") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: currency === "HUF" ? 0 : 2,
  }).format(amount);
}
