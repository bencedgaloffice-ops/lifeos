export const APP_NAME = "LifeOS";

/** organizations.type values */
export const ORGANIZATION_TYPES = [
  "employment",
  "own_business",
  "grant_project",
  "future_venture",
] as const;

/** recurring_transactions.frequency values */
export const RECURRING_FREQUENCIES = [
  "weekly",
  "monthly",
  "quarterly",
  "yearly",
] as const;

/** ai_memory.memory_type values */
export const AI_MEMORY_TYPES = [
  "goal_context",
  "decision",
  "preference",
  "pattern",
] as const;
