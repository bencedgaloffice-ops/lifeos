import { z } from "zod";

export const projectFormSchema = z.object({
  name: z.string().min(1, "Name is required").max(200),
  description: z.string().max(2000).optional().or(z.literal("")),
  status: z.enum(["active", "paused", "done"]),
  organizationId: z.string().optional().or(z.literal("")),
  lifeAreaId: z.string().optional().or(z.literal("")),
});
export type ProjectFormInput = z.infer<typeof projectFormSchema>;

export const taskFormSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  status: z.enum(["todo", "in_progress", "done"]),
  dueDate: z.string().optional().or(z.literal("")),
});
export type TaskFormInput = z.infer<typeof taskFormSchema>;
