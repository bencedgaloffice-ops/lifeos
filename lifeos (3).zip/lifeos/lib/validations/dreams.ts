import { z } from "zod";

export const dreamFormSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  description: z.string().max(2000).optional().or(z.literal("")),
  imageUrl: z
    .string()
    .trim()
    .refine((v) => v === "" || z.string().url().safeParse(v).success, {
      message: "Enter a valid URL",
    })
    .optional()
    .or(z.literal("")),
});
export type DreamFormInput = z.infer<typeof dreamFormSchema>;
