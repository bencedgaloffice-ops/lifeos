import { z } from "zod";

export const accountFormSchema = z.object({
  name: z.string().min(1, "Name is required").max(120),
  type: z.enum(["checking", "savings", "cash", "other"]),
  currency: z.string().min(1, "Currency is required").max(10),
  currentBalance: z.coerce.number(),
});
export type AccountFormInput = z.infer<typeof accountFormSchema>;

export const transactionFormSchema = z.object({
  accountId: z.string().min(1, "Account is required"),
  categoryId: z.string().optional().or(z.literal("")),
  lifeAreaId: z.string().optional().or(z.literal("")),
  direction: z.enum(["income", "expense"]),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  currency: z.string().min(1).max(10),
  description: z.string().max(300).optional().or(z.literal("")),
  occurredAt: z.string().min(1, "Date is required"),
});
export type TransactionFormInput = z.infer<typeof transactionFormSchema>;

export const budgetCategoryFormSchema = z.object({
  name: z.string().min(1, "Name is required").max(120),
  monthlyLimit: z.coerce.number().min(0).optional(),
  currency: z.string().min(1).max(10),
});
export type BudgetCategoryFormInput = z.infer<typeof budgetCategoryFormSchema>;

export const recurringFormSchema = z.object({
  accountId: z.string().min(1, "Account is required"),
  name: z.string().min(1, "Name is required").max(120),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  type: z.enum(["income", "expense"]),
  category: z.string().max(80).optional().or(z.literal("")),
  frequency: z.enum(["weekly", "monthly", "quarterly", "yearly"]),
  nextDate: z.string().min(1, "Next date is required"),
  active: z.boolean(),
});
export type RecurringFormInput = z.infer<typeof recurringFormSchema>;
