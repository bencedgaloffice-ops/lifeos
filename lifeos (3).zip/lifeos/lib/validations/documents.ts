import { z } from "zod";

export const documentMetadataSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  category: z.string().max(80).optional().or(z.literal("")),
  lifeAreaId: z.string().optional().or(z.literal("")),
  projectId: z.string().optional().or(z.literal("")),
});
export type DocumentMetadataInput = z.infer<typeof documentMetadataSchema>;

/** 20MB — generous for certificates/contracts/scans without letting arbitrary large files through. */
export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;
