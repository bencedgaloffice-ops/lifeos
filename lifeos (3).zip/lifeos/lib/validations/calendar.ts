import { z } from "zod";

export const eventFormSchema = z
  .object({
    title: z.string().min(1, "Title is required").max(200),
    description: z.string().max(2000).optional().or(z.literal("")),
    startDate: z.string().min(1, "Start date is required"),
    startTime: z.string().optional(),
    endDate: z.string().min(1, "End date is required"),
    endTime: z.string().optional(),
    allDay: z.boolean(),
    lifeAreaId: z.string().optional().or(z.literal("")),
    category: z.string().max(80).optional().or(z.literal("")),
    recurrence: z.enum(["none", "daily", "weekly", "monthly"]),
    recurrenceCount: z.coerce.number().int().min(1).max(52).optional(),
  })
  .refine(
    (data) => {
      const start = new Date(`${data.startDate}T${data.startTime || "00:00"}`);
      const end = new Date(`${data.endDate}T${data.endTime || "00:00"}`);
      return end >= start;
    },
    { message: "End must be after start", path: ["endDate"] }
  );

export type EventFormInput = z.infer<typeof eventFormSchema>;
