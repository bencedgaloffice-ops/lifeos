import { z } from "zod";

export const journalEntryFormSchema = z.object({
  title: z.string().max(200).optional().or(z.literal("")),
  body: z.string().max(20000).optional().or(z.literal("")),
  mood: z.string().max(40).optional().or(z.literal("")),
  entryDate: z.string().min(1, "Date is required"),
});
export type JournalEntryFormInput = z.infer<typeof journalEntryFormSchema>;
