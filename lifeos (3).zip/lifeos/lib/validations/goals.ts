import { z } from "zod";

export const goalFormSchema = z.object({
  title: z.string().min(1, "Title is required").max(200),
  description: z.string().max(2000).optional().or(z.literal("")),
  targetDate: z.string().optional().or(z.literal("")),
  status: z.enum(["active", "achieved", "dropped"]),
  category: z.string().max(80).optional().or(z.literal("")),
  lifeAreaId: z.string().optional().or(z.literal("")),
  progressPercent: z.coerce.number().int().min(0).max(100),
});
export type GoalFormInput = z.infer<typeof goalFormSchema>;
