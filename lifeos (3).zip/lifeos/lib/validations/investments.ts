import { z } from "zod";

export const investmentAccountFormSchema = z.object({
  name: z.string().min(1, "Name is required").max(120),
  institution: z.string().max(120).optional().or(z.literal("")),
  type: z.enum(["stocks", "crypto", "other"]),
  currency: z.string().min(1, "Currency is required").max(10),
});
export type InvestmentAccountFormInput = z.infer<typeof investmentAccountFormSchema>;

export const holdingFormSchema = z.object({
  symbol: z.string().min(1, "Symbol is required").max(20),
  quantity: z.coerce.number().positive("Quantity must be greater than 0"),
  avgCost: z.coerce.number().min(0).optional(),
  currentValue: z.coerce.number().min(0).optional(),
});
export type HoldingFormInput = z.infer<typeof holdingFormSchema>;
