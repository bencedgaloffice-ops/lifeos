-- LifeOS — initial schema
-- Convention: every user-owned table gets user_id, created_at (and
-- updated_at where rows are edited after creation), and an RLS policy
-- restricting all access to auth.uid() = user_id.

create extension if not exists "uuid-ossp";

-- ============================================================
-- Core
-- ============================================================

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  display_name text,
  locale text not null default 'en' check (locale in ('en', 'hu')),
  timezone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- Life Areas — the central connection layer
-- ============================================================

create table life_areas (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  icon text,
  color text,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- Organizations
-- ============================================================

create table organizations (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  type text check (type in ('employment', 'own_business', 'grant_project', 'future_venture')),
  description text,
  logo text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- Projects
-- ============================================================

create table projects (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  organization_id uuid references organizations(id) on delete set null,
  life_area_id uuid references life_areas(id) on delete set null,
  name text not null,
  description text,
  status text not null default 'active' check (status in ('active', 'paused', 'done')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table project_tasks (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid not null references projects(id) on delete cascade,
  title text not null,
  status text not null default 'todo' check (status in ('todo', 'in_progress', 'done')),
  due_date date,
  created_at timestamptz not null default now()
);

-- ============================================================
-- Calendar
-- ============================================================

create table calendar_events (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  life_area_id uuid references life_areas(id) on delete set null,
  title text not null,
  description text,
  start_at timestamptz not null,
  end_at timestamptz not null,
  all_day boolean not null default false,
  source text not null default 'manual' check (source in ('manual', 'google')),
  category text,
  recurrence_rule text,
  parent_event_id uuid references calendar_events(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- Money
-- ============================================================

create table accounts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  type text check (type in ('checking', 'savings', 'cash', 'other')),
  currency text not null default 'HUF',
  current_balance numeric not null default 0,
  created_at timestamptz not null default now()
);

create table budget_categories (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  icon text,
  monthly_limit numeric,
  currency text not null default 'HUF',
  created_at timestamptz not null default now()
);

create table transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  account_id uuid not null references accounts(id) on delete cascade,
  category_id uuid references budget_categories(id) on delete set null,
  life_area_id uuid references life_areas(id) on delete set null,
  amount numeric not null,
  currency text not null default 'HUF',
  direction text not null check (direction in ('income', 'expense')),
  description text,
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table recurring_transactions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  account_id uuid not null references accounts(id) on delete cascade,
  name text not null,
  amount numeric not null,
  type text not null check (type in ('income', 'expense')),
  category text,
  frequency text not null check (frequency in ('weekly', 'monthly', 'quarterly', 'yearly')),
  next_date date not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table net_worth_snapshots (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  snapshot_date date not null,
  total_assets numeric not null,
  total_liabilities numeric not null,
  net_worth numeric not null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- Goals & Dreams
-- ============================================================

create table goals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  life_area_id uuid references life_areas(id) on delete set null,
  title text not null,
  description text,
  target_date date,
  status text not null default 'active' check (status in ('active', 'achieved', 'dropped')),
  category text,
  progress_percent integer not null default 0 check (progress_percent between 0 and 100),
  created_at timestamptz not null default now()
);

create table dreams (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text,
  image_url text,
  order_index integer not null default 0,
  created_at timestamptz not null default now()
);

-- ============================================================
-- Timeline & Milestones
-- ============================================================

create table milestones (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  description text,
  date date not null,
  category text,
  related_goal_id uuid references goals(id) on delete set null,
  related_project_id uuid references projects(id) on delete set null,
  life_area_id uuid references life_areas(id) on delete set null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- Journal
-- ============================================================

create table journal_entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text,
  body text,
  mood text,
  entry_date date not null default current_date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- Documents
-- ============================================================

create table documents (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  life_area_id uuid references life_areas(id) on delete set null,
  related_project_id uuid references projects(id) on delete set null,
  title text not null,
  file_path text not null,
  category text,
  uploaded_at timestamptz not null default now()
);

-- ============================================================
-- Investments
-- ============================================================

create table investment_accounts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  institution text,
  type text check (type in ('stocks', 'crypto', 'other')),
  currency text not null default 'HUF',
  created_at timestamptz not null default now()
);

create table investment_holdings (
  id uuid primary key default uuid_generate_v4(),
  investment_account_id uuid not null references investment_accounts(id) on delete cascade,
  symbol text not null,
  quantity numeric not null,
  avg_cost numeric,
  current_value numeric,
  last_updated timestamptz not null default now()
);

-- ============================================================
-- AI Memory (foundation for a future assistant — not UI-wired yet)
-- ============================================================

create table ai_memory (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  memory_type text check (memory_type in ('goal_context', 'decision', 'preference', 'pattern')),
  content text not null,
  importance integer check (importance between 1 and 5),
  created_at timestamptz not null default now()
);

-- ============================================================
-- Settings
-- ============================================================

create table user_preferences (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  key text not null,
  value jsonb,
  updated_at timestamptz not null default now(),
  unique (user_id, key)
);

-- ============================================================
-- Row Level Security — every user-owned table
-- ============================================================

alter table profiles enable row level security;
alter table life_areas enable row level security;
alter table organizations enable row level security;
alter table projects enable row level security;
alter table project_tasks enable row level security;
alter table calendar_events enable row level security;
alter table accounts enable row level security;
alter table budget_categories enable row level security;
alter table transactions enable row level security;
alter table recurring_transactions enable row level security;
alter table net_worth_snapshots enable row level security;
alter table goals enable row level security;
alter table dreams enable row level security;
alter table milestones enable row level security;
alter table journal_entries enable row level security;
alter table documents enable row level security;
alter table investment_accounts enable row level security;
alter table investment_holdings enable row level security;
alter table ai_memory enable row level security;
alter table user_preferences enable row level security;

create policy "Users manage their own profile"
  on profiles for all
  using (auth.uid() = id)
  with check (auth.uid() = id);

create policy "Users manage their own rows" on life_areas for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on organizations for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on projects for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on calendar_events for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on accounts for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on budget_categories for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on transactions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on recurring_transactions for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on net_worth_snapshots for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on goals for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on dreams for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on milestones for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on journal_entries for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on documents for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on investment_accounts for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on ai_memory for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage their own rows" on user_preferences for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- project_tasks and investment_holdings are owned indirectly through
-- their parent row, so the policy checks ownership via a join.
create policy "Users manage tasks on their own projects" on project_tasks for all
  using (exists (
    select 1 from projects
    where projects.id = project_tasks.project_id
    and projects.user_id = auth.uid()
  ))
  with check (exists (
    select 1 from projects
    where projects.id = project_tasks.project_id
    and projects.user_id = auth.uid()
  ));

create policy "Users manage holdings in their own accounts" on investment_holdings for all
  using (exists (
    select 1 from investment_accounts
    where investment_accounts.id = investment_holdings.investment_account_id
    and investment_accounts.user_id = auth.uid()
  ))
  with check (exists (
    select 1 from investment_accounts
    where investment_accounts.id = investment_holdings.investment_account_id
    and investment_accounts.user_id = auth.uid()
  ));
