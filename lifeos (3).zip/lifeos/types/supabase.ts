/**
 * Hand-authored to exactly mirror supabase/migrations/0001_init.sql.
 * This is a type reflection of the already-approved schema, not a
 * schema change. Replace with the real generated file the moment a
 * live Supabase project exists:
 *
 *   npx supabase gen types typescript --project-id <id> --schema public > types/supabase.ts
 */

type Timestamp = string;

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          display_name: string | null;
          locale: "en" | "hu";
          timezone: string | null;
          avatar_url: string | null;
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id: string;
          display_name?: string | null;
          locale?: "en" | "hu";
          timezone?: string | null;
          avatar_url?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>;
        Relationships: [];
      };
      life_areas: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          icon: string | null;
          color: string | null;
          description: string | null;
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          icon?: string | null;
          color?: string | null;
          description?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["life_areas"]["Insert"]>;
        Relationships: [];
      };
      organizations: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          type: "employment" | "own_business" | "grant_project" | "future_venture" | null;
          description: string | null;
          logo: string | null;
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          type?: "employment" | "own_business" | "grant_project" | "future_venture" | null;
          description?: string | null;
          logo?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["organizations"]["Insert"]>;
        Relationships: [];
      };
      projects: {
        Row: {
          id: string;
          user_id: string;
          organization_id: string | null;
          life_area_id: string | null;
          name: string;
          description: string | null;
          status: "active" | "paused" | "done";
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          organization_id?: string | null;
          life_area_id?: string | null;
          name: string;
          description?: string | null;
          status?: "active" | "paused" | "done";
        };
        Update: Partial<Database["public"]["Tables"]["projects"]["Insert"]>;
        Relationships: [];
      };
      project_tasks: {
        Row: {
          id: string;
          project_id: string;
          title: string;
          status: "todo" | "in_progress" | "done";
          due_date: string | null;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          project_id: string;
          title: string;
          status?: "todo" | "in_progress" | "done";
          due_date?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["project_tasks"]["Insert"]>;
        Relationships: [];
      };
      calendar_events: {
        Row: {
          id: string;
          user_id: string;
          life_area_id: string | null;
          title: string;
          description: string | null;
          start_at: Timestamp;
          end_at: Timestamp;
          all_day: boolean;
          source: "manual" | "google";
          category: string | null;
          recurrence_rule: string | null;
          parent_event_id: string | null;
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          life_area_id?: string | null;
          title: string;
          description?: string | null;
          start_at: Timestamp;
          end_at: Timestamp;
          all_day?: boolean;
          source?: "manual" | "google";
          category?: string | null;
          recurrence_rule?: string | null;
          parent_event_id?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["calendar_events"]["Insert"]>;
        Relationships: [];
      };
      accounts: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          type: "checking" | "savings" | "cash" | "other" | null;
          currency: string;
          current_balance: number;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          type?: "checking" | "savings" | "cash" | "other" | null;
          currency?: string;
          current_balance?: number;
        };
        Update: Partial<Database["public"]["Tables"]["accounts"]["Insert"]>;
        Relationships: [];
      };
      budget_categories: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          icon: string | null;
          monthly_limit: number | null;
          currency: string;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          icon?: string | null;
          monthly_limit?: number | null;
          currency?: string;
        };
        Update: Partial<Database["public"]["Tables"]["budget_categories"]["Insert"]>;
        Relationships: [];
      };
      transactions: {
        Row: {
          id: string;
          user_id: string;
          account_id: string;
          category_id: string | null;
          life_area_id: string | null;
          amount: number;
          currency: string;
          direction: "income" | "expense";
          description: string | null;
          occurred_at: Timestamp;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          account_id: string;
          category_id?: string | null;
          life_area_id?: string | null;
          amount: number;
          currency?: string;
          direction: "income" | "expense";
          description?: string | null;
          occurred_at?: Timestamp;
        };
        Update: Partial<Database["public"]["Tables"]["transactions"]["Insert"]>;
        Relationships: [];
      };
      recurring_transactions: {
        Row: {
          id: string;
          user_id: string;
          account_id: string;
          name: string;
          amount: number;
          type: "income" | "expense";
          category: string | null;
          frequency: "weekly" | "monthly" | "quarterly" | "yearly";
          next_date: string;
          active: boolean;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          account_id: string;
          name: string;
          amount: number;
          type: "income" | "expense";
          category?: string | null;
          frequency: "weekly" | "monthly" | "quarterly" | "yearly";
          next_date: string;
          active?: boolean;
        };
        Update: Partial<Database["public"]["Tables"]["recurring_transactions"]["Insert"]>;
        Relationships: [];
      };
      net_worth_snapshots: {
        Row: {
          id: string;
          user_id: string;
          snapshot_date: string;
          total_assets: number;
          total_liabilities: number;
          net_worth: number;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          snapshot_date: string;
          total_assets: number;
          total_liabilities: number;
          net_worth: number;
        };
        Update: Partial<Database["public"]["Tables"]["net_worth_snapshots"]["Insert"]>;
        Relationships: [];
      };
      goals: {
        Row: {
          id: string;
          user_id: string;
          life_area_id: string | null;
          title: string;
          description: string | null;
          target_date: string | null;
          status: "active" | "achieved" | "dropped";
          category: string | null;
          progress_percent: number;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          life_area_id?: string | null;
          title: string;
          description?: string | null;
          target_date?: string | null;
          status?: "active" | "achieved" | "dropped";
          category?: string | null;
          progress_percent?: number;
        };
        Update: Partial<Database["public"]["Tables"]["goals"]["Insert"]>;
        Relationships: [];
      };
      dreams: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string | null;
          image_url: string | null;
          order_index: number;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          title: string;
          description?: string | null;
          image_url?: string | null;
          order_index?: number;
        };
        Update: Partial<Database["public"]["Tables"]["dreams"]["Insert"]>;
        Relationships: [];
      };
      milestones: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string | null;
          date: string;
          category: string | null;
          related_goal_id: string | null;
          related_project_id: string | null;
          life_area_id: string | null;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          title: string;
          description?: string | null;
          date: string;
          category?: string | null;
          related_goal_id?: string | null;
          related_project_id?: string | null;
          life_area_id?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["milestones"]["Insert"]>;
        Relationships: [];
      };
      journal_entries: {
        Row: {
          id: string;
          user_id: string;
          title: string | null;
          body: string | null;
          mood: string | null;
          entry_date: string;
          created_at: Timestamp;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          title?: string | null;
          body?: string | null;
          mood?: string | null;
          entry_date?: string;
        };
        Update: Partial<Database["public"]["Tables"]["journal_entries"]["Insert"]>;
        Relationships: [];
      };
      documents: {
        Row: {
          id: string;
          user_id: string;
          life_area_id: string | null;
          related_project_id: string | null;
          title: string;
          file_path: string;
          category: string | null;
          uploaded_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          life_area_id?: string | null;
          related_project_id?: string | null;
          title: string;
          file_path: string;
          category?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["documents"]["Insert"]>;
        Relationships: [];
      };
      investment_accounts: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          institution: string | null;
          type: "stocks" | "crypto" | "other" | null;
          currency: string;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          institution?: string | null;
          type?: "stocks" | "crypto" | "other" | null;
          currency?: string;
        };
        Update: Partial<Database["public"]["Tables"]["investment_accounts"]["Insert"]>;
        Relationships: [];
      };
      investment_holdings: {
        Row: {
          id: string;
          investment_account_id: string;
          symbol: string;
          quantity: number;
          avg_cost: number | null;
          current_value: number | null;
          last_updated: Timestamp;
        };
        Insert: {
          id?: string;
          investment_account_id: string;
          symbol: string;
          quantity: number;
          avg_cost?: number | null;
          current_value?: number | null;
        };
        Update: Partial<Database["public"]["Tables"]["investment_holdings"]["Insert"]>;
        Relationships: [];
      };
      ai_memory: {
        Row: {
          id: string;
          user_id: string;
          memory_type: "goal_context" | "decision" | "preference" | "pattern" | null;
          content: string;
          importance: number | null;
          created_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          memory_type?: "goal_context" | "decision" | "preference" | "pattern" | null;
          content: string;
          importance?: number | null;
        };
        Update: Partial<Database["public"]["Tables"]["ai_memory"]["Insert"]>;
        Relationships: [];
      };
      user_preferences: {
        Row: {
          id: string;
          user_id: string;
          key: string;
          value: unknown;
          updated_at: Timestamp;
        };
        Insert: {
          id?: string;
          user_id: string;
          key: string;
          value?: unknown;
        };
        Update: Partial<Database["public"]["Tables"]["user_preferences"]["Insert"]>;
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
}
