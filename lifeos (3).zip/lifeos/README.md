# LifeOS

A premium personal operating system — schedule, money, projects, goals,
dreams, journal, documents, investments, and a unified dashboard, built
as one coherent system rather than separate apps bolted together.

**Stack:** Next.js 15 (App Router) · React 19 · TypeScript (strict) ·
Tailwind CSS · Supabase (Postgres, Auth, Storage) · Vercel

## Status

All core modules are built and verified: Calendar, Money, Projects,
Goals, Dreams, Journal, Documents, Investments, and a Dashboard that
aggregates real data across all of them. Life Areas, Organizations,
Timeline, and Settings have schema and RLS in place but no management
UI yet — an AI layer is planned next.

## Project overview

Every module lives under its own route and owns its own components —
`app/(app)/<module>/components/` — reusing a shared, frozen design
system (`components/ui/`) rather than each module inventing its own
look. The database is the single source of truth: Row Level Security
is enabled on every table, so a user can only ever see their own data,
enforced at the Postgres level regardless of what the client sends.

```
app/(marketing)/   Public routes — landing, login, register, reset-password.
app/(app)/         Authenticated app shell (Sidebar, TopBar) + every module.
                    calendar/ money/ projects/ goals/ dreams/ journal/
                    documents/ investments/ dashboard/
components/ui/      Button, Card, GlassPanel, Input, Modal, Badge, Tag,
                    PageHeader, StatCard — shared, frozen primitives.
components/layout/  Sidebar, TopBar, LocaleSwitcher, UserMenu.
components/shared/  FormStatus — the one cross-module component (form
                    success/error banners), used by every module's forms.
lib/supabase/       Browser client, server client, middleware session helper.
lib/validations/    One zod schema file per module.
lib/i18n/           EN/HU dictionaries.
supabase/           SQL migrations — source of truth for the schema.
types/supabase.ts   Hand-authored to mirror the migrations exactly, until
                    a live project exists to run real codegen against.
.github/workflows/  CI — typecheck, lint, build on every PR and push to main.
```

## Local setup

**Requirements:** Node.js 20+, npm, a Supabase account.

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Copy the environment template**
   ```bash
   cp .env.example .env.local
   ```

3. **Set up Supabase** — see the section below — then fill in `.env.local`.

4. **Run the dev server**
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000).

## Supabase setup

1. Create a project at [supabase.com](https://supabase.com).
2. In **Project Settings → API**, copy the **Project URL** and **anon
   public key** into `.env.local`.
3. In **Authentication → Providers**, confirm **Email** is enabled.
   For local development, turn off "Confirm email" so sign-up works
   immediately without waiting on an email provider being configured;
   turn it back on before real users sign up in production.
4. Push the schema with the Supabase CLI:
   ```bash
   npx supabase login
   npx supabase link --project-ref <your-project-ref>
   npx supabase db push
   ```
   This applies, in order:
   - `0001_init.sql` — every table (profiles, life_areas,
     organizations, projects, project_tasks, calendar_events,
     accounts, budget_categories, transactions,
     recurring_transactions, net_worth_snapshots, goals, dreams,
     milestones, journal_entries, documents, investment_accounts,
     investment_holdings, ai_memory, user_preferences), with Row
     Level Security enabled and an owner-only policy on every one.
   - `0002_storage.sql` — the private `documents` bucket
     (folder-per-user access, used by the Documents module) and the
     public-read `avatars` bucket.
5. Generate real types from the live schema (replaces the
   hand-authored placeholder):
   ```bash
   npm run supabase:types
   ```
   Re-run this after any future schema change — `SUPABASE_PROJECT_ID`
   in `.env.local` must be set first.

## Environment variables

See `.env.example` for the canonical list. Copy it to `.env.local` for
local development; set the same keys in your hosting provider's
dashboard for deployed environments.

| Variable | Required | Notes |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Public — safe to expose to the browser. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Public — RLS is what actually protects data, not secrecy of this key. |
| `SUPABASE_SERVICE_ROLE_KEY` | No | Not currently used anywhere in the app. Only needed if you later add server-only admin scripts. **Never** expose it with a `NEXT_PUBLIC_` prefix. |
| `SUPABASE_PROJECT_ID` | No (local only) | Used by `npm run supabase:types`, not read at runtime. |

## Deployment (Vercel)

1. Push this repo to GitHub.
2. In Vercel, **Add New Project** → import the repo. Vercel
   auto-detects Next.js; no custom build command is needed.
3. Add the environment variables from the table above in **Project
   Settings → Environment Variables** (at minimum
   `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
4. Deploy. Every push to `main` goes to production; every PR gets its
   own preview URL.
5. In Supabase, update **Authentication → URL Configuration** with
   your production domain (Site URL + Redirect URLs) so magic
   links / password-reset links and OAuth redirects work outside
   `localhost`.

## Scripts

```bash
npm run dev         # local dev server
npm run build        # production build
npm run start         # run a production build locally
npm run lint            # ESLint
npm run typecheck        # tsc --noEmit
npm run supabase:types    # regenerate types/supabase.ts from a live project
```

## CI

`.github/workflows/ci.yml` runs `npm ci`, typecheck, lint, and build on
every pull request and every push to `main`. It uses placeholder
Supabase env values purely so the build step can resolve
`NEXT_PUBLIC_*` variables — no real Supabase calls happen during CI.
