import { NextResponse, type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";
import { LOCALES, DEFAULT_LOCALE, type Locale } from "@/lib/i18n/config";

const LOCALE_COOKIE = "locale";

// Routes that don't require an authenticated session.
const PUBLIC_PATHS = ["/", "/login", "/register", "/reset-password"];

function detectLocale(request: NextRequest): Locale {
  const acceptLanguage = request.headers.get("accept-language") ?? "";
  const match = LOCALES.find((locale) => acceptLanguage.includes(locale));
  return match ?? DEFAULT_LOCALE;
}

export async function middleware(request: NextRequest) {
  // --- Auth protection (unchanged) ---
  const { response, user } = await updateSession(request);

  const isPublicPath = PUBLIC_PATHS.includes(request.nextUrl.pathname);

  if (!user && !isPublicPath) {
    const redirectUrl = request.nextUrl.clone();
    redirectUrl.pathname = "/login";
    return NextResponse.redirect(redirectUrl);
  }

  // --- Locale detection ---
  // Cookie-based only — no path rewriting (no /en/... or /hu/...
  // prefixes). Once set, the cookie always wins over the browser's
  // Accept-Language header, so a user's explicit choice sticks even
  // if their browser language differs.
  const existingLocale = request.cookies.get(LOCALE_COOKIE)?.value;
  const isValidLocale = LOCALES.includes(existingLocale as Locale);

  if (!isValidLocale) {
    response.cookies.set(LOCALE_COOKIE, detectLocale(request), {
      path: "/",
      maxAge: 60 * 60 * 24 * 365, // 1 year
      sameSite: "lax",
    });
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all paths except static assets and image optimization files.
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
